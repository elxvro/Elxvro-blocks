import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

void main() {
  test('current real-audio and composed-music pipeline is configured', () {
    // Network-fetched assets are verified explicitly by GitHub Actions before
    // flutter test runs. This unit test only checks stable project wiring so a
    // local/offline test run is not coupled to a downloaded build artifact.
    expect(File('tool/fetch_real_material_audio.sh').existsSync(), isTrue);
    expect(File('tool/fetch_real_puzzle_music.sh').existsSync(), isTrue);

    const bundledUiAudio = <String>[
      'assets/audio/ui_tap_v1.wav',
      'assets/audio/ui_tap_v2.wav',
      'assets/audio/ui_tap_v3.wav',
      'assets/audio/record_fanfare.wav',
      'assets/audio/reward.wav',
      'assets/audio/game_over.wav',
    ];

    for (final path in bundledUiAudio) {
      final file = File(path);
      expect(file.existsSync(), isTrue, reason: 'Missing $path');
      expect(file.lengthSync(), greaterThan(1000), reason: 'Empty $path');
    }

    final audioService = File('lib/services/audio_service.dart').readAsStringSync();
    expect(audioService, contains("audio/cozy_puzzle_music.ogg"));
    expect(audioService, isNot(contains("audio/ambient_loop.wav")));
  });
}
