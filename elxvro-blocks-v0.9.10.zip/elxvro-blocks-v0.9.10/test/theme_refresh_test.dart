import 'package:elxvro_blocks/models/game_theme.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('v0.9.7 premium theme set is complete and compatible', () {
    expect(gameThemes.length, 6);
    expect(gameThemes.first.id, 'classic');
    expect(gameThemes.map((theme) => theme.id).toSet().length, gameThemes.length);
    expect(
      gameThemes.map((theme) => theme.name).toSet(),
      containsAll(<String>{
        'Cam',
        'Dal',
        'Taş',
        'Yaprak',
        'Kristal',
        'Mermer Altın',
      }),
    );

    expect(
      gameThemes.map((theme) => theme.material).toSet().length,
      gameThemes.length,
    );
    expect(
      gameThemes.map((theme) => theme.audioProfile).toSet(),
      containsAll(<String>{
        'glass',
        'wood',
        'stone',
        'leaf',
        'crystal',
        'marble',
      }),
    );
  });
}
