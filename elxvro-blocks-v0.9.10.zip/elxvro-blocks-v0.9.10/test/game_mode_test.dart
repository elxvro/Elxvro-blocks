import 'package:elxvro_blocks/models/game_mode.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('challenge, zen and hard mode rules are configured', () {
    expect(gameModeData[GameMode.timed]!.durationSeconds, 120);
    expect(gameModeData[GameMode.target]!.targetScore, 5000);
    expect(gameModeData[GameMode.daily]!.durationSeconds, 180);
    expect(gameModeData[GameMode.daily]!.targetScore, 3500);
    expect(gameModeData[GameMode.zen]!.zenRecovery, isTrue);
    expect(gameModeData[GameMode.hard]!.hardPieces, isTrue);
    expect(gameModeData[GameMode.hard]!.scoreMultiplier, greaterThan(1));
    expect(
      gameModeData[GameMode.hard]!.specialChance,
      lessThan(gameModeData[GameMode.classic]!.specialChance),
    );
  });
}
