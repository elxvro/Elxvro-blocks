import 'package:elxvro_blocks/models/block_piece.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('expanded piece catalog contains premium large shapes', () {
    final ids = blockCatalog.map((piece) => piece.id).toSet();
    expect(ids, contains('line_5_h'));
    expect(ids, contains('line_5_v'));
    expect(ids, contains('plus_5'));
    expect(ids, contains('u_5'));
    expect(ids, contains('step_5'));
    expect(ids, contains('hook_5'));
    expect(blockCatalog.where((piece) => piece.size >= 5).length, greaterThan(5));
  });
}
