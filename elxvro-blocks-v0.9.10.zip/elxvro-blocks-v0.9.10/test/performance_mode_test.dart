import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:elxvro_blocks/app_state.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('performance mode loads and persists', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{
      'performance_mode': true,
    });

    final state = AppState();
    await state.load();
    expect(state.performanceMode, isTrue);

    await state.setPerformanceMode(false);
    final prefs = await SharedPreferences.getInstance();
    expect(prefs.getBool('performance_mode'), isFalse);
  });
}
