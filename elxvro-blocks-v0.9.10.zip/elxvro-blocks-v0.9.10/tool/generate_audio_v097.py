import math, wave
from pathlib import Path
import numpy as np
from scipy.signal import butter, sosfilt

SR=44100
OUT=Path(__file__).resolve().parents[1]/'assets'/'audio'
OUT.mkdir(parents=True, exist_ok=True)
rng=np.random.default_rng(97017)

def tvec(d): return np.arange(int(SR*d))/SR

def env_exp(t, attack=0.004, decay=12.0):
    a=np.minimum(1.0, t/max(attack,1e-5))
    return a*np.exp(-decay*t)

def lp(x, cutoff):
    sos=butter(4, cutoff/(SR/2), btype='low', output='sos'); return sosfilt(sos,x)

def hp(x, cutoff):
    sos=butter(4, cutoff/(SR/2), btype='high', output='sos'); return sosfilt(sos,x)

def bp(x, lo, hi):
    sos=butter(3, [lo/(SR/2),hi/(SR/2)], btype='band', output='sos'); return sosfilt(sos,x)

def sine(freq,t,phase=0): return np.sin(2*np.pi*freq*t+phase)

def chirp(f0,f1,t):
    k=(f1-f0)/max(t[-1],1e-6)
    return np.sin(2*np.pi*(f0*t+0.5*k*t*t))

def normalize(x, peak=.86):
    x=np.nan_to_num(x)
    m=np.max(np.abs(x)) if len(x) else 1
    if m>0: x=x/m*peak
    # ultra-light soft clip
    return np.tanh(x*1.12)/np.tanh(1.12)*peak

def save(name,x):
    x=normalize(x)
    y=np.int16(np.clip(x,-1,1)*32767)
    with wave.open(str(OUT/name),'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(y.tobytes())

def add_at(base, sig, sec, gain=1.0):
    i=int(sec*SR); n=min(len(sig),len(base)-i)
    if n>0: base[i:i+n]+=sig[:n]*gain

def resonant(d, freqs, amps=None, decays=None, attack=.002):
    t=tvec(d); amps=amps or [1]*len(freqs); decays=decays or [8+2*i for i in range(len(freqs))]
    y=np.zeros_like(t)
    for i,f in enumerate(freqs):
        y += amps[i]*sine(f,t,rng.random()*6.28)*env_exp(t,attack,decays[i])
    return y

def transient(d=.12, lo=200, hi=4000, decay=30, gain=1):
    t=tvec(d); n=rng.normal(0,1,len(t)); n=bp(n,lo,hi); return n*env_exp(t,.001,decay)*gain

def fit(sig,d):
    out=np.zeros(int(SR*d)); n=min(len(sig),len(out)); out[:n]=sig[:n]; return out

def ui_tap(kind):
    d=.11; t=tvec(d)
    # no DTMF: short tactile transient + muted tonal body
    base=transient(d,700,5200,48,.30)
    f=[360,430,500][kind]
    body=(sine(f,t)+0.28*sine(f*1.92,t))*env_exp(t,.001,32)*.20
    return base+body

for i in range(3): save(f'ui_tap_v{i+1}.wav',ui_tap(i))
save('click.wav',ui_tap(1))

# Material signatures
MAT={
 'glass': dict(place='glass', base=2300),
 'wood': dict(place='wood', base=420),
 'stone': dict(place='stone', base=180),
 'leaf': dict(place='leaf', base=1200),
 'crystal': dict(place='crystal', base=1550),
 'marble': dict(place='marble', base=760),
}

def place_sound(mat,variant):
    d=.34; t=tvec(d); jitter=(variant-2)*0.04
    if mat=='glass':
        y=resonant(d,[2100*(1+jitter),3200,4850],[.55,.32,.18],[15,19,24]) + fit(transient(.11,1800,8000,45,.16), d)
    elif mat=='crystal':
        y=resonant(d,[1450*(1+jitter),2320,3690,5400],[.58,.34,.24,.12],[11,14,18,23])
    elif mat=='wood':
        y=resonant(d,[330*(1+jitter),510,840],[.60,.32,.16],[18,24,31]) + fit(transient(.09,300,1800,40,.30), d)
    elif mat=='stone':
        y=resonant(d,[120*(1+jitter),240,470],[.62,.32,.13],[23,28,36]) + fit(transient(.12,120,1600,34,.34), d)
    elif mat=='leaf':
        n=hp(rng.normal(0,1,len(t)),1700); flutter=(.6+.4*np.sin(2*np.pi*17*t))
        y=n*flutter*env_exp(t,.003,12)*.20 + resonant(d,[900,1500],[.16,.08],[16,22])
    else: # marble
        y=resonant(d,[590*(1+jitter),940,1540],[.55,.26,.12],[16,21,28]) + fit(transient(.10,350,2800,42,.18), d)
    return y

def clear_sound(mat,variant):
    # satisfying sweep, not an explosion
    d=.72; t=tvec(d); y=np.zeros_like(t)
    if mat=='glass':
        y += resonant(d,[1750,2600,4100],[.30,.24,.16],[7,9,12])
        for k in range(4): add_at(y,resonant(.22,[2800+420*k+variant*60,4700+300*k],[.22,.10],[15,21]),.08*k,.75)
        y += hp(rng.normal(0,1,len(t)),3800)*np.exp(-6*t)*.035
    elif mat=='crystal':
        for k,note in enumerate([1460,1840,2210,2920]): add_at(y,resonant(.32,[note,note*1.51],[.32,.11],[10,16]),k*.09,.9)
    elif mat=='wood':
        for k in range(3): add_at(y,place_sound('wood',(variant+k)%3+1),k*.10,.65)
        y += bp(rng.normal(0,1,len(t)),600,2400)*np.exp(-7*t)*.035
    elif mat=='stone':
        # rolling pebbles + muted impact, avoid harsh boom
        add_at(y,place_sound('stone',variant),0,.55)
        n=bp(rng.normal(0,1,len(t)),180,2200)
        y += n*(0.45+0.55*np.sin(2*np.pi*11*t)**2)*np.exp(-7.5*t)*.06
        for k in range(3): add_at(y,place_sound('stone',(variant+k)%3+1),.11+.08*k,.24)
    elif mat=='leaf':
        n=hp(rng.normal(0,1,len(t)),1400)
        sweep=np.exp(-3.8*t)*(0.55+0.45*np.sin(2*np.pi*(5+8*t)*t)**2)
        y += n*sweep*.065
        y += resonant(d,[900,1350],[.10,.06],[7,10])
    else: # marble
        add_at(y,place_sound('marble',variant),0,.58)
        y += resonant(d,[720,1080,1730],[.24,.14,.08],[8,12,16])
        y += bp(rng.normal(0,1,len(t)),450,3200)*np.exp(-9*t)*.028
    return y

def combo_sound(mat):
    d=1.05; y=np.zeros(int(SR*d))
    roots={'glass':880,'wood':440,'stone':330,'leaf':660,'crystal':740,'marble':520}
    root=roots[mat]
    ratios=[1,1.25,1.5,2.0]
    for i,r in enumerate(ratios):
        note=resonant(.36,[root*r,root*r*2.01],[.28,.10],[8,13])
        add_at(y,note,i*.14,1)
    # material cue at front, quiet
    add_at(y,place_sound(mat,2),0,.25)
    return y

def perfect_sound(mat):
    d=1.55; y=np.zeros(int(SR*d))
    roots={'glass':740,'wood':392,'stone':294,'leaf':523,'crystal':659,'marble':466}
    root=roots[mat]
    for i,r in enumerate([1,1.25,1.5,2,2.5]):
        add_at(y,resonant(.55,[root*r,root*r*2],[.28,.09],[6,10]),i*.16,1)
    # sparkle tail for reward feel
    tt=tvec(.75); sparkle=hp(rng.normal(0,1,len(tt)),5000)*np.exp(-5*tt)*.025
    add_at(y,sparkle,.65,1)
    return y

for mat in MAT:
    for v in range(1,4):
        p=place_sound(mat,v); c=clear_sound(mat,v)
        save(f'{mat}_place_v{v}.wav',p); save(f'{mat}_clear_v{v}.wav',c)
    # legacy aliases
    save(f'{mat}_place.wav',place_sound(mat,2)); save(f'{mat}_clear.wav',clear_sound(mat,2))
    save(f'{mat}_combo.wav',combo_sound(mat)); save(f'{mat}_perfect.wav',perfect_sound(mat))

# Generic fallbacks
save('place.wav',place_sound('glass',2)); save('clear.wav',clear_sound('glass',2)); save('combo.wav',combo_sound('glass')); save('perfect.wav',perfect_sound('glass'))

# Reward: clean celesta-like ding
d=1.0; t=tvec(d); reward=resonant(d,[1046.5,1568,2093],[.42,.22,.12],[6,9,12]); save('reward.wav',reward)

# Record celebration: rising fanfare + confetti sparkle, not alarm-like
D=2.15; fan=np.zeros(int(SR*D));
for i,f in enumerate([659.25,783.99,987.77,1318.51]):
    add_at(fan,resonant(.72,[f,f*2,.5*f],[.36,.12,.08],[5.5,8,7]),i*.23,1)
# confetti: many tiny bright pings
for i in range(14):
    f=float(rng.uniform(1800,5200)); start=float(rng.uniform(.65,1.7));
    add_at(fan,resonant(.18,[f,f*1.48],[.10,.04],[20,28]),start,1)
save('record_fanfare.wav',fan)

# Game over: gentle descending tones, no buzzer
D=1.25; go=np.zeros(int(SR*D));
for i,f in enumerate([523.25,440,349.23]): add_at(go,resonant(.50,[f,f*1.5],[.20,.07],[6,9]),i*.22,1)
save('game_over.wav',go)

# Ambient loop: 32s, very low-density, warm pads + rare glassy accents, no percussion
D=32.0; t=tvec(D); music=np.zeros_like(t)
# chord progression Cmaj7 - Am7 - Fmaj7 - Gsus2, 8 sec each
chords=[[130.81,164.81,196.00,246.94],[110.00,130.81,164.81,196.00],[87.31,130.81,164.81,220.00],[98.00,146.83,196.00,220.00]]
for ci,ch in enumerate(chords):
    st=ci*8.0; seg=tvec(8.0); e=np.sin(np.pi*np.clip(seg/8,0,1))**0.7
    sig=np.zeros_like(seg)
    for j,f in enumerate(ch):
        sig += (sine(f,seg,rng.random()*6.28)+.18*sine(f*2,seg,rng.random()*6.28))*e*(.055/(1+j*.12))
    # gentle moving air
    air=lp(rng.normal(0,1,len(seg)),900)*e*.004
    add_at(music,sig+air,st,1)
# sparse soft chimes
for st,f in [(3.2,784),(11.4,659),(19.6,698),(27.2,880)]:
    add_at(music,resonant(2.0,[f,f*1.5,f*2],[.025,.013,.006],[2.1,2.8,3.5]),st,1)
# Fade edges to loop smoothly
fade=int(.25*SR); music[:fade]*=np.linspace(0,1,fade); music[-fade:]*=np.linspace(1,0,fade)
save('ambient_loop.wav',music*.7)

(OUT/'README.txt').write_text('''ELXVRO Blocks v0.9.7 audio assets\n\nDirection: modern casual-puzzle sound design: short, clean, material-readable, non-fatiguing.\nAll sounds are original procedural synthesis created for ELXVRO. No third-party recordings or copied game audio.\n\nMaterial language:\n- Glass: delicate tap + crystal shimmer; clears sweep/chime rather than smash.\n- Wood/Dal: hollow knock + soft twig texture.\n- Stone: muted rock knock + pebble roll; no explosive boom.\n- Leaf: airy rustle/swipe.\n- Crystal: bell-like resonances and rising sparkle.\n- Marble: polished ceramic/stone knock + restrained ring.\n- UI: short tactile soft taps, intentionally not DTMF/keypad-like.\n- New record: rising celebratory fanfare + confetti sparkle.\n- Music: sparse 32s warm ambient pad loop with rare soft chimes.\n''', encoding='utf-8')
print('generated',len(list(OUT.glob('*.wav'))),'wav files')
