#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ASSETS="$ROOT/assets/audio"
TMP="$ROOT/build/real_audio_sources"
mkdir -p "$ASSETS" "$TMP"

UA="ELXVRO-Blocks/0.9.8 (real-material-audio build)"
CURL=(curl -fsSL --retry 5 --retry-delay 2 -A "$UA")

log() { printf '[real-audio] %s\n' "$*"; }

download_commons() {
  local filename="$1" out="$2"
  local encoded
  encoded="$(python3 - "$filename" <<'PY'
import sys, urllib.parse
print(urllib.parse.quote(sys.argv[1], safe=''))
PY
)"
  log "Wikimedia: $filename"
  "${CURL[@]}" "https://commons.wikimedia.org/wiki/Special:Redirect/file/${encoded}" -o "$out"
  test -s "$out"
}

download_oga_file() {
  local page="$1" filename="$2" out="$3"
  local html="$TMP/page.html"
  log "OpenGameArt: $filename"
  "${CURL[@]}" "$page" -o "$html"
  local href
  href="$(python3 - "$html" "$filename" <<'PY'
import html as htmllib, re, sys
from pathlib import Path
text=Path(sys.argv[1]).read_text(errors='ignore')
name=re.escape(sys.argv[2])
# Drupal file links may contain URL encoding and query strings.
pat=re.compile(r'href=[\"\']([^\"\']*(?:'+name.replace(r'\ ', r'(?:%20|\s)')+r')[^\"\']*)[\"\']', re.I)
m=pat.search(text)
if not m:
    # relaxed search by basename fragments
    token=sys.argv[2].split('.')[0].replace(' ', '.*')
    pat=re.compile(r'href=[\"\']([^\"\']*'+token+r'[^\"\']*)[\"\']', re.I)
    m=pat.search(text)
if not m:
    raise SystemExit(3)
print(htmllib.unescape(m.group(1)))
PY
)"
  if [[ "$href" == //* ]]; then href="https:$href"; fi
  if [[ "$href" == /* ]]; then href="https://opengameart.org$href"; fi
  "${CURL[@]}" "$href" -o "$out"
  test -s "$out"
}

# Real field/foley recordings. All are CC0 or public domain; see REAL_AUDIO_CREDITS.md.
download_commons "Binging glass.ogg" "$TMP/glass_taps.ogg"
download_oga_file "https://opengameart.org/content/glass-break" "glass_breaking.wav" "$TMP/glass_break.wav"
download_commons "Knocking on wood or door.ogg" "$TMP/wood_knocks.ogg"
download_commons "Snapping twig (single).ogg" "$TMP/twig_snap.ogg"
download_oga_file "https://opengameart.org/content/random-sounds-samples" "moving leaves stereo.ogg" "$TMP/leaves.ogg"
download_oga_file "https://opengameart.org/content/moving-boulder" "boulder_drop.ogg" "$TMP/boulder_drop.ogg"
download_oga_file "https://opengameart.org/content/moving-boulder" "move_boulder.ogg" "$TMP/boulder_move.ogg"
download_commons "Pen dropped.ogg" "$TMP/marble_floor.ogg"

# Make short game-ready clips while preserving the recorded material character.
# Processing is limited to trim, gain, high/low-pass and tiny tempo variations.
make_clip() {
  local input="$1" output="$2" start="$3" dur="$4" gain="$5" filter="$6"
  ffmpeg -hide_banner -loglevel error -y \
    -ss "$start" -i "$input" -t "$dur" \
    -af "${filter},volume=${gain},alimiter=limit=0.96" \
    -ar 44100 -ac 2 -c:a pcm_s16le "$output"
}

# Glass: real taps + real bottle/window-style shatter recording.
make_clip "$TMP/glass_taps.ogg" "$ASSETS/glass_place_v1.wav" 0.00 0.34 1.25 "highpass=f=280"
make_clip "$TMP/glass_taps.ogg" "$ASSETS/glass_place_v2.wav" 1.15 0.34 1.18 "highpass=f=300"
make_clip "$TMP/glass_taps.ogg" "$ASSETS/glass_place_v3.wav" 2.35 0.34 1.20 "highpass=f=260"
make_clip "$TMP/glass_break.wav" "$ASSETS/glass_clear_v1.wav" 0.00 1.10 0.82 "highpass=f=130"
make_clip "$TMP/glass_break.wav" "$ASSETS/glass_clear_v2.wav" 0.16 1.05 0.78 "highpass=f=150"
make_clip "$TMP/glass_break.wav" "$ASSETS/glass_clear_v3.wav" 0.30 1.00 0.80 "highpass=f=120"
make_clip "$TMP/glass_break.wav" "$ASSETS/glass_combo.wav" 0.00 1.55 0.84 "highpass=f=110"
make_clip "$TMP/glass_break.wav" "$ASSETS/glass_perfect.wav" 0.00 2.10 0.88 "highpass=f=90"

# Wood/branch: real knocks and real twig snap.
make_clip "$TMP/wood_knocks.ogg" "$ASSETS/wood_place_v1.wav" 0.00 0.42 1.05 "lowpass=f=5200"
make_clip "$TMP/wood_knocks.ogg" "$ASSETS/wood_place_v2.wav" 1.85 0.42 1.02 "lowpass=f=5000"
make_clip "$TMP/wood_knocks.ogg" "$ASSETS/wood_place_v3.wav" 3.85 0.42 1.05 "lowpass=f=5400"
make_clip "$TMP/twig_snap.ogg" "$ASSETS/wood_clear_v1.wav" 0.00 0.78 0.92 "highpass=f=100"
make_clip "$TMP/twig_snap.ogg" "$ASSETS/wood_clear_v2.wav" 0.04 0.74 0.88 "highpass=f=120"
make_clip "$TMP/twig_snap.ogg" "$ASSETS/wood_clear_v3.wav" 0.08 0.70 0.90 "highpass=f=90"
make_clip "$TMP/twig_snap.ogg" "$ASSETS/wood_combo.wav" 0.00 0.80 0.96 "highpass=f=80"
make_clip "$TMP/twig_snap.ogg" "$ASSETS/wood_perfect.wav" 0.00 0.80 1.02 "highpass=f=70"

# Leaves: actual rustling leaves. Kept soft so repeated clears do not fatigue.
make_clip "$TMP/leaves.ogg" "$ASSETS/leaf_place_v1.wav" 0.00 0.40 0.92 "highpass=f=220"
make_clip "$TMP/leaves.ogg" "$ASSETS/leaf_place_v2.wav" 0.45 0.40 0.90 "highpass=f=240"
make_clip "$TMP/leaves.ogg" "$ASSETS/leaf_place_v3.wav" 0.90 0.40 0.94 "highpass=f=200"
make_clip "$TMP/leaves.ogg" "$ASSETS/leaf_clear_v1.wav" 0.00 0.85 0.88 "highpass=f=180"
make_clip "$TMP/leaves.ogg" "$ASSETS/leaf_clear_v2.wav" 0.55 0.85 0.86 "highpass=f=190"
make_clip "$TMP/leaves.ogg" "$ASSETS/leaf_clear_v3.wav" 1.10 0.85 0.88 "highpass=f=170"
make_clip "$TMP/leaves.ogg" "$ASSETS/leaf_combo.wav" 0.20 1.15 0.90 "highpass=f=160"
make_clip "$TMP/leaves.ogg" "$ASSETS/leaf_perfect.wav" 0.00 1.50 0.92 "highpass=f=150"

# Stone: CC0 boulder/stone recordings.
make_clip "$TMP/boulder_drop.ogg" "$ASSETS/stone_place_v1.wav" 0.00 0.42 1.08 "lowpass=f=6500"
make_clip "$TMP/boulder_drop.ogg" "$ASSETS/stone_place_v2.wav" 0.03 0.42 1.02 "lowpass=f=6100"
make_clip "$TMP/boulder_drop.ogg" "$ASSETS/stone_place_v3.wav" 0.06 0.42 1.06 "lowpass=f=7000"
make_clip "$TMP/boulder_move.ogg" "$ASSETS/stone_clear_v1.wav" 0.00 0.82 0.96 "lowpass=f=5600"
make_clip "$TMP/boulder_move.ogg" "$ASSETS/stone_clear_v2.wav" 0.04 0.78 0.94 "lowpass=f=5300"
make_clip "$TMP/boulder_drop.ogg" "$ASSETS/stone_clear_v3.wav" 0.00 0.78 0.98 "lowpass=f=6000"
make_clip "$TMP/boulder_drop.ogg" "$ASSETS/stone_combo.wav" 0.00 0.90 1.00 "lowpass=f=6200"
make_clip "$TMP/boulder_drop.ogg" "$ASSETS/stone_perfect.wav" 0.00 1.10 1.03 "lowpass=f=6000"

# Marble: real recording on a marble floor; combine with a restrained stone body for clears.
make_clip "$TMP/marble_floor.ogg" "$ASSETS/marble_place_v1.wav" 0.00 0.44 1.08 "highpass=f=140"
make_clip "$TMP/marble_floor.ogg" "$ASSETS/marble_place_v2.wav" 0.10 0.44 1.04 "highpass=f=150"
make_clip "$TMP/marble_floor.ogg" "$ASSETS/marble_place_v3.wav" 0.20 0.44 1.06 "highpass=f=130"
make_clip "$TMP/boulder_drop.ogg" "$ASSETS/marble_clear_v1.wav" 0.00 0.74 0.88 "highpass=f=120,lowpass=f=7800"
make_clip "$TMP/marble_floor.ogg" "$ASSETS/marble_clear_v2.wav" 0.00 0.74 1.00 "highpass=f=120"
make_clip "$TMP/boulder_move.ogg" "$ASSETS/marble_clear_v3.wav" 0.00 0.74 0.82 "highpass=f=110,lowpass=f=7600"
make_clip "$TMP/marble_floor.ogg" "$ASSETS/marble_combo.wav" 0.00 0.90 1.02 "highpass=f=120"
make_clip "$TMP/marble_floor.ogg" "$ASSETS/marble_perfect.wav" 0.00 1.05 1.06 "highpass=f=110"

# Crystal: uses the same real glass recording, with only filtering to emphasize crystal resonance.
make_clip "$TMP/glass_taps.ogg" "$ASSETS/crystal_place_v1.wav" 0.00 0.48 1.16 "highpass=f=600"
make_clip "$TMP/glass_taps.ogg" "$ASSETS/crystal_place_v2.wav" 1.15 0.48 1.12 "highpass=f=720"
make_clip "$TMP/glass_taps.ogg" "$ASSETS/crystal_place_v3.wav" 2.35 0.48 1.14 "highpass=f=650"
make_clip "$TMP/glass_taps.ogg" "$ASSETS/crystal_clear_v1.wav" 0.00 0.90 1.08 "highpass=f=520"
make_clip "$TMP/glass_taps.ogg" "$ASSETS/crystal_clear_v2.wav" 1.15 0.90 1.04 "highpass=f=560"
make_clip "$TMP/glass_taps.ogg" "$ASSETS/crystal_clear_v3.wav" 2.35 0.90 1.06 "highpass=f=500"
make_clip "$TMP/glass_taps.ogg" "$ASSETS/crystal_combo.wav" 0.00 1.10 1.10 "highpass=f=480"
make_clip "$TMP/glass_taps.ogg" "$ASSETS/crystal_perfect.wav" 0.00 1.45 1.14 "highpass=f=450"

# Legacy aliases used by older screens/tests.
cp "$ASSETS/glass_place_v1.wav" "$ASSETS/glass_place.wav"
cp "$ASSETS/glass_clear_v1.wav" "$ASSETS/glass_clear.wav"
cp "$ASSETS/wood_place_v1.wav" "$ASSETS/wood_place.wav"
cp "$ASSETS/wood_clear_v1.wav" "$ASSETS/wood_clear.wav"
cp "$ASSETS/stone_place_v1.wav" "$ASSETS/stone_place.wav"
cp "$ASSETS/stone_clear_v1.wav" "$ASSETS/stone_clear.wav"
cp "$ASSETS/leaf_place_v1.wav" "$ASSETS/leaf_place.wav"
cp "$ASSETS/leaf_clear_v1.wav" "$ASSETS/leaf_clear.wav"
cp "$ASSETS/crystal_place_v1.wav" "$ASSETS/crystal_place.wav"
cp "$ASSETS/crystal_clear_v1.wav" "$ASSETS/crystal_clear.wav"
cp "$ASSETS/marble_place_v1.wav" "$ASSETS/marble_place.wav"
cp "$ASSETS/marble_clear_v1.wav" "$ASSETS/marble_clear.wav"

cat > "$ASSETS/REAL_AUDIO_BUILD.txt" <<TXT
ELXVRO Blocks v0.9.8
Real-material audio prepared during GitHub Actions build.
See REAL_AUDIO_CREDITS.md for sources and licenses.
TXT

log "Real material audio ready."
