ELXVRO Blocks v0.9.4 audio assets

ambient_loop.wav and the theme-specific glass/wood/stone/leaf/crystal/marble sound-effect files were synthesized specifically for this project from generated waveforms/noise. They do not contain samples copied from commercial songs, games, recordings, or third-party sound libraries.

Generic click/reward/game-over assets are inherited from the previous ELXVRO Blocks project version.
