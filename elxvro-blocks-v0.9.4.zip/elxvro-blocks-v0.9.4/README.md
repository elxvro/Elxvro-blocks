# ELXVRO Blocks v0.9.4 — Final Gameplay Polish

Bu sürüm v0.9.3 materyal temalarını korur ve oyun hissini final sürüme yaklaştırır.

## Öne çıkan yenilikler

- **Temaya özel temizleme efektleri**
  - Cam: keskin cam parçaları
  - Dal: ahşap kıymıkları
  - Taş: kaya parçaları
  - Yaprak: savrulan yaprak parçaları
  - Kristal: elmas/kristal kırıkları
  - Mermer Altın: parlak altın/mermer tozu
- **Geliştirilmiş hayalet önizleme**: geçerli bırakma hücreleri artık seçili temanın gerçek materyal görünümünü yarı saydam olarak gösterir.
- **Perfect Clear tam ekran vurgusu**: performans modu kapalıyken tema rengiyle premium overlay gösterilir.
- **Combo görsel iyileştirmesi**: glow artık seçili temanın vurgu rengini kullanır.
- **Performans Modu**: Ayarlar ekranından açılır; parçacık sayısını ve ağır gölgeleri azaltır.
- **Klasik oyuna devam etme**: klasik modda tahta, eldeki parçalar ve skor cihazda tutulur; oyuna tekrar girildiğinde kaldığın yerden devam eder.
- **Hızlı dokunma koruması**: sürükle-bırak ve güç butonlarında çift işlem ihtimali azaltıldı.
- **Dengeli haptikler**: normal yerleştirme, temizleme, yüksek combo ve Perfect Clear farklı şiddetlerde geri bildirim verir.
- **Tema ekranı canlı önizleme**: seçili temanın malzeme görünümü büyük kartta gösterilir.
- v0.9.2 ile gelen düşük gecikmeli AudioPool ses motoru ve v0.9.3 materyal çizimleri korunur.

## Sürüm

- Flutter package version: `0.9.4+18`
- Android package: `com.elxvro.elxvro_blocks`
- Çıktılar: APK + AAB + obfuscation symbols + SHA-256

## GitHub dosya adı

Repo kökünde:

```text
elxvro-blocks-v0.9.4.zip
```

bulunmalıdır.

## Önerilen test sırası

1. Cam, Dal, Taş, Yaprak, Kristal ve Mermer Altın temalarında birer satır temizle; parçalanma efektlerinin birbirinden farklı olduğunu doğrula.
2. Blok sürüklerken geçerli hücrelerde gerçek materyal ghost preview göründüğünü kontrol et.
3. Perfect Clear yapıp büyük overlay ve güçlü haptic'i kontrol et.
4. Ayarlar > Performans Modu'nu açıp parçacık yoğunluğunun azaldığını ve oyunun akıcı kaldığını kontrol et.
5. Klasik oyunda birkaç hamle yap, ana menüye dön, tekrar Klasik'e gir; tahta ve skorun geri geldiğini kontrol et.
6. Geri Al / Yenile / Özel butonlarına hızlı art arda dokunup çift tüketim olmadığını kontrol et.
7. Tema ekranında üstteki büyük canlı önizlemenin seçili tema ile değiştiğini kontrol et.
