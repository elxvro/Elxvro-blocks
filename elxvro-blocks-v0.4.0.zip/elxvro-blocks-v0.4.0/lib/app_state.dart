import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AppState extends ChangeNotifier {
  static const String _bestScoreKey = 'best_score';
  static const String _themeKey = 'theme_id';
  static const String _gamesPlayedKey = 'games_played';
  static const String _maxComboKey = 'max_combo';
  static const String _totalScoreKey = 'total_score';
  static const String _totalLinesKey = 'total_lines';
  static const String _totalBlocksKey = 'total_blocks';
  static const String _dailyDateKey = 'daily_date';
  static const String _dailyGamesKey = 'daily_games';
  static const String _dailyLinesKey = 'daily_lines';
  static const String _dailyBestScoreKey = 'daily_best_score';
  static const String _soundEnabledKey = 'sound_enabled';
  static const String _hapticsEnabledKey = 'haptics_enabled';

  static const String _coinsKey = 'coins';
  static const String _rewardClaimDateKey = 'reward_claim_date';
  static const String _loginStreakKey = 'login_streak';
  static const String _dailyClaimsDateKey = 'daily_claims_date';
  static const String _dailyClaimsKey = 'daily_claims';
  static const String _achievementClaimsKey = 'achievement_claims';
  static const String _unlockedThemesKey = 'unlocked_themes';
  static const String _undoInventoryKey = 'undo_inventory';
  static const String _refreshInventoryKey = 'refresh_inventory';
  static const String _specialInventoryKey = 'special_inventory';

  int bestScore = 0;
  int gamesPlayed = 0;
  int maxCombo = 0;
  int totalScore = 0;
  int totalLines = 0;
  int totalBlocks = 0;

  int dailyGames = 0;
  int dailyLines = 0;
  int dailyBestScore = 0;

  int coins = 0;
  int loginStreak = 0;
  int undoInventory = 0;
  int refreshInventory = 0;
  int specialInventory = 0;

  String themeId = 'classic';
  String _lastRewardClaimDate = '';
  final Set<String> _dailyClaims = <String>{};
  final Set<String> _achievementClaims = <String>{};
  final Set<String> _unlockedThemes = <String>{'classic'};

  bool soundEnabled = true;
  bool hapticsEnabled = true;
  bool isLoaded = false;

  int get completedDailyMissions {
    var completed = 0;
    if (dailyGames >= 1) completed += 1;
    if (dailyLines >= 8) completed += 1;
    if (dailyBestScore >= 2500) completed += 1;
    return completed;
  }

  int get unlockedAchievements {
    var unlocked = 0;
    if (gamesPlayed >= 1) unlocked += 1;
    if (bestScore >= 1000) unlocked += 1;
    if (maxCombo >= 3) unlocked += 1;
    if (totalLines >= 25) unlocked += 1;
    if (gamesPlayed >= 10) unlocked += 1;
    if (totalBlocks >= 250) unlocked += 1;
    if (bestScore >= 10000) unlocked += 1;
    return unlocked;
  }

  bool achievementUnlocked(String id) {
    switch (id) {
      case 'first_game':
        return gamesPlayed >= 1;
      case 'score_1000':
        return bestScore >= 1000;
      case 'combo_3':
        return maxCombo >= 3;
      case 'lines_25':
        return totalLines >= 25;
      case 'games_10':
        return gamesPlayed >= 10;
      case 'blocks_250':
        return totalBlocks >= 250;
      case 'score_10000':
        return bestScore >= 10000;
      default:
        return false;
    }
  }

  bool isDailyMissionClaimed(String id) => _dailyClaims.contains(id);

  bool isAchievementClaimed(String id) => _achievementClaims.contains(id);

  bool isThemeUnlocked(String id) => _unlockedThemes.contains(id);

  bool get dailyRewardAvailable =>
      _lastRewardClaimDate != _dayKey(DateTime.now());

  int get dailyRewardDay {
    if (!dailyRewardAvailable) {
      return loginStreak <= 0 ? 1 : loginStreak;
    }
    final yesterday = _dayKey(DateTime.now().subtract(const Duration(days: 1)));
    if (_lastRewardClaimDate == yesterday) {
      final next = loginStreak + 1;
      return next > 7 ? 7 : next;
    }
    return 1;
  }

  int get dailyRewardAmount {
    const rewards = <int>[50, 75, 100, 125, 150, 200, 300];
    final day = dailyRewardDay.clamp(1, 7).toInt();
    return rewards[day - 1];
  }

  int themePrice(String id) {
    switch (id) {
      case 'classic':
        return 0;
      case 'night':
        return 300;
      case 'marble':
        return 500;
      case 'fire':
        return 700;
      case 'nature':
        return 700;
      case 'aurora':
        return 1000;
      default:
        return 500;
    }
  }

  Future<void> load() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      bestScore = prefs.getInt(_bestScoreKey) ?? 0;
      gamesPlayed = prefs.getInt(_gamesPlayedKey) ?? 0;
      maxCombo = prefs.getInt(_maxComboKey) ?? 0;
      totalScore = prefs.getInt(_totalScoreKey) ?? 0;
      totalLines = prefs.getInt(_totalLinesKey) ?? 0;
      totalBlocks = prefs.getInt(_totalBlocksKey) ?? 0;
      themeId = prefs.getString(_themeKey) ?? 'classic';
      soundEnabled = prefs.getBool(_soundEnabledKey) ?? true;
      hapticsEnabled = prefs.getBool(_hapticsEnabledKey) ?? true;

      coins = prefs.getInt(_coinsKey) ?? 0;
      _lastRewardClaimDate = prefs.getString(_rewardClaimDateKey) ?? '';
      loginStreak = prefs.getInt(_loginStreakKey) ?? 0;
      undoInventory = prefs.getInt(_undoInventoryKey) ?? 0;
      refreshInventory = prefs.getInt(_refreshInventoryKey) ?? 0;
      specialInventory = prefs.getInt(_specialInventoryKey) ?? 0;

      _achievementClaims
        ..clear()
        ..addAll(prefs.getStringList(_achievementClaimsKey) ?? const <String>[]);

      _unlockedThemes
        ..clear()
        ..addAll(prefs.getStringList(_unlockedThemesKey) ?? const <String>[]);
      _unlockedThemes.add('classic');
      // Existing players keep whichever theme they had selected before the
      // economy system was introduced.
      _unlockedThemes.add(themeId);

      final today = _dayKey(DateTime.now());
      final savedDay = prefs.getString(_dailyDateKey);
      if (savedDay == today) {
        dailyGames = prefs.getInt(_dailyGamesKey) ?? 0;
        dailyLines = prefs.getInt(_dailyLinesKey) ?? 0;
        dailyBestScore = prefs.getInt(_dailyBestScoreKey) ?? 0;
      } else {
        dailyGames = 0;
        dailyLines = 0;
        dailyBestScore = 0;
        await _saveDaily(prefs, today);
      }

      final claimsDay = prefs.getString(_dailyClaimsDateKey);
      _dailyClaims.clear();
      if (claimsDay == today) {
        _dailyClaims.addAll(
          prefs.getStringList(_dailyClaimsKey) ?? const <String>[],
        );
      } else {
        await prefs.setString(_dailyClaimsDateKey, today);
        await prefs.setStringList(_dailyClaimsKey, const <String>[]);
      }

      await prefs.setStringList(
        _unlockedThemesKey,
        _unlockedThemes.toList()..sort(),
      );
    } catch (error, stackTrace) {
      debugPrint('ELXVRO storage load failed: $error');
      debugPrintStack(stackTrace: stackTrace);
    } finally {
      isLoaded = true;
      notifyListeners();
    }
  }

  Future<void> setTheme(String id) async {
    if (!isThemeUnlocked(id)) {
      return;
    }
    themeId = id;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_themeKey, id);
    } catch (error) {
      debugPrint('ELXVRO theme save failed: $error');
    }
  }

  Future<bool> unlockTheme(String id) async {
    if (isThemeUnlocked(id)) {
      await setTheme(id);
      return true;
    }
    final price = themePrice(id);
    if (coins < price) {
      return false;
    }
    coins -= price;
    _unlockedThemes.add(id);
    themeId = id;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt(_coinsKey, coins);
      await prefs.setString(_themeKey, id);
      await prefs.setStringList(
        _unlockedThemesKey,
        _unlockedThemes.toList()..sort(),
      );
    } catch (error) {
      debugPrint('ELXVRO theme unlock save failed: $error');
    }
    return true;
  }

  Future<void> setSoundEnabled(bool value) async {
    soundEnabled = value;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(_soundEnabledKey, value);
    } catch (error) {
      debugPrint('ELXVRO sound setting save failed: $error');
    }
  }

  Future<void> setHapticsEnabled(bool value) async {
    hapticsEnabled = value;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(_hapticsEnabledKey, value);
    } catch (error) {
      debugPrint('ELXVRO haptics setting save failed: $error');
    }
  }

  Future<bool> claimDailyReward() async {
    if (!dailyRewardAvailable) {
      return false;
    }
    final now = DateTime.now();
    final today = _dayKey(now);
    final yesterday = _dayKey(now.subtract(const Duration(days: 1)));
    if (_lastRewardClaimDate == yesterday) {
      loginStreak += 1;
      if (loginStreak > 7) loginStreak = 7;
    } else {
      loginStreak = 1;
    }
    const rewards = <int>[50, 75, 100, 125, 150, 200, 300];
    coins += rewards[loginStreak - 1];
    _lastRewardClaimDate = today;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt(_coinsKey, coins);
      await prefs.setInt(_loginStreakKey, loginStreak);
      await prefs.setString(_rewardClaimDateKey, today);
    } catch (error) {
      debugPrint('ELXVRO daily reward save failed: $error');
    }
    return true;
  }

  Future<bool> claimDailyMission({
    required String id,
    required int reward,
    required bool completed,
  }) async {
    if (!completed || _dailyClaims.contains(id)) {
      return false;
    }
    _dailyClaims.add(id);
    coins += reward;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt(_coinsKey, coins);
      await prefs.setString(_dailyClaimsDateKey, _dayKey(DateTime.now()));
      await prefs.setStringList(_dailyClaimsKey, _dailyClaims.toList()..sort());
    } catch (error) {
      debugPrint('ELXVRO mission reward save failed: $error');
    }
    return true;
  }

  Future<bool> claimAchievement({
    required String id,
    required int reward,
  }) async {
    if (!achievementUnlocked(id) || _achievementClaims.contains(id)) {
      return false;
    }
    _achievementClaims.add(id);
    coins += reward;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt(_coinsKey, coins);
      await prefs.setStringList(
        _achievementClaimsKey,
        _achievementClaims.toList()..sort(),
      );
    } catch (error) {
      debugPrint('ELXVRO achievement reward save failed: $error');
    }
    return true;
  }

  Future<bool> buyUndoPack() => _purchase(
        price: 120,
        undo: 3,
      );

  Future<bool> buyRefreshPack() => _purchase(
        price: 120,
        refresh: 3,
      );

  Future<bool> buySpecialPack() => _purchase(
        price: 180,
        special: 3,
      );

  Future<bool> buyPowerBundle() => _purchase(
        price: 300,
        undo: 5,
        refresh: 5,
        special: 2,
      );

  Future<bool> _purchase({
    required int price,
    int undo = 0,
    int refresh = 0,
    int special = 0,
  }) async {
    if (coins < price) {
      return false;
    }
    coins -= price;
    undoInventory += undo;
    refreshInventory += refresh;
    specialInventory += special;
    notifyListeners();
    await _saveEconomy();
    return true;
  }

  Future<bool> consumeUndo() async {
    if (undoInventory <= 0) return false;
    undoInventory -= 1;
    notifyListeners();
    await _saveEconomy();
    return true;
  }

  Future<bool> consumeRefresh() async {
    if (refreshInventory <= 0) return false;
    refreshInventory -= 1;
    notifyListeners();
    await _saveEconomy();
    return true;
  }

  Future<bool> consumeSpecial() async {
    if (specialInventory <= 0) return false;
    specialInventory -= 1;
    notifyListeners();
    await _saveEconomy();
    return true;
  }

  Future<void> _saveEconomy() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt(_coinsKey, coins);
      await prefs.setInt(_undoInventoryKey, undoInventory);
      await prefs.setInt(_refreshInventoryKey, refreshInventory);
      await prefs.setInt(_specialInventoryKey, specialInventory);
    } catch (error) {
      debugPrint('ELXVRO economy save failed: $error');
    }
  }

  Future<void> recordGame({
    required int score,
    required int combo,
    required int clearedLines,
    required int placedBlocks,
  }) async {
    gamesPlayed += 1;
    totalScore += score;
    totalLines += clearedLines;
    totalBlocks += placedBlocks;

    if (score > bestScore) {
      bestScore = score;
    }
    if (combo > maxCombo) {
      maxCombo = combo;
    }

    final today = _dayKey(DateTime.now());
    dailyGames += 1;
    dailyLines += clearedLines;
    if (score > dailyBestScore) {
      dailyBestScore = score;
    }
    notifyListeners();

    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt(_bestScoreKey, bestScore);
      await prefs.setInt(_gamesPlayedKey, gamesPlayed);
      await prefs.setInt(_maxComboKey, maxCombo);
      await prefs.setInt(_totalScoreKey, totalScore);
      await prefs.setInt(_totalLinesKey, totalLines);
      await prefs.setInt(_totalBlocksKey, totalBlocks);
      await _saveDaily(prefs, today);
    } catch (error) {
      debugPrint('ELXVRO stats save failed: $error');
    }
  }

  Future<void> _saveDaily(SharedPreferences prefs, String day) async {
    await prefs.setString(_dailyDateKey, day);
    await prefs.setInt(_dailyGamesKey, dailyGames);
    await prefs.setInt(_dailyLinesKey, dailyLines);
    await prefs.setInt(_dailyBestScoreKey, dailyBestScore);
  }

  String _dayKey(DateTime date) {
    final year = date.year.toString().padLeft(4, '0');
    final month = date.month.toString().padLeft(2, '0');
    final day = date.day.toString().padLeft(2, '0');
    return '$year-$month-$day';
  }
}
