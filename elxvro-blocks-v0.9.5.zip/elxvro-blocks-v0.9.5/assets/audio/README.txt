ELXVRO Blocks v0.9.5 audio assets

ambient_loop.wav and the theme-specific glass/wood/stone/leaf/crystal/marble sound-effect files were synthesized specifically for this project from generated waveforms/noise. They do not contain samples copied from commercial songs, games, recordings, or third-party sound libraries.

v0.9.5 adds place_v1..v3 and clear_v1..v3 variations for every material profile. These are deterministic pitch/gain variations generated from the project's own synthesized source effects to reduce repetitive playback without introducing third-party audio.

Generic click/reward/game-over assets are inherited from the previous ELXVRO Blocks project version.
