# ELXVRO Blocks v0.9.5 — Gameplay Expansion

v0.9.4'te oturan materyal tema ve performans altyapısını koruyup oyunun tekrar oynanabilirliğini artıran genişleme sürümü.

## Yeni oyun modları

- **ZEN**
  - Süre ve hedef baskısı yok.
  - Hamle tamamen tıkanırsa oyun bitmez; **Zen Nefesi** dolu hücrelerin bir bölümünü temizleyip yeni parçalar verir.
  - Daha sakin puan katsayısı ve biraz daha yüksek özel blok ihtimali kullanır.
- **ZOR MOD**
  - Oyun 20 dolu hücreyle başlar.
  - Büyük/karmaşık bloklar çok daha sık gelir.
  - Özel blok ihtimali düşüktür.
  - Puanlar **x1.35** katsayısıyla hesaplanır.

## Yeni blok şekilleri

Standart havuza şu şekiller eklendi:

- 5'li yatay çizgi
- 5'li dikey çizgi
- Plus / artı parçası
- U parçası
- Basamak parçası
- Kanca parçası

## Yeni clear sistemi

Tek hamlede birden fazla çizgi temizlemek artık ayrı olay olarak ödüllendirilir:

- **DOUBLE CLEAR** — 2 çizgi
- **TRIPLE CLEAR** — 3 çizgi
- **MEGA CLEAR** — 4+ çizgi

Bu clear türleri ek skor, tema rengi banner ve daha güçlü ses/haptic geri bildirimi üretir.

## Kritik hamle kurtarma

Hamle kalmadığında elde kullanılabilir **Yenile, Özel Blok veya Geri Al** hakkı varsa oyun artık hemen bitmez. Oyuncuya `KRİTİK HAMLE • GÜÇ KULLAN` uyarısı verilir ve kurtarma aracı kullanılabilir.

## Tema sistemi genişletmesi

- Seçili Cam / Dal / Taş / Yaprak / Kristal / Mermer Altın materyali artık ana ekran, modlar, ayarlar, mağaza, başarımlar, profil, ödüller, sosyal merkez ve istatistik arka planlarına taşınır.
- Material 3 vurgu rengi seçili temanın accent rengiyle dinamik oluşturulur.
- Premium ana buton seçili temanın renginden gradient üretir.

## Ses varyasyonları

- Cam, Dal, Taş, Yaprak, Kristal ve Mermer için **3 farklı yerleştirme** ve **3 farklı temizleme** varyasyonu bulunur.
- Aynı sesin her hamlede birebir tekrar etmesi azaltıldı.
- Düşük gecikmeli AudioPool motoru korunur; yalnız aktif temanın havuzları sıcak tutulur.
- Double/Triple/Mega clear durumunda daha güçlü tema sesi kullanılır.

## Sürüm

- Flutter package: `0.9.5+19`
- Android package: `com.elxvro.elxvro_blocks`
- Build: APK + AAB + obfuscation symbols + SHA-256

## GitHub dosyası

Repo kökünde:

```text
elxvro-blocks-v0.9.5.zip
```

bulunmalıdır.

## Önerilen test sırası

1. Modlar > Zen'e gir; tahtayı tıkayıp Zen Nefesi sonrası oyunun devam ettiğini kontrol et.
2. Modlar > Zor Mod'a gir; başlangıç tahtasının dolu ve büyük parçaların daha sık olduğunu kontrol et.
3. Tek hamlede 2 ve 3 çizgi temizleyerek DOUBLE/TRIPLE CLEAR bannerlarını kontrol et.
4. Hamle kalmadığında Yenile veya Geri Al hakkı varken oyunun hemen bitmediğini kontrol et.
5. Cam, Dal, Taş ve Yaprak arasında geçiş yapıp ana menü/mod ekranındaki arka plan materyalinin değiştiğini kontrol et.
6. Aynı temada art arda blok koyup yerleştirme/temizleme seslerinde küçük varyasyonlar olduğunu dinle.
7. İstatistikler ekranında Zen ve Zor Mod rekorlarının kaydedildiğini kontrol et.
