import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AppState extends ChangeNotifier {
  static const String _bestScoreKey = 'best_score';
  static const String _themeKey = 'theme_id';
  static const String _gamesPlayedKey = 'games_played';
  static const String _maxComboKey = 'max_combo';

  int bestScore = 0;
  int gamesPlayed = 0;
  int maxCombo = 0;
  String themeId = 'classic';
  bool isLoaded = false;

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    bestScore = prefs.getInt(_bestScoreKey) ?? 0;
    gamesPlayed = prefs.getInt(_gamesPlayedKey) ?? 0;
    maxCombo = prefs.getInt(_maxComboKey) ?? 0;
    themeId = prefs.getString(_themeKey) ?? 'classic';
    isLoaded = true;
    notifyListeners();
  }

  Future<void> setTheme(String id) async {
    themeId = id;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_themeKey, id);
  }

  Future<void> recordGame({required int score, required int combo}) async {
    gamesPlayed += 1;
    if (score > bestScore) {
      bestScore = score;
    }
    if (combo > maxCombo) {
      maxCombo = combo;
    }
    notifyListeners();

    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_bestScoreKey, bestScore);
    await prefs.setInt(_gamesPlayedKey, gamesPlayed);
    await prefs.setInt(_maxComboKey, maxCombo);
  }
}
