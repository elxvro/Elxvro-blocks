import 'package:flutter/material.dart';

import 'app_state.dart';
import 'screens/home_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final appState = AppState();
  await appState.load();
  runApp(ElxvroBlocksApp(appState: appState));
}

class ElxvroBlocksApp extends StatelessWidget {
  const ElxvroBlocksApp({super.key, required this.appState});

  final AppState appState;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: appState,
      builder: (context, _) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'ELXVRO Blocks',
          theme: ThemeData(
            brightness: Brightness.dark,
            scaffoldBackgroundColor: const Color(0xFF050505),
            colorScheme: ColorScheme.fromSeed(
              seedColor: const Color(0xFFD79A4B),
              brightness: Brightness.dark,
            ),
            useMaterial3: true,
          ),
          home: HomeScreen(appState: appState),
        );
      },
    );
  }
}
