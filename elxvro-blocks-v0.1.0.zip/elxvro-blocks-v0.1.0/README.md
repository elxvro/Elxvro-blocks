# ELXVRO Blocks v0.1.0

Premium görsel kimliğe sahip, 10x10 sürükle-bırak blok puzzle prototipi.

## Bu sürümde

- 10x10 oynanabilir tahta
- 3 rastgele blok ve sürükle-bırak yerleştirme
- Tam dolan satır/sütun temizleme
- Puan ve combo sistemi
- Oyun bitti algılama
- Yerel en yüksek skor / oynanan oyun / maksimum combo kaydı
- 6 tema: Klasik, Gece, Mermer, Ateş, Doğa, Aurora
- Premium koyu + altın ELXVRO UI
- GitHub Actions üzerinden release APK üretimi
- Board engine unit testleri

## GitHub Actions

Repoyu GitHub'a yükleyip `main` branch'ine push yaptığında:

1. Flutter 3.47.4 kurulur.
2. Android platform dosyaları oluşturulur.
3. `flutter analyze` çalışır.
4. `flutter test` çalışır.
5. Release APK oluşturulur.
6. `ELXVRO-Blocks-v0.1.0.apk` artifact olarak yüklenir.

Workflow: `.github/workflows/build-apk.yml`

## Not

Bu ilk oynanabilir temel sürümdür. Sonraki sürüm için animasyonlu satır patlaması, özel bloklar, günlük görevler, başarımlar, ses/haptics ve Google Play Games planlanabilir.
