import 'package:flutter/material.dart';

import '../game/adventure_quest.dart';

class AdventureResultDialog extends StatelessWidget {
  const AdventureResultDialog({
    super.key,
    required this.progress,
    required this.success,
    required this.stars,
    required this.score,
    required this.earnedCoins,
    required this.accent,
    required this.surface,
    required this.turkish,
    required this.canGoNext,
    required this.onMap,
    required this.onNext,
    required this.onRetry,
  });
  final AdventureQuestProgress progress;
  final bool success;
  final int stars;
  final int score;
  final int earnedCoins;
  final Color accent;
  final Color surface;
  final bool turkish;
  final bool canGoNext;
  final VoidCallback onMap;
  final VoidCallback onNext;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    final mission = progress.mission;
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 21, vertical: 20),
      child: Container(
        constraints: const BoxConstraints(maxWidth: 420),
        padding: const EdgeInsets.all(19),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(25),
          border: Border.all(color: accent.withValues(alpha: .54)),
          gradient: LinearGradient(
            begin: Alignment.topCenter, end: Alignment.bottomCenter,
            colors: <Color>[
              Color.lerp(surface, accent, .22)!, surface,
            ],
          ),
          boxShadow: <BoxShadow>[
            BoxShadow(color: accent.withValues(alpha: .18), blurRadius: 30),
          ],
        ),
        child: SingleChildScrollView(child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            if (success)
              Row(mainAxisAlignment: MainAxisAlignment.center, children:
                List<Widget>.generate(3, (i) => Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 3),
                  child: Icon(i < stars ? Icons.star_rounded : Icons.star_border_rounded,
                    color: i < stars ? const Color(0xFFFFD568) : Colors.white24,
                    size: i == 1 ? 52 : 40),
                )),
              )
            else Icon(Icons.restart_alt_rounded, size: 53, color: accent),
            const SizedBox(height: 9),
            Text(success
                  ? (turkish ? 'BÖLÜM TAMAMLANDI!' : 'LEVEL COMPLETE!')
                  : (turkish ? 'GÖREV TAMAMLANAMADI' : 'MISSION FAILED'),
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900,
                color: accent)),
            const SizedBox(height: 4),
            Text('${turkish ? 'Bölüm' : 'Level'} ${mission.level}',
              style: const TextStyle(color: Colors.white70, fontSize: 12)),
            const SizedBox(height: 14),
            _stat(Icons.view_agenda_rounded,
              turkish ? 'Temizlenen satır' : 'Cleared lines',
              '${progress.lines}/${mission.linesTarget}'),
            if (mission.specialKind != null)
              _stat(Icons.diamond_rounded,
                switch (mission.specialKind!) {
                  AdventureGoalKind.ice => turkish ? 'Kırılan buz' : 'Ice broken',
                  AdventureGoalKind.crystals => turkish ? 'Kristal' : 'Crystals',
                  _ => turkish ? 'Temizlenen taş' : 'Stones cleared',
                }, '${progress.specialCollected}/${mission.specialTarget}'),
            if (mission.comboTarget > 0)
              _stat(Icons.bolt_rounded, turkish ? 'En iyi kombo' : 'Best combo',
                '${progress.maxCombo}/${mission.comboTarget}'),
            if (mission.isBoss)
              _stat(Icons.shield_rounded, turkish ? 'Boss enerjisi' : 'Boss health',
                '${progress.bossHealth}/${mission.bossMaxHealth}'),
            _stat(Icons.leaderboard_rounded,
              turkish ? 'Skor' : 'Score', '$score'),
            const SizedBox(height: 13),
            if (success)
              Container(
                padding: const EdgeInsets.all(11),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14),
                  color: Colors.black.withValues(alpha: .22),
                  border: Border.all(color: accent.withValues(alpha: .22)),
                ),
                child: Row(mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    const Icon(Icons.monetization_on_rounded,
                      color: Color(0xFFFFD568)),
                    const SizedBox(width: 6),
                    Text('+$earnedCoins',
                      style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
                    const SizedBox(width: 8),
                    Text(turkish ? 'İlk tamamlama ödülü' : 'First-clear reward',
                      style: const TextStyle(color: Colors.white60, fontSize: 10)),
                  ],
                ),
              ),
            const SizedBox(height: 17),
            SizedBox(width: double.infinity, child: FilledButton.icon(
              onPressed: canGoNext ? onNext : onRetry,
              style: FilledButton.styleFrom(
                backgroundColor: accent,
                foregroundColor: Colors.black,
                padding: const EdgeInsets.symmetric(vertical: 13),
              ),
              icon: Icon(canGoNext ? Icons.arrow_forward_rounded : Icons.replay_rounded),
              label: Text(canGoNext
                  ? (turkish ? 'SONRAKİ BÖLÜM' : 'NEXT LEVEL')
                  : (turkish ? 'TEKRAR DENE' : 'TRY AGAIN')),
            )),
            TextButton.icon(
              onPressed: onMap,
              icon: const Icon(Icons.map_rounded),
              label: Text(turkish ? 'DÜNYA HARİTASI' : 'WORLD MAP'),
              style: TextButton.styleFrom(foregroundColor: Colors.white70),
            ),
          ],
        )),
      ),
    );
  }

  Widget _stat(IconData icon, String label, String value) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 4),
    child: Row(children: <Widget>[
      Icon(icon, size: 17, color: accent),
      const SizedBox(width: 7),
      Expanded(child: Text(label,
        style: const TextStyle(color: Colors.white70, fontSize: 12))),
      Text(value, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 12)),
    ]),
  );
}
