import 'package:flutter/material.dart';

import '../game/adventure_quest.dart';

class AdventureMissionHud extends StatelessWidget {
  const AdventureMissionHud({
    super.key,
    required this.progress,
    required this.accent,
    required this.surface,
    required this.turkish,
  });
  final AdventureQuestProgress progress;
  final Color accent;
  final Color surface;
  final bool turkish;

  @override
  Widget build(BuildContext context) {
    final mission = progress.mission;
    final objectives = <(IconData, String, int, int)>[
      (Icons.view_agenda_rounded, turkish ? 'SATIR' : 'LINES',
        progress.lines, mission.linesTarget),
      if (mission.specialKind != null)
        (switch (mission.specialKind!) {
            AdventureGoalKind.ice => Icons.ac_unit_rounded,
            AdventureGoalKind.crystals => Icons.diamond_rounded,
            _ => Icons.hexagon_rounded,
          },
          switch (mission.specialKind!) {
            AdventureGoalKind.ice => turkish ? 'BUZ' : 'ICE',
            AdventureGoalKind.crystals => turkish ? 'KRİSTAL' : 'CRYSTAL',
            _ => turkish ? 'TAŞ' : 'STONE',
          },
          progress.specialCollected, mission.specialTarget),
      if (mission.comboTarget > 0)
        (Icons.bolt_rounded, turkish ? 'KOMBO' : 'COMBO',
          progress.maxCombo, mission.comboTarget),
    ];
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 0, 12, 5),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: surface.withValues(alpha: .9),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: accent.withValues(alpha: .25)),
      ),
      child: Column(mainAxisSize: MainAxisSize.min, children: <Widget>[
        Row(children: <Widget>[
          for (var i = 0; i < objectives.length; i++) ...<Widget>[
            if (i > 0) const SizedBox(width: 8),
            Expanded(child: _ObjectiveTile(
              icon: objectives[i].$1, label: objectives[i].$2,
              current: objectives[i].$3, target: objectives[i].$4,
              accent: accent,
            )),
          ],
        ]),
        if (mission.isBoss) ...<Widget>[
          const SizedBox(height: 8),
          Row(children: <Widget>[
            const Icon(Icons.shield_rounded, color: Color(0xFFFF778A), size: 13),
            const SizedBox(width: 5),
            Expanded(child: Text(
              turkish ? 'BOSS • KARANLIK ÇEKİRDEK' : 'BOSS • DARK CORE',
              style: const TextStyle(fontSize: 9, fontWeight: FontWeight.w900),
            )),
            Text('${progress.bossHealth}/${mission.bossMaxHealth}',
              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 10)),
          ]),
          const SizedBox(height: 3),
          ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: LinearProgressIndicator(
              minHeight: 5,
              backgroundColor: Colors.white10,
              value: progress.bossHealth / mission.bossMaxHealth,
              valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFFFF6485)),
            ),
          ),
        ],
      ]),
    );
  }
}

class _ObjectiveTile extends StatelessWidget {
  const _ObjectiveTile({
    required this.icon, required this.label, required this.current,
    required this.target, required this.accent,
  });
  final IconData icon;
  final String label;
  final int current;
  final int target;
  final Color accent;

  @override
  Widget build(BuildContext context) {
    final done = current >= target;
    return Row(mainAxisAlignment: MainAxisAlignment.center, children: <Widget>[
      Icon(done ? Icons.check_circle_rounded : icon,
        color: done ? const Color(0xFF67EAA0) : accent, size: 17),
      const SizedBox(width: 4),
      Flexible(child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(label, maxLines: 1, overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: Colors.white54, fontSize: 8,
              fontWeight: FontWeight.w900)),
          Text('${current.clamp(0, target)}/$target',
            style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w900)),
        ],
      )),
    ]);
  }
}
