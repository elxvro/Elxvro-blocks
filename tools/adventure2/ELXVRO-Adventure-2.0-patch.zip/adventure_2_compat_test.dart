import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:elxvro_blocks/app_state.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() => SharedPreferences.setMockInitialValues(<String, Object>{}));

  test('failed mission does not unlock the next level or award coins', () async {
    final app = AppState();
    await app.load();
    expect(app.adventureUnlockedLevel, 1);
    final earned = await app.completeAdventureLevel(
      level: 1, reward: 100, score: 30000, completed: false,
    );
    expect(earned, 0);
    expect(app.coins, 0);
    expect(app.isAdventureLevelCompleted(1), false);
    expect(app.isAdventureLevelUnlocked(2), false);
  });

  test('completing quest stores stars without double-paying coins', () async {
    final app = AppState();
    await app.load();
    final first = await app.completeAdventureLevel(
      level: 1, reward: 75, score: 900, completed: true, stars: 2,
    );
    expect(first, 75);
    expect(app.adventureStarsForLevel(1), 2);
    expect(app.adventureUnlockedLevel, 2);
    final repeat = await app.completeAdventureLevel(
      level: 1, reward: 75, score: 1400, completed: true, stars: 3,
    );
    expect(repeat, 0);
    expect(app.coins, 75);
    expect(app.adventureStarsForLevel(1), 3);
    final newSession = AppState();
    await newSession.load();
    expect(newSession.adventureStarsForLevel(1), 3);
    expect(newSession.coins, 75);
    expect(newSession.adventureUnlockedLevel, 2);
  });

  test('first completion stars use mission rating, not old score thresholds', () async {
    final app = AppState();
    await app.load();
    await app.completeAdventureLevel(
      level: 1, reward: 10, score: 50000, completed: true, stars: 1,
    );
    expect(app.adventureStarsForLevel(1), 1);
  });

  test('pre-2.0 saves retain completed levels, unlocks and coins', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{
      'adventure_unlocked_level': 15,
      'adventure_completed': <String>['1', '2', '10', '14'],
      'adventure_best_scores': <String>['1:5000', '2:3400', '10:60000'],
      'coins': 940,
      'theme_id': 'fire',
    });
    final app = AppState();
    await app.load();
    expect(app.adventureUnlockedLevel, 15);
    expect(app.adventureCompletedCount, 4);
    expect(app.adventureStarsForLevel(10), greaterThanOrEqualTo(1));
    expect(app.coins, 940);
    expect(app.themeId, 'fire');
  });

  test('theme implementation and other gameplay modes remain untouched', () {
    final gameplay = File('lib/screens/falling_blocks_screen.dart').readAsStringSync();
    final map = File('lib/screens/adventure_screen.dart').readAsStringSync();
    expect(gameplay, contains('AdventureMissionHud('));
    expect(gameplay, contains('AdventureResultDialog('));
    expect(gameplay, contains('AdventureSpecial.ice'));
    expect(gameplay, contains('AdventureQuestProgress('));
    expect(map, contains('PremiumBackground('));
    expect(map, contains('theme.backgroundTop'));
    expect(map, contains('theme.backgroundBottom'));
    expect(map, contains('theme.blockAccent'));
    expect(map, isNot(contains('app.themeId =')));
  });
}
