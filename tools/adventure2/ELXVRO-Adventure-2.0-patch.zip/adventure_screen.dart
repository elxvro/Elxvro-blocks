import 'package:flutter/material.dart';

import '../app_state.dart';
import '../game/adventure_quest.dart';
import '../l10n/app_strings.dart';
import '../models/adventure_level.dart';
import '../models/game_theme.dart';
import '../widgets/coin_badge.dart';
import '../widgets/premium_background.dart';
import 'falling_blocks_screen.dart';

/// Adventure 2.0 is deliberately theme-aware. It never changes appState.themeId.
class AdventureScreen extends StatefulWidget {
  const AdventureScreen({super.key, required this.appState});
  final AppState appState;

  @override
  State<AdventureScreen> createState() => _AdventureScreenState();
}

class _AdventureScreenState extends State<AdventureScreen> {
  int? _selectedWorld;
  static const _titlesTr = <String>[
    'Neon Şehir', 'Buz Vadisi', 'Zehirli Orman',
    'Lav Dağı', 'Uzay Üssü', 'Karanlık Boyut',
  ];
  static const _titlesEn = <String>[
    'Neon City', 'Ice Valley', 'Toxic Forest',
    'Lava Mountain', 'Space Station', 'Dark Dimension',
  ];
  static const _icons = <IconData>[
    Icons.location_city_rounded, Icons.ac_unit_rounded,
    Icons.forest_rounded, Icons.local_fire_department_rounded,
    Icons.rocket_launch_rounded, Icons.auto_awesome_rounded,
  ];
  static const _worldAccents = <Color>[
    Color(0xFFAB69FF), Color(0xFF67CFFF), Color(0xFF5BEFA0),
    Color(0xFFFF8569), Color(0xFF67B0FF), Color(0xFFE080FF),
  ];

  String _name(int world, String lang) =>
      lang == 'tr' ? _titlesTr[world] : _titlesEn[world];

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: widget.appState,
      builder: (context, _) {
        final app = widget.appState;
        final l = AppStrings(app.languageCode);
        final tr = app.languageCode == 'tr';
        final theme = gameThemes.firstWhere(
          (item) => item.id == app.themeId,
          orElse: () => gameThemes.first,
        );
        final accent = theme.blockAccent;
        final current = ((app.adventureUnlockedLevel - 1) ~/ 10).clamp(0, 5);
        final world = _selectedWorld ?? current;
        final unlocked = app.isAdventureLevelUnlocked(world * 10 + 1);
        final completed = app.adventureCompletedCount;
        return Scaffold(
          body: PremiumBackground(
            top: theme.backgroundTop,
            bottom: theme.backgroundBottom,
            material: theme.material,
            accent: accent,
            child: SafeArea(
              child: Column(children: <Widget>[
                Padding(
                  padding: const EdgeInsets.fromLTRB(8, 6, 14, 6),
                  child: Row(children: <Widget>[
                    IconButton(
                      onPressed: () => Navigator.of(context).pop(),
                      icon: const Icon(Icons.arrow_back_rounded),
                    ),
                    Expanded(child: Text(
                      l.t('adventure.title'),
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: accent, fontSize: 17,
                        fontWeight: FontWeight.w900, letterSpacing: 2.0,
                      ),
                    )),
                    CoinBadge(coins: app.coins, compact: true),
                  ]),
                ),
                Container(
                  margin: const EdgeInsets.fromLTRB(16, 4, 16, 12),
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 13),
                  decoration: BoxDecoration(
                    color: theme.board.withValues(alpha: .79),
                    borderRadius: BorderRadius.circular(19),
                    border: Border.all(color: accent.withValues(alpha: .27)),
                  ),
                  child: Column(children: <Widget>[
                    Row(children: <Widget>[
                      Icon(Icons.map_rounded, color: accent, size: 20),
                      const SizedBox(width: 8),
                      Expanded(child: Text(
                        tr ? 'MACERA 2.0  •  6 DÜNYA' : 'ADVENTURE 2.0  •  6 WORLDS',
                        style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 12),
                      )),
                      Text('$completed/60', style: TextStyle(
                        fontWeight: FontWeight.w900, color: accent,
                      )),
                    ]),
                    const SizedBox(height: 9),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(20),
                      child: LinearProgressIndicator(
                        minHeight: 6, value: completed / 60,
                        backgroundColor: Colors.white10,
                        valueColor: AlwaysStoppedAnimation<Color>(accent),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(children: <Widget>[
                      Icon(Icons.star_rounded, size: 16, color: Colors.amber.shade300),
                      const SizedBox(width: 3),
                      Text('${app.adventureTotalStars}/180',
                          style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold)),
                      const Spacer(),
                      Text(tr ? 'Dünya seç, göreve başla' : 'Choose a world and begin',
                          style: const TextStyle(color: Colors.white54, fontSize: 10)),
                    ]),
                  ]),
                ),
                SizedBox(
                  height: 120,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: 6,
                    separatorBuilder: (_, _) => const SizedBox(width: 9),
                    itemBuilder: (context, index) {
                      final open = app.isAdventureLevelUnlocked(index * 10 + 1);
                      final selected = index == world;
                      final tone = Color.lerp(_worldAccents[index], accent, .27)!;
                      return Semantics(
                        button: true,
                        label: '${index + 1}. ${_name(index, app.languageCode)}',
                        child: InkWell(
                          onTap: () => setState(() => _selectedWorld = index),
                          borderRadius: BorderRadius.circular(20),
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 200),
                            width: 147, padding: const EdgeInsets.all(11),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(
                                color: selected ? tone : Colors.white12,
                                width: selected ? 1.8 : 1,
                              ),
                              gradient: LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: <Color>[
                                  Color.lerp(theme.board, tone, selected ? .43 : .19)!,
                                  theme.board,
                                ],
                              ),
                            ),
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Row(children: <Widget>[
                                  Icon(_icons[index], color: open ? tone : Colors.white30, size: 28),
                                  const Spacer(),
                                  Icon(open ? Icons.explore_rounded : Icons.lock_rounded,
                                    color: open ? tone : Colors.white30, size: 15),
                                ]),
                                const Spacer(),
                                Text(_name(index, app.languageCode),
                                  maxLines: 1, overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 12)),
                                const SizedBox(height: 3),
                                Text('${index * 10 + 1}–${index * 10 + 10}',
                                  style: TextStyle(color: tone, fontWeight: FontWeight.w800, fontSize: 10)),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 14, 20, 8),
                  child: Row(children: <Widget>[
                    Icon(_icons[world], color: Color.lerp(_worldAccents[world], accent, .27)),
                    const SizedBox(width: 9),
                    Expanded(child: Text('${world + 1}. ${_name(world, app.languageCode)}',
                      style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w900))),
                    if (!unlocked)
                      const Icon(Icons.lock_rounded, color: Colors.white38, size: 20),
                  ]),
                ),
                if (!unlocked)
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
                    child: Text(tr
                        ? 'Önce önceki dünyanın boss bölümünü tamamla.'
                        : 'Defeat the previous world boss to unlock this world.',
                      style: const TextStyle(color: Colors.white60, fontSize: 11)),
                  ),
                Expanded(child: GridView.builder(
                  key: ValueKey<int>(world),
                  padding: const EdgeInsets.fromLTRB(18, 8, 18, 20),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 5, crossAxisSpacing: 8, mainAxisSpacing: 14,
                    childAspectRatio: .76,
                  ),
                  itemCount: 10,
                  itemBuilder: (context, idx) {
                    final number = world * 10 + idx + 1;
                    final level = adventureLevelFor(number);
                    final open = app.isAdventureLevelUnlocked(number);
                    final stars = app.adventureStarsForLevel(number);
                    final boss = number % 10 == 0;
                    final tone = Color.lerp(_worldAccents[world], accent, .27)!;
                    return InkWell(
                      onTap: open ? () async {
                        await Navigator.of(context).push(MaterialPageRoute<void>(
                          builder: (_) => FallingBlocksScreen(
                            appState: app, adventureLevel: level,
                          ),
                        ));
                      } : null,
                      borderRadius: BorderRadius.circular(16),
                      child: Column(children: <Widget>[
                        Expanded(child: Container(
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(colors: <Color>[
                              Color.lerp(theme.board, boss ? Colors.redAccent : tone, open ? .48 : .12)!,
                              theme.board,
                            ]),
                            borderRadius: BorderRadius.circular(15),
                            border: Border.all(color: open ?
                              (stars > 0 ? tone : tone.withValues(alpha: .46)) : Colors.white10),
                            boxShadow: stars > 0 ? <BoxShadow>[
                              BoxShadow(color: tone.withValues(alpha: .16), blurRadius: 10),
                            ] : null,
                          ),
                          child: open ? (boss
                            ? Icon(Icons.shield_rounded, color: tone, size: 28)
                            : Text('$number', style: const TextStyle(fontSize: 18,
                                fontWeight: FontWeight.w900)))
                            : const Icon(Icons.lock_rounded, color: Colors.white24, size: 20),
                        )),
                        const SizedBox(height: 4),
                        if (open) Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: List<Widget>.generate(3, (i) => Icon(
                            i < stars ? Icons.star_rounded : Icons.star_border_rounded,
                            size: 13,
                            color: i < stars ? Colors.amberAccent : Colors.white30,
                          )),
                        ) else const SizedBox(height: 13),
                      ]),
                    );
                  },
                )),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
                  child: Row(children: <Widget>[
                    Expanded(child: Text(
                      tr ? '★ Yıldız topla • Her 10. bölümde boss' :
                        '★ Collect stars • Boss at every level 10',
                      style: const TextStyle(color: Colors.white54, fontSize: 10),
                    )),
                    Icon(Icons.bolt_rounded, color: accent, size: 17),
                    Text(tr ? '60 BÖLÜM' : '60 LEVELS',
                      style: TextStyle(color: accent, fontWeight: FontWeight.bold, fontSize: 10)),
                  ]),
                ),
              ]),
            ),
          ),
        );
      },
    );
  }
}
