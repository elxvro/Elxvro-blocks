/// New Adventure mission rules. No colors, theme IDs, or unrelated modes here.
/// Negative board values are empty; 0–6 are the existing themed block colors.
class AdventureSpecial {
  static const int ice = 7;
  static const int crystal = 8;
  static const int stone = 9;
}

enum AdventureGoalKind { lines, ice, crystals, stones, combos, boss }

class AdventureMission {
  const AdventureMission({
    required this.level,
    required this.linesTarget,
    required this.scoreForStar,
    this.specialKind,
    this.specialTarget = 0,
    this.comboTarget = 0,
    this.bossMaxHealth = 0,
  });
  final int level;
  final int linesTarget;
  final int scoreForStar;
  final AdventureGoalKind? specialKind;
  final int specialTarget;
  final int comboTarget;
  final int bossMaxHealth;

  int get world => ((level - 1) ~/ 10).clamp(0, 5);
  bool get isBoss => level % 10 == 0;
  int? get specialCode => switch (specialKind) {
    AdventureGoalKind.ice => AdventureSpecial.ice,
    AdventureGoalKind.crystals => AdventureSpecial.crystal,
    AdventureGoalKind.stones => AdventureSpecial.stone,
    _ => null,
  };

  static AdventureMission forLevel(int number) {
    final n = number.clamp(1, 60).toInt();
    final world = (n - 1) ~/ 10;
    final stage = (n - 1) % 10;
    final boss = stage == 9;
    final special = switch (world) {
      1 => AdventureGoalKind.ice,
      2 => AdventureGoalKind.crystals,
      3 => AdventureGoalKind.stones,
      5 => AdventureGoalKind.crystals,
      _ => null,
    };
    return AdventureMission(
      level: n,
      linesTarget: (3 + world + stage ~/ 4).clamp(3, 9).toInt(),
      scoreForStar: 600 + world * 1050 + stage * 260,
      specialKind: special,
      specialTarget: special == null ? 0 : 2 + stage ~/ 4,
      comboTarget: world == 4 ? (stage >= 5 ? 3 : 2) : 0,
      bossMaxHealth: boss ? 500 + world * 90 : 0,
    );
  }
}

class AdventureQuestProgress {
  AdventureQuestProgress(this.mission) : bossHealth = mission.bossMaxHealth;
  final AdventureMission mission;
  int lines = 0;
  int specialCollected = 0;
  int maxCombo = 0;
  int bossHealth;

  void onClearedRows({
    required int count,
    required Iterable<int> removedCells,
    required int combo,
  }) {
    if (count <= 0) return;
    lines += count;
    if (combo > maxCombo) maxCombo = combo;
    final match = mission.specialCode;
    if (match != null) {
      specialCollected += removedCells.where((v) => v == match).length;
    }
    if (mission.isBoss) {
      final damage = count * 170 + (combo > 1 ? (combo - 1) * 45 : 0);
      bossHealth = (bossHealth - damage).clamp(0, mission.bossMaxHealth).toInt();
    }
  }

  bool get completed =>
      lines >= mission.linesTarget &&
      specialCollected >= mission.specialTarget &&
      maxCombo >= mission.comboTarget &&
      bossHealth == 0;

  int earnedStars(int score) {
    if (!completed) return 0;
    if (score >= (mission.scoreForStar * 1.45).round() ||
        maxCombo >= 4) return 3;
    if (score >= mission.scoreForStar || maxCombo >= 2) return 2;
    return 1;
  }
}
