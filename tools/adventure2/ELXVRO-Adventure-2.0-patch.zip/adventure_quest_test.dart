import 'package:flutter_test/flutter_test.dart';
import 'package:elxvro_blocks/game/adventure_quest.dart';

void main() {
  test('60 missions preserve 6 worlds and distinct boss encounters', () {
    for (var n = 1; n <= 60; n++) {
      final mission = AdventureMission.forLevel(n);
      expect(mission.level, n);
      expect(mission.world, (n - 1) ~/ 10);
      expect(mission.linesTarget, greaterThan(0));
      expect(mission.isBoss, n % 10 == 0);
      expect(mission.bossMaxHealth > 0, n % 10 == 0);
    }
  });

  test('Neon city clears three rows to complete first quest', () {
    final progress = AdventureQuestProgress(AdventureMission.forLevel(1));
    expect(progress.completed, isFalse);
    progress.onClearedRows(count: 2, removedCells: const <int>[], combo: 1);
    expect(progress.completed, isFalse);
    progress.onClearedRows(count: 1, removedCells: const <int>[], combo: 2);
    expect(progress.completed, isTrue);
    expect(progress.earnedStars(0), 2);
  });

  test('ice world counts only ice cells in lines actually cleared', () {
    final quest = AdventureMission.forLevel(11);
    expect(quest.specialCode, AdventureSpecial.ice);
    final progress = AdventureQuestProgress(quest);
    progress.onClearedRows(
      count: quest.linesTarget,
      removedCells: <int>[AdventureSpecial.crystal, AdventureSpecial.ice],
      combo: 1,
    );
    expect(progress.completed, isFalse);
    progress.onClearedRows(
      count: 1,
      removedCells: <int>[AdventureSpecial.ice, AdventureSpecial.ice],
      combo: 1,
    );
    expect(progress.completed, isTrue);
  });

  test('boss must lose all health and line target must also be reached', () {
    final mission = AdventureMission.forLevel(10);
    final progress = AdventureQuestProgress(mission);
    expect(mission.bossMaxHealth, greaterThan(0));
    progress.onClearedRows(count: 1, removedCells: const <int>[], combo: 1);
    expect(progress.bossHealth, lessThan(mission.bossMaxHealth));
    expect(progress.completed, isFalse);
    progress.onClearedRows(
      count: mission.linesTarget + 5,
      removedCells: const <int>[],
      combo: 3,
    );
    expect(progress.bossHealth, 0);
    expect(progress.completed, isTrue);
    expect(progress.earnedStars(100000), 3);
  });

  test('failing a mission gives zero stars and never completes', () {
    final run = AdventureQuestProgress(AdventureMission.forLevel(43));
    expect(run.earnedStars(9999999), 0);
  });
}
