#!/usr/bin/env python3
"""Migrate ELXVRO Blocks v0.30.1 to Adventure 2.0 without changing theme assets.

This patch only adjusts the existing adventure gameplay and AppState.
New world UI, quest and reward widgets are copied separately.
"""
from pathlib import Path
import sys

root = Path(sys.argv[1] if len(sys.argv)>1 else 'extracted/elxvro-blocks')

def replace(s,a,b,label):
    if s.count(a)!=1: raise RuntimeError(f'{label}: expected one source anchor; got {s.count(a)}')
    return s.replace(a,b,1)

p=root/'lib/app_state.dart';s=p.read_text()
s=replace(s, "  static const String _adventureBestScoresKey = 'adventure_best_scores';",
'''  static const String _adventureBestScoresKey = 'adventure_best_scores';
  // New stars are stored separately; older completion data is never overwritten.
  static const String _adventureStarsV2Key = 'adventure_stars_v2';''','star key')
s=replace(s,'  final Map<int, int> _adventureBestScores = <int, int>{};',
'''  final Map<int, int> _adventureBestScores = <int, int>{};
  final Map<int, int> _adventureStarsV2 = <int, int>{};''','star map')
s=replace(s,'      final savedAdventureLevel =',
'''      _adventureStarsV2.clear();
      for (final raw in prefs.getStringList(_adventureStarsV2Key) ?? const <String>[]) {
        final parts = raw.split(':');
        if (parts.length != 2) continue;
        final level = int.tryParse(parts[0]);
        final stars = int.tryParse(parts[1]);
        if (level != null && stars != null && _adventureCompleted.contains(level)) {
          _adventureStarsV2[level] = stars.clamp(1, 3).toInt();
        }
      }
      final savedAdventureLevel =''','load stars')
s=replace(s,'''    final target = adventureLevelFor(level).targetScore;
    final score = adventureBestScoreForLevel(level);''',
'''    final stored = _adventureStarsV2[level];
    if (stored != null) return stored;
    // Preserve pre-2.0 stars for all previously completed levels.
    final target = adventureLevelFor(level).targetScore;
    final score = adventureBestScoreForLevel(level);''','read stars')
s=replace(s,'''    bool completed = true,
  }) async {
    if (level < 1 || level > 60)''',
'''    bool completed = true,
    int? stars,
  }) async {
    if (level < 1 || level > 60)''','new star argument')
s=replace(s,'''    final firstCompletion = completed && _adventureCompleted.add(level);''',
'''    // Capture old stars before mutating the completion set.
    final previousStars = adventureStarsForLevel(level);
    final firstCompletion = completed && _adventureCompleted.add(level);''','prior completion stars')
s=replace(s,'''    if (level >= adventureUnlockedLevel && adventureUnlockedLevel < 60) {
      adventureUnlockedLevel = level + 1;
    }

    final earned = firstCompletion ? reward : 0;''',
'''    if (completed && stars != null) {
      final bestStars = stars > previousStars ? stars : previousStars;
      _adventureStarsV2[level] = bestStars.clamp(1, 3).toInt();
    }
    // Failing must not unlock another level. Keep historical user progress.
    if (completed && level >= adventureUnlockedLevel && adventureUnlockedLevel < 60) {
      adventureUnlockedLevel = level + 1;
    }

    final earned = firstCompletion ? reward : 0;''','success-only unlock')
s=replace(s,'''      if (earned > 0) {
        await prefs.setInt(_coinsKey, coins);
      }
    } catch (error) {
      debugPrint('ELXVRO adventure tournament save failed: $error');''',
'''      if (stars != null && _adventureCompleted.contains(level)) {
        final starLevels = _adventureStarsV2.keys.toList()..sort();
        await prefs.setStringList(
          _adventureStarsV2Key,
          starLevels.map((n) => '$n:${_adventureStarsV2[n]}').toList(),
        );
      }
      if (earned > 0) {
        await prefs.setInt(_coinsKey, coins);
      }
    } catch (error) {
      debugPrint('ELXVRO adventure tournament save failed: $error');''','persist stars')
p.write_text(s)

p=root/'lib/screens/falling_blocks_screen.dart';s=p.read_text()
s=replace(s,"import '../game/drag_step_accumulator.dart';",
'''import '../game/drag_step_accumulator.dart';
import '../game/adventure_quest.dart';
import '../widgets/adventure_mission_hud.dart';
import '../widgets/adventure_result_dialog.dart';''','adventure imports')
s=replace(s,'  int _riseTicks = 0;',
'''  int _riseTicks = 0;
  AdventureQuestProgress? _quest;''','quest state')
s=replace(s,'''    _riseTicks = 0;
    _locking = false;''',
'''    _riseTicks = 0;
    _quest = _isAdventure
        ? AdventureQuestProgress(AdventureMission.forLevel(widget.adventureLevel!.number))
        : null;
    _locking = false;''','quest reset')
s=replace(s,'''        _board[row][col] = col == gap ? -1 : _random.nextInt(7);''',
'''        _board[row][col] = (col == gap || _random.nextInt(4) == 0)
            ? -1 : _randomAdventureCell(col, gap);''',
 'seed specials')
s=replace(s,'  _FallingPiece _randomPiece() {',
'''  int _randomAdventureCell(int col, int hole) {
    if (col == hole) return -1;
    final code = _quest?.mission.specialCode;
    if (code != null && _random.nextInt(5) == 0) return code;
    return _random.nextInt(7);
  }

  _FallingPiece _randomPiece() {''','special generator')
# quest created before seed - ensure correct order
s=replace(s,'''    _board = List<List<int>>.generate(
      _rows,
      (_) => List<int>.filled(_cols, -1),
    );
    if (_isAdventure) {
      _seedAdventureBoard();
    }
    _piece =''',
'''    _quest = _isAdventure
        ? AdventureQuestProgress(AdventureMission.forLevel(widget.adventureLevel!.number))
        : null;
    _board = List<List<int>>.generate(
      _rows,
      (_) => List<int>.filled(_cols, -1),
    );
    if (_isAdventure) {
      _seedAdventureBoard();
    }
    _piece =''','initialize mission before seed')
# remove duplicate reassignment after seed
s=replace(s,'''    _riseTicks = 0;
    _quest = _isAdventure
        ? AdventureQuestProgress(AdventureMission.forLevel(widget.adventureLevel!.number))
        : null;
    _locking = false;''', '''    _riseTicks = 0;
    _locking = false;''','avoid second quest assignment')
s=replace(s,'''          const limit = 8;
          if (_riseTicks >= limit) {''',
'''          final limit = _quest!.mission.isBoss ? 14 : 22;
          if (_riseTicks >= limit) {''','boss aggression')
s=replace(s,'''    final incoming = List<int>.generate(
      _cols, (col) => col == hole ? -1 : _random.nextInt(7),
    );''',
'''    final incoming = List<int>.generate(
      _cols, (col) => (col == hole || _random.nextInt(4) == 0)
          ? -1 : _randomAdventureCell(col, hole),
    );''','special rise')
s=replace(s,'''    if (cleared.isNotEmpty) {
      _emitImpact(''',
'''    if (cleared.isNotEmpty) {
      final clearedCells = <int>[
        for (final r in cleared) ..._board[r],
      ];
      _emitImpact(''','capture special cells')
s=replace(s,'''      _score += base * _difficultyLevel + comboBonus;

      unawaited(''',
'''      _score += base * _difficultyLevel + comboBonus;
      if (_quest != null) {
        _quest!.onClearedRows(
          count: cleared.length,
          removedCells: clearedCells,
          combo: _combo,
        );
      }

      unawaited(''','quest progress')
s=replace(s,'''    _piece = _nextPiece;
    _nextPiece = _randomPiece();''',
'''    if (_quest?.completed == true) {
      _locking = false;
      await _finish(success: true);
      return;
    }

    _piece = _nextPiece;
    _nextPiece = _randomPiece();''','victory early completion')
s=replace(s,'''    // Endless mode ends on defeat; a high score qualifies as completion.
    final completed = _isAdventure
        ? _score >= widget.adventureLevel!.targetScore
        : success;

    if (_isAdventure) {''',
'''    // Mission objectives, not endless score, determine Adventure victory.
    final completed = _isAdventure ? success && _quest!.completed : success;
    final stars = completed && _isAdventure ? _quest!.earnedStars(_score) : 0;
    var earnedCoins = 0;

    if (_isAdventure) {''','victory condition')
s=replace(s,'''      await widget.appState.completeAdventureLevel(
        level: level.number,
        reward: completed ? level.reward : 0,
        score: _score,
        completed: completed,
      );''',
'''      earnedCoins = await widget.appState.completeAdventureLevel(
        level: level.number,
        reward: completed ? level.reward : 0,
        score: _score,
        completed: completed,
        stars: completed ? stars : null,
      );''','persist stars')
# Insert distinct reward UI for only Adventure; never alter arcade results.
s=replace(s,'''    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {''',
'''    if (_isAdventure) {
      final level = widget.adventureLevel!;
      final canGoNext = completed && level.number < adventureLevelCount;
      await showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) => AdventureResultDialog(
          progress: _quest!,
          success: completed,
          stars: stars,
          score: _score,
          earnedCoins: earnedCoins,
          accent: _theme.blockAccent,
          surface: _theme.board,
          turkish: widget.appState.languageCode == 'tr',
          canGoNext: canGoNext,
          onMap: () {
            Navigator.of(dialogContext).pop();
            Navigator.of(context).pop();
          },
          onRetry: () {
            Navigator.of(dialogContext).pop();
            setState(_reset);
          },
          onNext: () {
            Navigator.of(dialogContext).pop();
            Navigator.of(context).pushReplacement(MaterialPageRoute<void>(
              builder: (_) => FallingBlocksScreen(
                appState: widget.appState,
                adventureLevel: adventureLevelFor(level.number + 1),
              ),
            ));
          },
        ),
      );
      return;
    }

    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {''','Adventure result dialog')
s=replace(s,'''              Expanded(
                child: LayoutBuilder(''',
'''              if (_quest != null)
                AdventureMissionHud(
                  progress: _quest!,
                  accent: levelAccent,
                  surface: _theme.board,
                  turkish: widget.appState.languageCode == 'tr',
                ),
              Expanded(
                child: LayoutBuilder(''','mission hud')
s=replace(s,'''                              final displayIndex = colorIndex;
                              final base = palette[displayIndex % palette.length];''',
'''                              final displayIndex = colorIndex;
                              final base = palette[displayIndex % palette.length];''','tile marker check') if False else s
s=replace(s,'''                              return tile;
                            },
                          ),''',
'''                              if (_isAdventure && fixedColor >= AdventureSpecial.ice) {
                                final marker = switch (fixedColor) {
                                  AdventureSpecial.ice => Icons.ac_unit_rounded,
                                  AdventureSpecial.crystal => Icons.diamond_rounded,
                                  _ => Icons.hexagon_rounded,
                                };
                                return Stack(fit: StackFit.expand, children: <Widget>[
                                  tile,
                                  Center(child: Icon(marker, size: 14,
                                    color: Colors.white.withValues(alpha: .94))),
                                ]);
                              }
                              return tile;
                            },
                          ),''','special board visuals')
p.write_text(s)

# The old regression expected level unlock on failure, now intentionally forbidden.
p = root/'test/adventure_stability_test.dart'
s = p.read_text()
s = replace(s, "test('loss unlocks next stage without completion stars or coins'", "test('loss keeps next stage locked with no stars or coins'", 'legacy failure test title')
s = s.replace('expect(state.adventureUnlockedLevel, 2);', 'expect(state.adventureUnlockedLevel, 1);', 1)
s = s.replace('expect(reloaded.adventureUnlockedLevel, 2);', 'expect(reloaded.adventureUnlockedLevel, 1);', 1)
p.write_text(s)

p=root/'pubspec.yaml';s=p.read_text()
s=replace(s,'version: 0.30.1+75','version: 0.31.0+76','version bump')
p.write_text(s)
for path in (root/'test').glob('*.dart'):
    old=path.read_text()
    new=old.replace('version: 0.30.1+75', 'version: 0.31.0+76')
    if old!=new: path.write_text(new)
print('Adventure 2.0 integrated into existing ELXVRO theme without asset/theme changes.')
