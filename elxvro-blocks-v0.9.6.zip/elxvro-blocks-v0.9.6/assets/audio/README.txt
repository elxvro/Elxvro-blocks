ELXVRO Blocks v0.9.6 audio assets

All audio in this package is generated specifically for ELXVRO Blocks from synthesized waveforms/noise. No third-party song, recording, sample pack, or copyrighted music recording is included.

v0.9.6 audio refresh:
- ambient_loop.wav: new calm original ambient loop (Sakin Akış)
- ui_tap_v1..v3.wav: soft non-keypad UI taps
- record_fanfare.wav: personal-record celebration fanfare
- reward.wav: positive reward cue
- game_over.wav: neutral soft ending cue
- *_clear_v1..v3.wav: lower-fatigue theme clear variations
- *_combo.wav: musical combo cues
- *_perfect.wav: premium Perfect Clear cues
