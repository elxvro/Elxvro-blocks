import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

void main() {
  test('v0.9.6 audio refresh assets are present', () {
    const required = <String>[
      'assets/audio/ambient_loop.wav',
      'assets/audio/ui_tap_v1.wav',
      'assets/audio/ui_tap_v2.wav',
      'assets/audio/ui_tap_v3.wav',
      'assets/audio/record_fanfare.wav',
      'assets/audio/reward.wav',
      'assets/audio/game_over.wav',
    ];

    for (final path in required) {
      expect(File(path).existsSync(), isTrue, reason: 'Missing $path');
      expect(File(path).lengthSync(), greaterThan(1000), reason: 'Empty $path');
    }
  });
}
