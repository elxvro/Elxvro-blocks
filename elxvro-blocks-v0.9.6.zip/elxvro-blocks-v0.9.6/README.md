# ELXVRO Blocks v0.9.6 — Audio Experience Refresh

Bu sürüm ses deneyimini baştan dengeler. Amaç uzun oyun oturumlarında yorucu tekrarları azaltmak ve önemli anları daha heyecanlı hale getirmektir.

## Yenilikler

- Yeni özgün **Sakin Akış** ambient arka plan müziği.
- Oyun efektlerinin varsayılan seviyesi `%82`, müzik `%34`, arayüz sesleri `%72`.
- Arayüz sesleri oyun efektlerinden ayrıldı.
- Telefon tuşu benzeri eski click yerine üç farklı yumuşak dokunuş sesi kullanılıyor.
- Ayarlara **Arayüz Sesleri** aç/kapat ve ayrı ses seviyesi eklendi.
- Cam / Dal / Taş / Yaprak / Kristal / Mermer temizleme sesleri yeniden üretildi; patlama karakteri azaltıldı.
- Combo sesleri daha müzikal ve yükselen bir yapıya geçirildi.
- Perfect Clear sesleri daha ödüllendirici fakat daha yumuşak hale getirildi.
- Yeni kişisel rekor için özel `record_fanfare.wav` kutlama sesi eklendi.
- Yeni rekor ekranında konfeti ve `🎉 🎊 🎁` kutlama animasyonu eklendi.
- Challenge başarısında nötr game-over yerine ödül sesi kullanılıyor.
- Düşük gecikmeli AudioPool altyapısı korunuyor.

## Sürüm

- Flutter package: `0.9.6+20`
- Android package: `com.elxvro.elxvro_blocks`

## GitHub ZIP

Repo köküne şu dosyayı yükleyin:

`elxvro-blocks-v0.9.6.zip`

Workflow dosyası ZIP içinde `.github/workflows/build-apk.yml` altında da bulunur.
