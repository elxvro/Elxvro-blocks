# ELXVRO Blocks v0.9.3 — Material Theme Refresh

Bu sürümde tema sistemi yalnızca renk ve ses değiştiren yapıdan çıkarıldı. Her tema artık blok silüeti, yüzey dokusu ve oyun arka planı ile kendi malzemesini görsel olarak temsil eder. v0.9.2 ses motoru düzeltmeleri korunur.

## Görsel olarak ayrışan temalar

- **Cam** — yarı saydam/frosted yüzey, çift cam kenarı, parlama çizgileri ve kabarcık detayları; arka planda cam panel çizgileri.
- **Dal** — sıcak ahşap gövde, belirgin damarlar, budak halkası ve dal çizgileri; arka planda ahşap damarları ve dal motifi.
- **Taş** — köşeleri kırılmış kaya silüeti, çatlaklar, granül noktalar ve ağır taş yüzeyi; arka planda taş duvar örgüsü.
- **Yaprak** — kare yerine yaprak silüeti, ana damar ve yan damarlar; arka planda yaprak damarları ve yaprak gölgeleri.
- **Kristal** — altıgen/fasetli kristal silüeti, farklı ışık yüzleri ve keskin kenarlar; arka planda kırınım/faset çizgileri.
- **Mermer Altın** — mermer plaka görünümü, koyu damarlar ve altın damar/çerçeve; arka planda mermer damar akışı.

Tema seçildiğinde ana menü, tema ekranı ve oyun ekranındaki arka plan motifi de seçili malzemeye dönüşür. Parça önizlemeleri ve tahtadaki dolu hücreler aynı materyal renderer'ını kullanır.

## Ses motoru

v0.9.2 ile gelen AudioPool tabanlı düşük gecikmeli efekt sistemi, tema bazlı sesler ve optimize edilmiş müzik katmanı korunur.

## Sürüm

- Flutter package version: `0.9.3+17`
- Android package: `com.elxvro.elxvro_blocks`
- Build çıktıları: APK + AAB + debug symbols + SHA-256

## GitHub dosya adı

Repo kökünde:

```text
elxvro-blocks-v0.9.3.zip
```

bulunmalıdır.

## Test sırası

1. Cam temasında blokların gerçekten cam yüzey ve yansıma gösterdiğini kontrol et.
2. Dal temasında damar/budak, Taş temasında kırık köşe/çatlak farkını kontrol et.
3. Yaprak temasında blok hücrelerinin yaprak silüetine dönüştüğünü kontrol et.
4. Kristal temasında faceted geometriyi, Mermer Altın temasında damar ve altın çerçeveyi kontrol et.
5. Tema değiştirince ana menü ve oyun arka planının da görsel motif değiştirdiğini doğrula.
6. Ses/müzik açıkken performansı en az 10 dakika kontrol et.
