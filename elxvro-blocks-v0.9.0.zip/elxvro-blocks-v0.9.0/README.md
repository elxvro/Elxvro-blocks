# ELXVRO Blocks v0.9.0 — Release Candidate

Bu sürüm yeni büyük oyun mekaniği eklemek yerine v0.8.0 tabanını Play Store öncesi sağlamlaştırır.

## Release Candidate değişiklikleri

- Uygulama arka plana geçtiğinde müzik otomatik duraklatılır; dönüşte güvenli biçimde devam eder.
- Oyun arka plana geçtiğinde süreli mod sayacı durur. Oyuna geri dönüldüğünde pause menüsü açılır; arka planda süre kaybı olmaz.
- Arka plandan dönüş anında blok bırakma, Geri Al, Yenile ve Özel blok işlemleri kilitlenerek yarış durumları azaltılır.
- Günlük görev, günlük challenge ve haftalık lig tarihleri uygulama yeniden açılmadan da resume sırasında yenilenir.
- Ses efektlerinde aynı anda çalışan geçici player sayısı sınırlandı; hızlı dokunmalarda gereksiz audio player birikimi azaltıldı.
- Yakalanmamış Flutter/async hataları için üst seviye hata koruması eklendi; mevcut güvenli hata ekranı korunuyor.
- Sürüm: `0.9.0+14`.
- Paket kimliği: `com.elxvro.elxvro_blocks`.
- Siyah/altın ikon, adaptive icon, native splash, ses/müzik sistemi ve önceki tüm oyun özellikleri korunuyor.

## Release build

GitHub Actions artık iki ana çıktı üretir:

- `ELXVRO-Blocks-v0.9.0.apk` — cihaz testi için.
- `ELXVRO-Blocks-v0.9.0.aab` — Play Console paketi için.

Ayrıca obfuscation sembolleri ve SHA-256 dosyası artifact içine eklenir:

- `ELXVRO-Blocks-v0.9.0-symbols.zip`
- `ELXVRO-Blocks-v0.9.0-SHA256.txt`
- `release-signing-status.txt`

## Release signing hazırlığı

Workflow aşağıdaki GitHub Actions Secrets değerlerinin tamamı mevcutsa release keystore kullanır:

- `ELXVRO_KEYSTORE_BASE64`
- `ELXVRO_KEYSTORE_PASSWORD`
- `ELXVRO_KEY_ALIAS`
- `ELXVRO_KEY_PASSWORD`

Bu secret'lar tanımlı değilse build yine APK/AAB üretir fakat Flutter'ın debug-signing fallback'i kullanılır. Bu durumda oluşan AAB yalnızca test içindir ve production Play Store yayınına yüklenmemelidir. Artifact içindeki `release-signing-status.txt` hangi durumun kullanıldığını açıkça yazar.

## GitHub Actions akışı

Repo kökünde `elxvro-blocks-v0.9.0.zip` bulunmalı. Workflow sırasıyla:

1. ZIP bütünlüğünü kontrol eder ve projeyi açar.
2. Flutter Android platformunu `com.elxvro.elxvro_blocks` kimliğiyle üretir.
3. Android marka/portre ayarlarını uygular.
4. Varsa GitHub Secrets üzerinden release signing'i kurar.
5. Paketleri yükler; launcher icon ve native splash üretir.
6. `flutter analyze` ve `flutter test` çalıştırır.
7. Obfuscation + split debug info ile release APK üretir.
8. Obfuscation + split debug info ile release AAB üretir.
9. APK/AAB varlığını doğrular, SHA-256 üretir ve sembolleri paketler.
10. Hepsini `ELXVRO-Blocks-v0.9.0` artifact'ı olarak yükler.

## v0.9.0 test planı

- Klasik modda 10–15 dakika normal oyun.
- 2 Dakika modunda oyunu arka plana alıp geri dön; süre arka planda ilerlememeli ve pause menüsü açılmalı.
- Oyun sırasında ekranı kapat/aç; blok sürükleme ve güç butonları düzgün devam etmeli.
- Müzik açıkken uygulamayı arka plana al; müzik durmalı, geri dönüşte devam etmeli.
- Gece yarısı / yeni gün senaryosunda günlük görev ve challenge ekranlarını kontrol et.
- Geri Al, Yenile ve Özel blok butonlarına hızlı art arda dokunarak çift işlem olmadığını kontrol et.
- Farklı ekran oranlarında ana menü, oyun tahtası, mağaza, profil, ayarlar ve challenge ekranlarını kontrol et.
- APK'yı gerçek cihazda kurup en az bir uzun oyun oturumu yap.
- Play Store öncesi AAB için `release-signing-status.txt` dosyasında release keystore yapılandırıldığını doğrula.

Not: Bu çalışma ortamında Flutter SDK bulunmadığı için kesin `flutter analyze`, `flutter test`, APK ve AAB derleme doğrulamasını GitHub Actions yapacaktır.
