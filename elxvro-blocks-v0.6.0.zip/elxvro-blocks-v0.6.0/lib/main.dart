import 'dart:async';

import 'package:flutter/material.dart';

import 'app_state.dart';
import 'screens/home_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  // Show the Flutter UI immediately. Persistent storage is loaded after the
  // first frame so a storage/plugin problem can never leave the app on a
  // blank launch screen.
  final appState = AppState();

  ErrorWidget.builder = (FlutterErrorDetails details) {
    return const Material(
      color: Color(0xFF050505),
      child: SafeArea(
        child: Center(
          child: Padding(
            padding: EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Icon(
                  Icons.warning_amber_rounded,
                  color: Color(0xFFFFC86E),
                  size: 42,
                ),
                SizedBox(height: 14),
                Text(
                  'ELXVRO Blocks',
                  style: TextStyle(
                    color: Color(0xFFFFD99A),
                    fontSize: 24,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 2,
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  'Arayüz yüklenirken bir sorun oluştu.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white70),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  };

  runApp(ElxvroBlocksApp(appState: appState));
  unawaited(appState.load());
}

class ElxvroBlocksApp extends StatelessWidget {
  const ElxvroBlocksApp({super.key, required this.appState});

  final AppState appState;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: appState,
      builder: (context, _) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'ELXVRO Blocks',
          theme: ThemeData(
            brightness: Brightness.dark,
            scaffoldBackgroundColor: const Color(0xFF050505),
            colorScheme: ColorScheme.fromSeed(
              seedColor: const Color(0xFFD79A4B),
              brightness: Brightness.dark,
            ),
            useMaterial3: true,
          ),
          home: HomeScreen(appState: appState),
        );
      },
    );
  }
}
