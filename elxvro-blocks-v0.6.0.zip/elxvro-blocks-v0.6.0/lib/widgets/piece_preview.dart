import 'package:flutter/material.dart';

import '../models/block_piece.dart';

class PiecePreview extends StatelessWidget {
  const PiecePreview({
    super.key,
    required this.piece,
    required this.color,
    required this.accent,
    this.cellSize = 24,
    this.dimmed = false,
  });

  final BlockPiece piece;
  final Color color;
  final Color accent;
  final double cellSize;
  final bool dimmed;

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: dimmed ? 0.18 : 1,
      child: SizedBox(
        width: piece.cols * cellSize,
        height: piece.rows * cellSize,
        child: Stack(
          children: piece.cells.map((cell) {
            return Positioned(
              left: cell.col * cellSize,
              top: cell.row * cellSize,
              child: Container(
                width: cellSize - 2,
                height: cellSize - 2,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(cellSize * 0.14),
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: <Color>[
                      accent.withValues(alpha: 0.96),
                      color,
                    ],
                  ),
                  border: Border.all(
                    color: accent.withValues(alpha: 0.65),
                    width: 0.8,
                  ),
                  boxShadow: <BoxShadow>[
                    BoxShadow(
                      color: accent.withValues(alpha: 0.2),
                      blurRadius: 7,
                    ),
                  ],
                ),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }
}
