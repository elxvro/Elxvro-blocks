import 'package:flutter/material.dart';

class GameThemeData {
  const GameThemeData({
    required this.id,
    required this.name,
    required this.subtitle,
    required this.backgroundTop,
    required this.backgroundBottom,
    required this.board,
    required this.cell,
    required this.block,
    required this.blockAccent,
  });

  final String id;
  final String name;
  final String subtitle;
  final Color backgroundTop;
  final Color backgroundBottom;
  final Color board;
  final Color cell;
  final Color block;
  final Color blockAccent;
}

const List<GameThemeData> gameThemes = <GameThemeData>[
  GameThemeData(
    id: 'classic',
    name: 'Klasik',
    subtitle: 'Zamansız sıcaklık',
    backgroundTop: Color(0xFF101010),
    backgroundBottom: Color(0xFF020202),
    board: Color(0xFF171513),
    cell: Color(0xFF28221D),
    block: Color(0xFFC88A48),
    blockAccent: Color(0xFFFFD98B),
  ),
  GameThemeData(
    id: 'night',
    name: 'Gece',
    subtitle: 'Modern ve sade',
    backgroundTop: Color(0xFF07101D),
    backgroundBottom: Color(0xFF02040A),
    board: Color(0xFF0B1422),
    cell: Color(0xFF13223A),
    block: Color(0xFF294B86),
    blockAccent: Color(0xFF8FB7FF),
  ),
  GameThemeData(
    id: 'marble',
    name: 'Mermer',
    subtitle: 'Zarif detaylar',
    backgroundTop: Color(0xFF1D1D1F),
    backgroundBottom: Color(0xFF080808),
    board: Color(0xFF202124),
    cell: Color(0xFF35363A),
    block: Color(0xFFB7B9BE),
    blockAccent: Color(0xFFFFFFFF),
  ),
  GameThemeData(
    id: 'fire',
    name: 'Ateş',
    subtitle: 'Enerji dolu',
    backgroundTop: Color(0xFF210704),
    backgroundBottom: Color(0xFF070201),
    board: Color(0xFF260B05),
    cell: Color(0xFF411309),
    block: Color(0xFFB93817),
    blockAccent: Color(0xFFFF9D45),
  ),
  GameThemeData(
    id: 'nature',
    name: 'Doğa',
    subtitle: 'Huzur veren tonlar',
    backgroundTop: Color(0xFF09180F),
    backgroundBottom: Color(0xFF020604),
    board: Color(0xFF0E2115),
    cell: Color(0xFF193624),
    block: Color(0xFF487754),
    blockAccent: Color(0xFFB7E38A),
  ),
  GameThemeData(
    id: 'aurora',
    name: 'Aurora',
    subtitle: 'Renklerin dansı',
    backgroundTop: Color(0xFF0A0721),
    backgroundBottom: Color(0xFF020208),
    board: Color(0xFF10102D),
    cell: Color(0xFF1A1B42),
    block: Color(0xFF5E43D5),
    blockAccent: Color(0xFF50E9FF),
  ),
];
