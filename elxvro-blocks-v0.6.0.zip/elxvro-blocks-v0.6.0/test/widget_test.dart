import 'package:elxvro_blocks/app_state.dart';
import 'package:elxvro_blocks/main.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('ELXVRO Blocks ana ekranı açılır', (WidgetTester tester) async {
    final appState = AppState();

    await tester.pumpWidget(ElxvroBlocksApp(appState: appState));
    await tester.pump();

    expect(find.text('ELXVRO'), findsOneWidget);
    expect(find.text('OYNA'), findsOneWidget);
  });
}
