# ELXVRO Blocks v0.6.0 — Progression & Premium Polish

Bu sürüm v0.5.0 Challenge Modes tabanını korur ve oyuncu ilerlemesi ile oyun hissini geliştirir.

## Yeni özellikler

- XP ve seviye sistemi
- Ana menüde canlı seviye / XP çubuğu
- Yeni Profil & Seviye ekranı
- Her 5 seviyede otomatik milestone ödülü
  - coin
  - özel blok hakkı
  - belirli seviyelerde premium tema kilidi açma
- İlk oyun için hızlı eğitim penceresi
- Ayarlardan eğitimi yeniden gösterme
- Oyun içi duraklatma menüsü
  - devam et
  - yeniden başlat
  - ana menü
  - ses / titreşim kontrolü
- Perfect Clear sistemi
  - tahta tamamen boşalırsa +1000 skor
  - ekstra XP ve coin
  - oyun sonu istatistiği
- Combo seviyesine göre ekstra coin
- Oyun sonu XP, seviye ve bonus ödül özeti
- Perfect Clear / seviye odaklı yeni başarımlar
- İstatistiklere seviye, XP ve Perfect Clear bilgileri
- v0.5.0 modları, ekonomi, mağaza, temalar, görevler, özel bloklar, Undo/Yenile sistemi korunur

## GitHub ZIP build

Repo köküne `elxvro-blocks-v0.6.0.zip` yüklenebilir. Repo içindeki `.github/workflows/build-apk.yml` akışı ZIP'i açıp Flutter Android platform dosyalarını oluşturur, analyze/test çalıştırır ve release APK üretir.

Beklenen artifact: `ELXVRO-Blocks-v0.6.0`
