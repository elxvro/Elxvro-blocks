# ELXVRO Blocks v0.5.0 — Challenge Modes

Bu sürüm v0.4.1 ekonomi ve ödül sisteminin üzerine yeni oyun modları ekler.

## Yeni özellikler

- Klasik mod: hamle kalmayana kadar sınırsız oyun.
- 2 Dakika modu: 120 saniyelik skor yarışı.
- Hedef 5000 modu: hamleler bitmeden 5.000 puana ulaşma hedefi.
- Günlük Challenge: her gün aynı gün için sabit başlangıç tahtası ve parça akışı.
- Günlük Challenge hedefi: 3 dakika içinde 3.500 puan.
- Mod ekranında ayrı rekorlar.
- 2 Dakika tamamlaması: +25 coin.
- Hedef 5000 başarısı: +60 coin.
- Günlük Challenge başarısı: günde bir kez +150 coin.
- Oyun sırasında mod adı, kalan süre ve hedef bilgisi.
- Challenge sonuç ekranında kazanılan coin bilgisi.

## Korunan sistemler

- Premium siyah/altın arayüz
- 10x10 oyun alanı
- Hassas sürükle-bırak ve hayalet önizleme
- Özel bloklar
- Geri Al / Yenile / Özel güçler
- Günlük ödül, görevler, başarımlar ve mağaza
- Tema sistemi
- İstatistikler
- Yerel kayıt

## Sürüm

`0.5.0+10`

GitHub ZIP build yapısında repo kökünde `elxvro-blocks-v0.5.0.zip` bulunmalı. ZIP açıldığında proje klasörü `elxvro-blocks-v0.5.0/` olarak oluşur.
