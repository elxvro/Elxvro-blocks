import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../app_state.dart';
import '../game/board_engine.dart';
import '../models/block_piece.dart';
import '../models/game_mode.dart';
import '../models/game_theme.dart';
import '../widgets/piece_preview.dart';
import '../widgets/premium_background.dart';

class GameScreen extends StatefulWidget {
  const GameScreen({
    super.key,
    required this.appState,
    this.mode = GameMode.classic,
  });

  final AppState appState;
  final GameMode mode;

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen>
    with SingleTickerProviderStateMixin {
  static const int _boardSize = 10;
  final BoardEngine _engine = BoardEngine(size: _boardSize);
  Random _random = Random();
  final GlobalKey _gridKey = GlobalKey();

  late List<BlockPiece?> _pieces;
  late final AnimationController _clearController;
  Timer? _modeTimer;

  int _score = 0;
  int _combo = 0;
  int _bestComboThisGame = 0;
  int _clearedLinesThisGame = 0;
  int _placedBlocksThisGame = 0;
  int? _hoverRow;
  int? _hoverCol;
  int? _hoverPieceIndex;
  bool _finishing = false;
  bool _undoAvailable = true;
  bool _refreshAvailable = true;
  int _secondsLeft = 0;
  _GameSnapshot? _undoSnapshot;
  Set<int> _flashCells = <int>{};
  List<_Particle> _particles = <_Particle>[];

  GameThemeData get _theme => gameThemes.firstWhere(
        (theme) => theme.id == widget.appState.themeId,
        orElse: () => gameThemes.first,
      );


  GameModeData get _modeData => gameModeData[widget.mode]!;

  int get _dailySeed {
    final now = DateTime.now();
    return now.year * 10000 + now.month * 100 + now.day;
  }

  int get _modeBest {
    switch (widget.mode) {
      case GameMode.classic:
        return widget.appState.bestScore;
      case GameMode.timed:
        return widget.appState.timedBestScore;
      case GameMode.target:
        return widget.appState.targetBestScore;
      case GameMode.daily:
        return widget.appState.dailyChallengeBestScore;
    }
  }

  String get _modeStatus {
    final target = _modeData.targetScore;
    final timer = _modeData.durationSeconds;
    if (target != null && timer != null) {
      return '${_formatTime(_secondsLeft)}  •  HEDEF $target';
    }
    if (timer != null) {
      return _formatTime(_secondsLeft);
    }
    if (target != null) {
      return 'HEDEF $target';
    }
    return 'SINIRSIZ';
  }

  String _formatTime(int seconds) {
    final safe = max(0, seconds);
    final minutes = safe ~/ 60;
    final rest = safe % 60;
    return '$minutes:${rest.toString().padLeft(2, '0')}';
  }

  @override
  void initState() {
    super.initState();
    _prepareRound();
    _clearController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 520),
    )..addStatusListener((status) {
        if (status == AnimationStatus.completed && mounted) {
          setState(() {
            _flashCells = <int>{};
            _particles = <_Particle>[];
          });
        }
      });
    _startModeTimer();
  }

  @override
  void dispose() {
    _modeTimer?.cancel();
    _clearController.dispose();
    super.dispose();
  }

  void _prepareRound() {
    _modeTimer?.cancel();
    _random = widget.mode == GameMode.daily ? Random(_dailySeed) : Random();
    _engine.reset();
    if (widget.mode == GameMode.daily) {
      _applyDailyStartingBoard();
    } else if (widget.mode == GameMode.target) {
      _applyTargetStartingBoard();
    }
    _secondsLeft = _modeData.durationSeconds ?? 0;
    _pieces = _generatePieces();
  }

  void _applyTargetStartingBoard() {
    final state = List<List<bool>>.generate(
      _boardSize,
      (_) => List<bool>.filled(_boardSize, false),
    );
    const cells = <({int row, int col})>[
      (row: 9, col: 0),
      (row: 9, col: 1),
      (row: 8, col: 0),
      (row: 9, col: 8),
      (row: 9, col: 9),
      (row: 8, col: 9),
      (row: 7, col: 3),
      (row: 7, col: 6),
      (row: 6, col: 4),
      (row: 6, col: 5),
    ];
    for (final cell in cells) {
      state[cell.row][cell.col] = true;
    }
    _engine.restore(state);
  }

  void _applyDailyStartingBoard() {
    final boardRandom = Random(_dailySeed ^ 0x5EED);
    final state = List<List<bool>>.generate(
      _boardSize,
      (_) => List<bool>.filled(_boardSize, false),
    );
    final rowCounts = List<int>.filled(_boardSize, 0);
    var placed = 0;
    while (placed < 14) {
      final row = 4 + boardRandom.nextInt(6);
      final col = boardRandom.nextInt(_boardSize);
      if (state[row][col] || rowCounts[row] >= 6) {
        continue;
      }
      state[row][col] = true;
      rowCounts[row] += 1;
      placed += 1;
    }
    _engine.restore(state);
  }

  void _startModeTimer() {
    if (_modeData.durationSeconds == null) {
      return;
    }
    _modeTimer?.cancel();
    _modeTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted || _finishing) {
        return;
      }
      if (_secondsLeft <= 1) {
        timer.cancel();
        setState(() => _secondsLeft = 0);
        unawaited(_handleTimeExpired());
        return;
      }
      setState(() => _secondsLeft -= 1);
    });
  }

  Future<void> _handleTimeExpired() async {
    if (widget.mode == GameMode.timed) {
      await _finishGame(success: true, reason: 'SÜRE DOLDU');
      return;
    }
    await _finishGame(success: false, reason: 'SÜRE DOLDU');
  }

  List<BlockPiece?> _generatePieces() {
    var specialUsed = false;
    return List<BlockPiece?>.generate(3, (_) {
      final shouldUseSpecial = !specialUsed && _random.nextDouble() < 0.13;
      if (shouldUseSpecial) {
        specialUsed = true;
        return specialBlockCatalog[_random.nextInt(specialBlockCatalog.length)];
      }
      return blockCatalog[_random.nextInt(blockCatalog.length)];
    });
  }

  void _resetGame() {
    _modeTimer?.cancel();
    setState(() {
      _finishing = false;
      _prepareRound();
      _score = 0;
      _combo = 0;
      _bestComboThisGame = 0;
      _clearedLinesThisGame = 0;
      _placedBlocksThisGame = 0;
      _hoverRow = null;
      _hoverCol = null;
      _hoverPieceIndex = null;
      _undoAvailable = true;
      _refreshAvailable = true;
      _undoSnapshot = null;
      _flashCells = <int>{};
      _particles = <_Particle>[];
    });
    _clearController.reset();
    _startModeTimer();
  }

  _GameSnapshot _captureSnapshot() {
    return _GameSnapshot(
      grid: _engine.snapshot(),
      pieces: List<BlockPiece?>.from(_pieces),
      score: _score,
      combo: _combo,
      bestCombo: _bestComboThisGame,
      clearedLines: _clearedLinesThisGame,
      placedBlocks: _placedBlocksThisGame,
    );
  }

  Future<void> _undoLastMove() async {
    if (_finishing) return;
    final snapshot = _undoSnapshot;
    if (snapshot == null || (!_undoAvailable && widget.appState.undoInventory <= 0)) {
      return;
    }

    if (!_undoAvailable) {
      final consumed = await widget.appState.consumeUndo();
      if (!consumed || !mounted) return;
    }

    setState(() {
      _engine.restore(snapshot.grid);
      _pieces = List<BlockPiece?>.from(snapshot.pieces);
      _score = snapshot.score;
      _combo = snapshot.combo;
      _bestComboThisGame = snapshot.bestCombo;
      _clearedLinesThisGame = snapshot.clearedLines;
      _placedBlocksThisGame = snapshot.placedBlocks;
      if (_undoAvailable) {
        _undoAvailable = false;
      }
      _undoSnapshot = null;
      _flashCells = <int>{};
      _particles = <_Particle>[];
      _hoverRow = null;
      _hoverCol = null;
      _hoverPieceIndex = null;
    });
    _clearController.reset();
    _playClick();
    _lightHaptic();
  }

  Future<void> _refreshPieces() async {
    if (_finishing) return;
    if (!_refreshAvailable && widget.appState.refreshInventory <= 0) {
      return;
    }

    if (!_refreshAvailable) {
      final consumed = await widget.appState.consumeRefresh();
      if (!consumed || !mounted) return;
    }

    var candidate = List<BlockPiece?>.from(_pieces);
    for (var attempt = 0; attempt < 30; attempt++) {
      var specialUsed = false;
      candidate = List<BlockPiece?>.generate(3, (index) {
        if (_pieces[index] == null) {
          return null;
        }
        final useSpecial = !specialUsed && _random.nextDouble() < 0.16;
        if (useSpecial) {
          specialUsed = true;
          return specialBlockCatalog[
              _random.nextInt(specialBlockCatalog.length)];
        }
        return blockCatalog[_random.nextInt(blockCatalog.length)];
      });
      if (_engine.hasAnyMove(candidate.whereType<BlockPiece>())) {
        break;
      }
    }

    setState(() {
      _pieces = candidate;
      if (_refreshAvailable) {
        _refreshAvailable = false;
      }
      _undoSnapshot = null;
      _hoverRow = null;
      _hoverCol = null;
      _hoverPieceIndex = null;
    });
    _playClick();
    _lightHaptic();
    _checkGameState();
  }

  Future<void> _useSpecialBlock() async {
    if (_finishing) return;
    if (widget.appState.specialInventory <= 0) {
      return;
    }
    final index = _pieces.indexWhere((piece) => piece != null);
    if (index < 0) {
      return;
    }
    final consumed = await widget.appState.consumeSpecial();
    if (!consumed || !mounted) return;
    setState(() {
      _pieces[index] =
          specialBlockCatalog[_random.nextInt(specialBlockCatalog.length)];
      _undoSnapshot = null;
      _hoverRow = null;
      _hoverCol = null;
      _hoverPieceIndex = null;
    });
    _playAlert();
    _lightHaptic();
  }

  ({int row, int col})? _rawOriginFromGlobal(Offset globalOffset) {
    final renderObject = _gridKey.currentContext?.findRenderObject();
    if (renderObject is! RenderBox || !renderObject.hasSize) {
      return null;
    }

    final local = renderObject.globalToLocal(globalOffset);
    final size = renderObject.size;
    if (local.dx < 0 ||
        local.dy < 0 ||
        local.dx >= size.width ||
        local.dy >= size.height) {
      return null;
    }

    final cellWidth = size.width / _boardSize;
    final cellHeight = size.height / _boardSize;
    final col = (local.dx / cellWidth).floor();
    final row = (local.dy / cellHeight).floor();
    return (row: row, col: col);
  }

  ({int row, int col})? _snapToValidOrigin(
    BlockPiece piece,
    int row,
    int col,
  ) {
    if (_engine.canPlace(piece, row, col)) {
      return (row: row, col: col);
    }

    const offsets = <({int row, int col})>[
      (row: -1, col: 0),
      (row: 1, col: 0),
      (row: 0, col: -1),
      (row: 0, col: 1),
      (row: -1, col: -1),
      (row: -1, col: 1),
      (row: 1, col: -1),
      (row: 1, col: 1),
    ];

    for (final offset in offsets) {
      final candidateRow = row + offset.row;
      final candidateCol = col + offset.col;
      if (_engine.canPlace(piece, candidateRow, candidateCol)) {
        return (row: candidateRow, col: candidateCol);
      }
    }
    return null;
  }

  void _updateHover(DragTargetDetails<int> details) {
    final index = details.data;
    final piece = _pieces[index];
    if (piece == null) {
      return;
    }

    final raw = _rawOriginFromGlobal(details.offset);
    if (raw == null) {
      setState(() {
        _hoverPieceIndex = null;
        _hoverRow = null;
        _hoverCol = null;
      });
      return;
    }

    final snapped = _snapToValidOrigin(piece, raw.row, raw.col);
    final shown = snapped ?? raw;
    setState(() {
      _hoverPieceIndex = index;
      _hoverRow = shown.row;
      _hoverCol = shown.col;
    });
  }

  void _acceptPiece(DragTargetDetails<int> details) {
    if (_finishing) return;
    final index = details.data;
    final piece = _pieces[index];
    if (piece == null) {
      return;
    }

    final raw = _rawOriginFromGlobal(details.offset);
    if (raw == null) {
      return;
    }
    final snapped = _snapToValidOrigin(piece, raw.row, raw.col);
    if (snapped == null) {
      setState(() {
        _hoverPieceIndex = null;
        _hoverRow = null;
        _hoverCol = null;
      });
      return;
    }

    final before = _captureSnapshot();
    final result = _engine.place(piece, snapped.row, snapped.col);

    if (result == null) {
      setState(() {
        _hoverPieceIndex = null;
        _hoverRow = null;
        _hoverCol = null;
      });
      return;
    }

    setState(() {
      if (_undoAvailable || widget.appState.undoInventory > 0) {
        _undoSnapshot = before;
      }
      _pieces[index] = null;
      final lineCount = result.clearedLines;
      _placedBlocksThisGame += 1;
      _clearedLinesThisGame += lineCount;

      final didClear = result.clearedCellCount > 0;
      if (didClear) {
        _combo += 1;
        _bestComboThisGame = max(_bestComboThisGame, _combo);
      } else {
        _combo = 0;
      }

      _score += result.placedCells * 10;
      _score += lineCount * 120 * max(1, _combo);
      _score += _specialBonus(result);

      _hoverPieceIndex = null;
      _hoverRow = null;
      _hoverCol = null;

      if (_pieces.every((item) => item == null)) {
        _pieces = _generatePieces();
      }
    });

    if (result.clearedCellCount > 0) {
      _triggerClearFx(result.clearedCells);
      _mediumHaptic();
      _playAlert();
    } else {
      _lightHaptic();
      _playClick();
    }

    _checkGameState();
  }

  int _specialBonus(PlacementResult result) {
    switch (result.power) {
      case PiecePower.bomb:
        return 80 + result.clearedCellCount * 18;
      case PiecePower.rowClear:
      case PiecePower.columnClear:
        return 100 + result.clearedCellCount * 14;
      case PiecePower.wild:
        return 50;
      case PiecePower.normal:
        return 0;
    }
  }

  void _triggerClearFx(List<BoardCell> cells) {
    if (cells.isEmpty) {
      return;
    }

    final flash = <int>{};
    final particles = <_Particle>[];
    for (final cell in cells) {
      flash.add(cell.row * _boardSize + cell.col);
      final count = cells.length > 18 ? 2 : 4;
      for (var i = 0; i < count; i++) {
        particles.add(
          _Particle(
            x: (cell.col + 0.5) / _boardSize,
            y: (cell.row + 0.5) / _boardSize,
            vx: (_random.nextDouble() - 0.5) * 0.22,
            vy: -0.05 - _random.nextDouble() * 0.18,
            radius: 1.5 + _random.nextDouble() * 2.8,
          ),
        );
      }
    }

    setState(() {
      _flashCells = flash;
      _particles = particles.take(72).toList(growable: false);
    });
    _clearController.forward(from: 0);
  }

  void _playClick() {
    if (widget.appState.soundEnabled) {
      SystemSound.play(SystemSoundType.click);
    }
  }

  void _playAlert() {
    if (widget.appState.soundEnabled) {
      SystemSound.play(SystemSoundType.alert);
    }
  }

  void _lightHaptic() {
    if (widget.appState.hapticsEnabled) {
      HapticFeedback.selectionClick();
    }
  }

  void _mediumHaptic() {
    if (widget.appState.hapticsEnabled) {
      HapticFeedback.mediumImpact();
    }
  }

  Future<void> _checkGameState() async {
    if (_finishing) {
      return;
    }

    final target = _modeData.targetScore;
    if (target != null && _score >= target) {
      await _finishGame(success: true, reason: 'HEDEF TAMAMLANDI');
      return;
    }

    final available = _pieces.whereType<BlockPiece>().toList();
    if (available.isNotEmpty && _engine.hasAnyMove(available)) {
      return;
    }

    final timedSuccess =
        widget.mode == GameMode.timed && _score >= 1000;
    await _finishGame(
      success: widget.mode == GameMode.classic || timedSuccess,
      reason: 'HAMLE KALMADI',
    );
  }

  Future<void> _finishGame({
    required bool success,
    required String reason,
  }) async {
    if (_finishing) {
      return;
    }
    _finishing = true;
    _modeTimer?.cancel();

    await widget.appState.recordGame(
      score: _score,
      combo: _bestComboThisGame,
      clearedLines: _clearedLinesThisGame,
      placedBlocks: _placedBlocksThisGame,
    );
    final modeReward = await widget.appState.recordModeResult(
      modeId: _modeData.id,
      score: _score,
      success: success,
    );
    if (!mounted) {
      return;
    }

    _playAlert();
    if (widget.appState.hapticsEnabled) {
      HapticFeedback.heavyImpact();
    }

    var title = 'OYUN BİTTİ';
    if (widget.mode == GameMode.timed) {
      title = reason;
    } else if (widget.mode == GameMode.target || widget.mode == GameMode.daily) {
      title = success ? 'HEDEF TAMAMLANDI' : 'CHALLENGE BİTTİ';
    }

    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return AlertDialog(
          backgroundColor: const Color(0xFF12100E),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
          title: Text(
            title,
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: Color(0xFFFFD98B),
              letterSpacing: 2.2,
              fontWeight: FontWeight.w700,
            ),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Text(
                '${_modeData.title}  •  $reason',
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white54, fontSize: 11),
              ),
              const SizedBox(height: 18),
              Text(
                '$_score',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 42,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const Text(
                'SKOR',
                style: TextStyle(
                  color: Colors.white38,
                  fontSize: 10,
                  letterSpacing: 1.5,
                ),
              ),
              const SizedBox(height: 18),
              Row(
                children: <Widget>[
                  Expanded(
                    child: _DialogStat(
                      label: 'ÇİZGİ',
                      value: '$_clearedLinesThisGame',
                    ),
                  ),
                  Expanded(
                    child: _DialogStat(
                      label: 'MAX COMBO',
                      value: 'x$_bestComboThisGame',
                    ),
                  ),
                  Expanded(
                    child: _DialogStat(
                      label: 'BLOK',
                      value: '$_placedBlocksThisGame',
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Text(
                'MOD REKORU  ${max(_modeBest, _score)}',
                style: const TextStyle(
                  color: Color(0xFFFFC86E),
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                ),
              ),
              if (modeReward > 0) ...<Widget>[
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 9,
                  ),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(999),
                    color: const Color(0xFFFFC86E).withValues(alpha: 0.10),
                    border: Border.all(
                      color: const Color(0xFFFFC86E).withValues(alpha: 0.25),
                    ),
                  ),
                  child: Text(
                    '+$modeReward COIN KAZANDIN',
                    style: const TextStyle(
                      color: Color(0xFFFFD98B),
                      fontSize: 10,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 0.8,
                    ),
                  ),
                ),
              ],
            ],
          ),
          actionsAlignment: MainAxisAlignment.center,
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.of(context).pop();
              },
              child: const Text('ANA MENÜ'),
            ),
            FilledButton(
              onPressed: () {
                Navigator.of(context).pop();
                _resetGame();
              },
              style: FilledButton.styleFrom(
                backgroundColor: const Color(0xFFC7863C),
                foregroundColor: const Color(0xFF160D06),
              ),
              child: const Text('TEKRAR OYNA'),
            ),
          ],
        );
      },
    );
  }

  String get _comboText {
    if (_combo >= 6) {
      return 'ULTRA COMBO  x$_combo';
    }
    if (_combo >= 4) {
      return 'MEGA COMBO  x$_combo';
    }
    return 'COMBO x$_combo';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: PremiumBackground(
        top: _theme.backgroundTop,
        bottom: _theme.backgroundBottom,
        child: SafeArea(
          child: LayoutBuilder(
            builder: (context, constraints) {
              final heightLimited = max(250.0, constraints.maxHeight - 285);
              final boardExtent = min(
                constraints.maxWidth - 28,
                min(430.0, heightLimited),
              );
              final cellSize = boardExtent / _boardSize;
              return Column(
                children: <Widget>[
                  _TopBar(
                    score: _score,
                    best: max(_modeBest, _score),
                    modeLabel: _modeData.title,
                    modeStatus: _modeStatus,
                    onBack: () => Navigator.of(context).pop(),
                    onHelp: () => _showHowToPlay(context),
                  ),
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 230),
                    transitionBuilder: (child, animation) => ScaleTransition(
                      scale: Tween<double>(begin: 0.72, end: 1).animate(
                        CurvedAnimation(
                          parent: animation,
                          curve: Curves.easeOutBack,
                        ),
                      ),
                      child: FadeTransition(opacity: animation, child: child),
                    ),
                    child: _combo > 1
                        ? Padding(
                            key: ValueKey<int>(_combo),
                            padding: const EdgeInsets.only(bottom: 6),
                            child: Text(
                              _comboText,
                              style: TextStyle(
                                color: _combo >= 4
                                    ? const Color(0xFFFFFFFF)
                                    : const Color(0xFFFFD98B),
                                fontWeight: FontWeight.w900,
                                letterSpacing: 2.0,
                                shadows: const <Shadow>[
                                  Shadow(
                                    color: Color(0x99FFB84D),
                                    blurRadius: 16,
                                  ),
                                ],
                              ),
                            ),
                          )
                        : const SizedBox(key: ValueKey<int>(0), height: 0),
                  ),
                  const SizedBox(height: 4),
                  SizedBox(
                    width: boardExtent,
                    height: boardExtent,
                    child: DragTarget<int>(
                      onWillAcceptWithDetails: (details) {
                        _updateHover(details);
                        return _pieces[details.data] != null;
                      },
                      onMove: _updateHover,
                      onLeave: (_) {
                        setState(() {
                          _hoverRow = null;
                          _hoverCol = null;
                          _hoverPieceIndex = null;
                        });
                      },
                      onAcceptWithDetails: _acceptPiece,
                      builder: (context, candidateData, rejectedData) {
                        return Container(
                          padding: const EdgeInsets.all(5),
                          decoration: BoxDecoration(
                            color: _theme.board,
                            borderRadius: BorderRadius.circular(18),
                            border: Border.all(
                              color: _theme.blockAccent.withValues(alpha: 0.35),
                            ),
                            boxShadow: <BoxShadow>[
                              BoxShadow(
                                color: Colors.black.withValues(alpha: 0.40),
                                blurRadius: 28,
                              ),
                            ],
                          ),
                          child: AnimatedBuilder(
                            animation: _clearController,
                            builder: (context, _) {
                              return Stack(
                                children: <Widget>[
                                  _BoardGrid(
                                    engine: _engine,
                                    theme: _theme,
                                    hoverRow: _hoverRow,
                                    hoverCol: _hoverCol,
                                    hoverPiece: _hoverPieceIndex == null
                                        ? null
                                        : _pieces[_hoverPieceIndex!],
                                    cellSize: cellSize,
                                    gridKey: _gridKey,
                                    flashCells: _flashCells,
                                    flashProgress: _clearController.value,
                                  ),
                                  if (_particles.isNotEmpty)
                                    Positioned.fill(
                                      child: IgnorePointer(
                                        child: CustomPaint(
                                          painter: _ParticleBurstPainter(
                                            particles: _particles,
                                            progress: _clearController.value,
                                            color: _theme.blockAccent,
                                          ),
                                        ),
                                      ),
                                    ),
                                ],
                              );
                            },
                          ),
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 10),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 22),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Expanded(
                          child: _GameToolButton(
                            icon: Icons.undo_rounded,
                            label: 'GERİ AL',
                            charge: (_undoAvailable ? 1 : 0) +
                                widget.appState.undoInventory,
                            enabled: _undoSnapshot != null &&
                                (_undoAvailable ||
                                    widget.appState.undoInventory > 0),
                            onPressed: _undoLastMove,
                          ),
                        ),
                        const SizedBox(width: 7),
                        Expanded(
                          child: _GameToolButton(
                            icon: Icons.autorenew_rounded,
                            label: 'YENİLE',
                            charge: (_refreshAvailable ? 1 : 0) +
                                widget.appState.refreshInventory,
                            enabled: _refreshAvailable ||
                                widget.appState.refreshInventory > 0,
                            onPressed: _refreshPieces,
                          ),
                        ),
                        const SizedBox(width: 7),
                        Expanded(
                          child: _GameToolButton(
                            icon: Icons.auto_awesome_rounded,
                            label: 'ÖZEL',
                            charge: widget.appState.specialInventory,
                            enabled: widget.appState.specialInventory > 0 &&
                                _pieces.any((piece) => piece != null),
                            onPressed: _useSpecialBlock,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 10),
                  Expanded(
                    child: Align(
                      alignment: Alignment.topCenter,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: List<Widget>.generate(3, (index) {
                          final piece = _pieces[index];
                          return Expanded(
                            child: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 5),
                              child: _PieceSlot(
                                piece: piece,
                                index: index,
                                theme: _theme,
                              ),
                            ),
                          );
                        }),
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  void _showHowToPlay(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF111111),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            const Text(
              'NASIL OYNANIR?',
              style: TextStyle(
                color: Color(0xFFFFD98B),
                fontWeight: FontWeight.w800,
                letterSpacing: 1.7,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              '${_modeData.title}: ${_modeData.description}',
              style: const TextStyle(
                color: Color(0xFFFFC86E),
                fontSize: 11,
                height: 1.4,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 16),
            const _Rule(text: '1. Bloğu sürükle; hayalet alan nereye oturacağını gösterir.'),
            const _Rule(text: '2. Dolu satır veya sütunları temizleyerek combo yap.'),
            const _Rule(text: '3. Bomba, Satır, Sütun ve Joker özel bloklarını kullan.'),
            const _Rule(text: '4. Her oyunda 1 ücretsiz Geri Al ve 1 Yenile hakkın var.'),
            const _Rule(text: '5. Mağazadan ekstra hak ve Özel Blok gücü alabilirsin.'),
            const _Rule(text: '6. Mod hedefini tamamla veya mümkün olan en iyi skoru yap.'),
          ],
        ),
      ),
    );
  }
}

class _GameSnapshot {
  const _GameSnapshot({
    required this.grid,
    required this.pieces,
    required this.score,
    required this.combo,
    required this.bestCombo,
    required this.clearedLines,
    required this.placedBlocks,
  });

  final List<List<bool>> grid;
  final List<BlockPiece?> pieces;
  final int score;
  final int combo;
  final int bestCombo;
  final int clearedLines;
  final int placedBlocks;
}

class _TopBar extends StatelessWidget {
  const _TopBar({
    required this.score,
    required this.best,
    required this.modeLabel,
    required this.modeStatus,
    required this.onBack,
    required this.onHelp,
  });

  final int score;
  final int best;
  final String modeLabel;
  final String modeStatus;
  final VoidCallback onBack;
  final VoidCallback onHelp;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 6, 8, 10),
      child: Row(
        children: <Widget>[
          IconButton(onPressed: onBack, icon: const Icon(Icons.arrow_back_rounded)),
          Expanded(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    _ScoreBlock(
                      label: 'EN YÜKSEK',
                      value: '$best',
                      icon: Icons.emoji_events_rounded,
                    ),
                    const SizedBox(width: 28),
                    _ScoreBlock(label: 'SKOR', value: '$score'),
                  ],
                ),
                const SizedBox(height: 3),
                Text(
                  '$modeLabel  •  $modeStatus',
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Color(0xFFFFC86E),
                    fontSize: 8,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.8,
                  ),
                ),
              ],
            ),
          ),
          IconButton(onPressed: onHelp, icon: const Icon(Icons.help_outline_rounded)),
        ],
      ),
    );
  }
}

class _ScoreBlock extends StatelessWidget {
  const _ScoreBlock({required this.label, required this.value, this.icon});

  final String label;
  final String value;
  final IconData? icon;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        Row(
          children: <Widget>[
            if (icon != null) ...<Widget>[
              Icon(icon, size: 16, color: const Color(0xFFFFC66D)),
              const SizedBox(width: 5),
            ],
            Text(
              value,
              style: const TextStyle(
                fontSize: 21,
                fontWeight: FontWeight.w800,
                color: Colors.white,
              ),
            ),
          ],
        ),
        Text(
          label,
          style: const TextStyle(
            color: Colors.white38,
            fontSize: 8,
            fontWeight: FontWeight.w600,
            letterSpacing: 1.2,
          ),
        ),
      ],
    );
  }
}

class _BoardGrid extends StatelessWidget {
  const _BoardGrid({
    required this.engine,
    required this.theme,
    required this.hoverRow,
    required this.hoverCol,
    required this.hoverPiece,
    required this.cellSize,
    required this.gridKey,
    required this.flashCells,
    required this.flashProgress,
  });

  final BoardEngine engine;
  final GameThemeData theme;
  final int? hoverRow;
  final int? hoverCol;
  final BlockPiece? hoverPiece;
  final double cellSize;
  final GlobalKey gridKey;
  final Set<int> flashCells;
  final double flashProgress;

  bool _isHoveredCell(int row, int col) {
    final piece = hoverPiece;
    final originRow = hoverRow;
    final originCol = hoverCol;
    if (piece == null || originRow == null || originCol == null) {
      return false;
    }
    return piece.cells.any(
      (cell) => originRow + cell.row == row && originCol + cell.col == col,
    );
  }

  @override
  Widget build(BuildContext context) {
    final canPlace = hoverPiece != null && hoverRow != null && hoverCol != null
        ? engine.canPlace(hoverPiece!, hoverRow!, hoverCol!)
        : false;

    return SizedBox.expand(
      key: gridKey,
      child: GridView.builder(
        physics: const NeverScrollableScrollPhysics(),
        padding: EdgeInsets.zero,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: _GameScreenState._boardSize,
          mainAxisSpacing: 2,
          crossAxisSpacing: 2,
        ),
        itemCount: engine.size * engine.size,
        itemBuilder: (context, index) {
          final row = index ~/ engine.size;
          final col = index % engine.size;
          final filled = engine.grid[row][col];
          final hovered = _isHoveredCell(row, col);
          final flashed = flashCells.contains(index);
          final flashAlpha = (1 - flashProgress).clamp(0.0, 1.0).toDouble();
          final hoverColor = canPlace
              ? theme.blockAccent.withValues(alpha: 0.55)
              : const Color(0xFFFF4D4D).withValues(alpha: 0.42);

          return AnimatedContainer(
            duration: const Duration(milliseconds: 90),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(max(2.5, cellSize * 0.10)),
              color: filled
                  ? null
                  : flashed
                      ? theme.blockAccent.withValues(alpha: 0.72 * flashAlpha)
                      : hovered
                          ? hoverColor
                          : theme.cell,
              gradient: filled
                  ? LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: <Color>[theme.blockAccent, theme.block],
                    )
                  : null,
              border: Border.all(
                color: flashed
                    ? Colors.white.withValues(alpha: 0.88 * flashAlpha)
                    : filled
                        ? theme.blockAccent.withValues(alpha: 0.55)
                        : Colors.white.withValues(alpha: 0.035),
                width: flashed ? 1.3 : 0.7,
              ),
              boxShadow: flashed
                  ? <BoxShadow>[
                      BoxShadow(
                        color: theme.blockAccent.withValues(
                          alpha: 0.55 * flashAlpha,
                        ),
                        blurRadius: 14,
                      ),
                    ]
                  : filled
                      ? <BoxShadow>[
                          BoxShadow(
                            color: theme.blockAccent.withValues(alpha: 0.18),
                            blurRadius: 7,
                          ),
                        ]
                      : null,
            ),
          );
        },
      ),
    );
  }
}

class _PieceSlot extends StatelessWidget {
  const _PieceSlot({
    required this.piece,
    required this.index,
    required this.theme,
  });

  final BlockPiece? piece;
  final int index;
  final GameThemeData theme;

  @override
  Widget build(BuildContext context) {
    final currentPiece = piece;
    final child = Container(
      height: 112,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.035),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: currentPiece?.isSpecial == true
              ? theme.blockAccent.withValues(alpha: 0.28)
              : Colors.white.withValues(alpha: 0.045),
        ),
      ),
      child: currentPiece == null
          ? const SizedBox.shrink()
          : Stack(
              alignment: Alignment.center,
              children: <Widget>[
                PiecePreview(
                  piece: currentPiece,
                  color: theme.block,
                  accent: theme.blockAccent,
                  cellSize: currentPiece.rows >= 3 || currentPiece.cols >= 3
                      ? 22
                      : 27,
                ),
                if (currentPiece.isSpecial)
                  Positioned(
                    top: 7,
                    right: 7,
                    child: _SpecialBadge(piece: currentPiece),
                  ),
              ],
            ),
    );

    if (currentPiece == null) {
      return child;
    }

    return Draggable<int>(
      data: index,
      dragAnchorStrategy: pointerDragAnchorStrategy,
      maxSimultaneousDrags: 1,
      feedback: Material(
        color: Colors.transparent,
        child: Stack(
          clipBehavior: Clip.none,
          children: <Widget>[
            PiecePreview(
              piece: currentPiece,
              color: theme.block,
              accent: theme.blockAccent,
              cellSize: 28,
            ),
            if (currentPiece.isSpecial)
              Positioned(
                right: -18,
                top: -18,
                child: _SpecialBadge(piece: currentPiece, compact: true),
              ),
          ],
        ),
      ),
      childWhenDragging: Opacity(opacity: 0.18, child: child),
      child: child,
    );
  }
}

class _SpecialBadge extends StatelessWidget {
  const _SpecialBadge({required this.piece, this.compact = false});

  final BlockPiece piece;
  final bool compact;

  IconData get _icon {
    switch (piece.power) {
      case PiecePower.bomb:
        return Icons.brightness_7_rounded;
      case PiecePower.rowClear:
        return Icons.swap_horiz_rounded;
      case PiecePower.columnClear:
        return Icons.swap_vert_rounded;
      case PiecePower.wild:
        return Icons.auto_awesome_rounded;
      case PiecePower.normal:
        return Icons.square_rounded;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: compact
          ? const EdgeInsets.all(5)
          : const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
      decoration: BoxDecoration(
        color: const Color(0xFF0A0806).withValues(alpha: 0.92),
        borderRadius: BorderRadius.circular(9),
        border: Border.all(color: const Color(0xFFFFD98B).withValues(alpha: 0.5)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Icon(_icon, size: 12, color: const Color(0xFFFFD98B)),
          if (!compact) ...<Widget>[
            const SizedBox(width: 4),
            Text(
              piece.powerLabel,
              style: const TextStyle(
                color: Color(0xFFFFD98B),
                fontSize: 7,
                fontWeight: FontWeight.w900,
                letterSpacing: 0.4,
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _GameToolButton extends StatelessWidget {
  const _GameToolButton({
    required this.icon,
    required this.label,
    required this.charge,
    required this.enabled,
    required this.onPressed,
  });

  final IconData icon;
  final String label;
  final int charge;
  final bool enabled;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white.withValues(alpha: enabled ? 0.05 : 0.025),
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        onTap: enabled ? onPressed : null,
        borderRadius: BorderRadius.circular(14),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 9),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Icon(
                icon,
                size: 17,
                color: enabled ? const Color(0xFFFFD98B) : Colors.white24,
              ),
              const SizedBox(width: 4),
              Flexible(
                child: Text(
                label,
                style: TextStyle(
                  color: enabled ? Colors.white70 : Colors.white24,
                  fontSize: 9,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 0.4,
                ),
                overflow: TextOverflow.ellipsis,
                maxLines: 1,
              ),
              ),
              const SizedBox(width: 4),
              Container(
                width: 20,
                height: 20,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: enabled
                      ? const Color(0xFFFFC86E).withValues(alpha: 0.14)
                      : Colors.white.withValues(alpha: 0.025),
                ),
                child: Text(
                  '$charge',
                  style: TextStyle(
                    color: enabled ? const Color(0xFFFFD98B) : Colors.white24,
                    fontSize: 9,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _DialogStat extends StatelessWidget {
  const _DialogStat({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        Text(
          value,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 17,
            fontWeight: FontWeight.w900,
          ),
        ),
        const SizedBox(height: 3),
        Text(
          label,
          textAlign: TextAlign.center,
          style: const TextStyle(
            color: Colors.white38,
            fontSize: 7,
            letterSpacing: 0.8,
          ),
        ),
      ],
    );
  }
}

class _Particle {
  const _Particle({
    required this.x,
    required this.y,
    required this.vx,
    required this.vy,
    required this.radius,
  });

  final double x;
  final double y;
  final double vx;
  final double vy;
  final double radius;
}

class _ParticleBurstPainter extends CustomPainter {
  const _ParticleBurstPainter({
    required this.particles,
    required this.progress,
    required this.color,
  });

  final List<_Particle> particles;
  final double progress;
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final t = Curves.easeOutCubic.transform(
      progress.clamp(0.0, 1.0).toDouble(),
    );
    final alpha = (1 - progress).clamp(0.0, 1.0).toDouble();
    final paint = Paint()..style = PaintingStyle.fill;

    for (final particle in particles) {
      final x = (particle.x + particle.vx * t) * size.width;
      final y = (particle.y + particle.vy * t + 0.10 * t * t) * size.height;
      paint.color = color.withValues(alpha: 0.88 * alpha);
      canvas.drawCircle(
        Offset(x, y),
        particle.radius * (1 - 0.35 * t),
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _ParticleBurstPainter oldDelegate) {
    return oldDelegate.progress != progress ||
        oldDelegate.particles != particles ||
        oldDelegate.color != color;
  }
}

class _Rule extends StatelessWidget {
  const _Rule({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Text(
        text,
        style: const TextStyle(color: Colors.white70, height: 1.35),
      ),
    );
  }
}
