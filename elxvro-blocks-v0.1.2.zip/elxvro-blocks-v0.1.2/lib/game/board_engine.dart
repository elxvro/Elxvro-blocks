import '../models/block_piece.dart';

class PlacementResult {
  const PlacementResult({
    required this.placedCells,
    required this.clearedRows,
    required this.clearedColumns,
  });

  final int placedCells;
  final List<int> clearedRows;
  final List<int> clearedColumns;

  int get clearedLines => clearedRows.length + clearedColumns.length;
}

class BoardEngine {
  BoardEngine({this.size = 10})
      : grid = List<List<bool>>.generate(
          size,
          (_) => List<bool>.filled(size, false),
        );

  final int size;
  final List<List<bool>> grid;

  void reset() {
    for (final row in grid) {
      row.fillRange(0, row.length, false);
    }
  }

  bool canPlace(BlockPiece piece, int originRow, int originCol) {
    for (final cell in piece.cells) {
      final row = originRow + cell.row;
      final col = originCol + cell.col;
      if (row < 0 || col < 0 || row >= size || col >= size) {
        return false;
      }
      if (grid[row][col]) {
        return false;
      }
    }
    return true;
  }

  PlacementResult? place(BlockPiece piece, int originRow, int originCol) {
    if (!canPlace(piece, originRow, originCol)) {
      return null;
    }

    for (final cell in piece.cells) {
      grid[originRow + cell.row][originCol + cell.col] = true;
    }

    final rows = <int>[];
    final columns = <int>[];

    for (var row = 0; row < size; row++) {
      if (grid[row].every((value) => value)) {
        rows.add(row);
      }
    }

    for (var col = 0; col < size; col++) {
      var full = true;
      for (var row = 0; row < size; row++) {
        if (!grid[row][col]) {
          full = false;
          break;
        }
      }
      if (full) {
        columns.add(col);
      }
    }

    for (final row in rows) {
      for (var col = 0; col < size; col++) {
        grid[row][col] = false;
      }
    }
    for (final col in columns) {
      for (var row = 0; row < size; row++) {
        grid[row][col] = false;
      }
    }

    return PlacementResult(
      placedCells: piece.size,
      clearedRows: rows,
      clearedColumns: columns,
    );
  }

  bool hasMoveFor(BlockPiece piece) {
    for (var row = 0; row < size; row++) {
      for (var col = 0; col < size; col++) {
        if (canPlace(piece, row, col)) {
          return true;
        }
      }
    }
    return false;
  }

  bool hasAnyMove(Iterable<BlockPiece> pieces) {
    return pieces.any(hasMoveFor);
  }
}
