import 'dart:math';

class CellOffset {
  const CellOffset(this.row, this.col);

  final int row;
  final int col;
}

class BlockPiece {
  const BlockPiece({required this.id, required this.cells});

  final String id;
  final List<CellOffset> cells;

  int get rows => cells.map((cell) => cell.row).reduce(max) + 1;
  int get cols => cells.map((cell) => cell.col).reduce(max) + 1;
  int get size => cells.length;
}

const List<BlockPiece> blockCatalog = <BlockPiece>[
  BlockPiece(id: 'single', cells: <CellOffset>[CellOffset(0, 0)]),
  BlockPiece(
    id: 'domino_h',
    cells: <CellOffset>[CellOffset(0, 0), CellOffset(0, 1)],
  ),
  BlockPiece(
    id: 'domino_v',
    cells: <CellOffset>[CellOffset(0, 0), CellOffset(1, 0)],
  ),
  BlockPiece(
    id: 'line_3_h',
    cells: <CellOffset>[
      CellOffset(0, 0),
      CellOffset(0, 1),
      CellOffset(0, 2),
    ],
  ),
  BlockPiece(
    id: 'line_3_v',
    cells: <CellOffset>[
      CellOffset(0, 0),
      CellOffset(1, 0),
      CellOffset(2, 0),
    ],
  ),
  BlockPiece(
    id: 'line_4_h',
    cells: <CellOffset>[
      CellOffset(0, 0),
      CellOffset(0, 1),
      CellOffset(0, 2),
      CellOffset(0, 3),
    ],
  ),
  BlockPiece(
    id: 'line_4_v',
    cells: <CellOffset>[
      CellOffset(0, 0),
      CellOffset(1, 0),
      CellOffset(2, 0),
      CellOffset(3, 0),
    ],
  ),
  BlockPiece(
    id: 'square_2',
    cells: <CellOffset>[
      CellOffset(0, 0),
      CellOffset(0, 1),
      CellOffset(1, 0),
      CellOffset(1, 1),
    ],
  ),
  BlockPiece(
    id: 'l_small',
    cells: <CellOffset>[
      CellOffset(0, 0),
      CellOffset(1, 0),
      CellOffset(1, 1),
    ],
  ),
  BlockPiece(
    id: 'l_medium',
    cells: <CellOffset>[
      CellOffset(0, 0),
      CellOffset(1, 0),
      CellOffset(2, 0),
      CellOffset(2, 1),
      CellOffset(2, 2),
    ],
  ),
  BlockPiece(
    id: 't',
    cells: <CellOffset>[
      CellOffset(0, 0),
      CellOffset(0, 1),
      CellOffset(0, 2),
      CellOffset(1, 1),
    ],
  ),
  BlockPiece(
    id: 'z',
    cells: <CellOffset>[
      CellOffset(0, 0),
      CellOffset(0, 1),
      CellOffset(1, 1),
      CellOffset(1, 2),
    ],
  ),
  BlockPiece(
    id: 'corner_5',
    cells: <CellOffset>[
      CellOffset(0, 0),
      CellOffset(1, 0),
      CellOffset(2, 0),
      CellOffset(2, 1),
      CellOffset(2, 2),
    ],
  ),
  BlockPiece(
    id: 'square_3',
    cells: <CellOffset>[
      CellOffset(0, 0), CellOffset(0, 1), CellOffset(0, 2),
      CellOffset(1, 0), CellOffset(1, 1), CellOffset(1, 2),
      CellOffset(2, 0), CellOffset(2, 1), CellOffset(2, 2),
    ],
  ),
];
