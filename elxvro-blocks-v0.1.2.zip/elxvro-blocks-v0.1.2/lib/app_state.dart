import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AppState extends ChangeNotifier {
  static const String _bestScoreKey = 'best_score';
  static const String _themeKey = 'theme_id';
  static const String _gamesPlayedKey = 'games_played';
  static const String _maxComboKey = 'max_combo';

  int bestScore = 0;
  int gamesPlayed = 0;
  int maxCombo = 0;
  String themeId = 'classic';
  bool isLoaded = false;

  Future<void> load() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      bestScore = prefs.getInt(_bestScoreKey) ?? 0;
      gamesPlayed = prefs.getInt(_gamesPlayedKey) ?? 0;
      maxCombo = prefs.getInt(_maxComboKey) ?? 0;
      themeId = prefs.getString(_themeKey) ?? 'classic';
    } catch (error, stackTrace) {
      // Storage is non-critical. Keep the in-memory defaults and let the game
      // remain fully playable even if the platform plugin is unavailable.
      debugPrint('ELXVRO storage load failed: $error');
      debugPrintStack(stackTrace: stackTrace);
    } finally {
      isLoaded = true;
      notifyListeners();
    }
  }

  Future<void> setTheme(String id) async {
    themeId = id;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_themeKey, id);
    } catch (error) {
      debugPrint('ELXVRO theme save failed: $error');
    }
  }

  Future<void> recordGame({required int score, required int combo}) async {
    gamesPlayed += 1;
    if (score > bestScore) {
      bestScore = score;
    }
    if (combo > maxCombo) {
      maxCombo = combo;
    }
    notifyListeners();

    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt(_bestScoreKey, bestScore);
      await prefs.setInt(_gamesPlayedKey, gamesPlayed);
      await prefs.setInt(_maxComboKey, maxCombo);
    } catch (error) {
      debugPrint('ELXVRO stats save failed: $error');
    }
  }
}
