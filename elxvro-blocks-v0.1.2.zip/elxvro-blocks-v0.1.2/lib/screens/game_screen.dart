import 'dart:math';

import 'package:flutter/material.dart';

import '../app_state.dart';
import '../game/board_engine.dart';
import '../models/block_piece.dart';
import '../models/game_theme.dart';
import '../widgets/piece_preview.dart';
import '../widgets/premium_background.dart';

class GameScreen extends StatefulWidget {
  const GameScreen({super.key, required this.appState});

  final AppState appState;

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  static const int _boardSize = 10;
  final BoardEngine _engine = BoardEngine(size: _boardSize);
  final Random _random = Random();
  final GlobalKey _boardKey = GlobalKey();

  late List<BlockPiece?> _pieces;
  int _score = 0;
  int _combo = 0;
  int _bestComboThisGame = 0;
  int? _hoverRow;
  int? _hoverCol;
  int? _hoverPieceIndex;
  bool _finishing = false;

  GameThemeData get _theme => gameThemes.firstWhere(
        (theme) => theme.id == widget.appState.themeId,
        orElse: () => gameThemes.first,
      );

  @override
  void initState() {
    super.initState();
    _pieces = _generatePieces();
  }

  List<BlockPiece?> _generatePieces() {
    return List<BlockPiece?>.generate(
      3,
      (_) => blockCatalog[_random.nextInt(blockCatalog.length)],
    );
  }

  void _resetGame() {
    setState(() {
      _engine.reset();
      _pieces = _generatePieces();
      _score = 0;
      _combo = 0;
      _bestComboThisGame = 0;
      _hoverRow = null;
      _hoverCol = null;
      _hoverPieceIndex = null;
      _finishing = false;
    });
  }

  void _updateHover(DragTargetDetails<int> details, double boardExtent) {
    final renderObject = _boardKey.currentContext?.findRenderObject();
    if (renderObject is! RenderBox) {
      return;
    }
    final local = renderObject.globalToLocal(details.offset);
    final cell = boardExtent / _boardSize;
    final col = (local.dx / cell).floor();
    final row = (local.dy / cell).floor();

    setState(() {
      _hoverPieceIndex = details.data;
      _hoverRow = row;
      _hoverCol = col;
    });
  }

  void _acceptPiece(DragTargetDetails<int> details, double boardExtent) {
    final index = details.data;
    final piece = _pieces[index];
    if (piece == null) {
      return;
    }
    final renderObject = _boardKey.currentContext?.findRenderObject();
    if (renderObject is! RenderBox) {
      return;
    }

    final local = renderObject.globalToLocal(details.offset);
    final cell = boardExtent / _boardSize;
    final col = (local.dx / cell).floor();
    final row = (local.dy / cell).floor();
    final result = _engine.place(piece, row, col);

    if (result == null) {
      setState(() {
        _hoverPieceIndex = null;
        _hoverRow = null;
        _hoverCol = null;
      });
      return;
    }

    setState(() {
      _pieces[index] = null;
      final lineCount = result.clearedLines;
      if (lineCount > 0) {
        _combo += 1;
        _bestComboThisGame = max(_bestComboThisGame, _combo);
      } else {
        _combo = 0;
      }
      _score += result.placedCells * 10;
      _score += lineCount * 120 * max(1, _combo);

      _hoverPieceIndex = null;
      _hoverRow = null;
      _hoverCol = null;

      if (_pieces.every((piece) => piece == null)) {
        _pieces = _generatePieces();
      }
    });

    _checkGameOver();
  }

  Future<void> _checkGameOver() async {
    final available = _pieces.whereType<BlockPiece>().toList();
    if (available.isNotEmpty && _engine.hasAnyMove(available)) {
      return;
    }
    if (_finishing) {
      return;
    }
    _finishing = true;

    await widget.appState.recordGame(
      score: _score,
      combo: _bestComboThisGame,
    );
    if (!mounted) {
      return;
    }

    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return AlertDialog(
          backgroundColor: const Color(0xFF12100E),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
          title: const Text(
            'OYUN BİTTİ',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Color(0xFFFFD98B),
              letterSpacing: 2.5,
              fontWeight: FontWeight.w700,
            ),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              const Text(
                'Harika bir oyun çıkardın.',
                style: TextStyle(color: Colors.white54),
              ),
              const SizedBox(height: 22),
              const Text('SKOR', style: TextStyle(color: Colors.white38, fontSize: 11)),
              Text(
                '$_score',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 38,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'EN YÜKSEK  ${widget.appState.bestScore}',
                style: const TextStyle(color: Color(0xFFFFC86E), fontSize: 12),
              ),
            ],
          ),
          actionsAlignment: MainAxisAlignment.center,
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.of(context).pop();
              },
              child: const Text('ANA MENÜ'),
            ),
            FilledButton(
              onPressed: () {
                Navigator.of(context).pop();
                _resetGame();
              },
              style: FilledButton.styleFrom(
                backgroundColor: const Color(0xFFC7863C),
                foregroundColor: const Color(0xFF160D06),
              ),
              child: const Text('TEKRAR OYNA'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: PremiumBackground(
        top: _theme.backgroundTop,
        bottom: _theme.backgroundBottom,
        child: SafeArea(
          child: LayoutBuilder(
            builder: (context, constraints) {
              final boardExtent = min(constraints.maxWidth - 28, 430.0);
              final cellSize = boardExtent / _boardSize;
              return Column(
                children: <Widget>[
                  _TopBar(
                    score: _score,
                    best: max(widget.appState.bestScore, _score),
                    onBack: () => Navigator.of(context).pop(),
                    onHelp: () => _showHowToPlay(context),
                  ),
                  if (_combo > 1)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 6),
                      child: Text(
                        'COMBO x$_combo',
                        style: const TextStyle(
                          color: Color(0xFFFFD98B),
                          fontWeight: FontWeight.w900,
                          letterSpacing: 2.0,
                        ),
                      ),
                    ),
                  const SizedBox(height: 4),
                  SizedBox(
                    width: boardExtent,
                    height: boardExtent,
                    child: DragTarget<int>(
                      onWillAcceptWithDetails: (details) {
                        _updateHover(details, boardExtent);
                        return true;
                      },
                      onMove: (details) => _updateHover(details, boardExtent),
                      onLeave: (_) {
                        setState(() {
                          _hoverRow = null;
                          _hoverCol = null;
                          _hoverPieceIndex = null;
                        });
                      },
                      onAcceptWithDetails: (details) =>
                          _acceptPiece(details, boardExtent),
                      builder: (context, candidateData, rejectedData) {
                        return Container(
                          key: _boardKey,
                          padding: const EdgeInsets.all(5),
                          decoration: BoxDecoration(
                            color: _theme.board,
                            borderRadius: BorderRadius.circular(18),
                            border: Border.all(
                              color: _theme.blockAccent.withValues(alpha: 0.35),
                            ),
                            boxShadow: <BoxShadow>[
                              BoxShadow(
                                color: Colors.black.withValues(alpha: 0.40),
                                blurRadius: 28,
                              ),
                            ],
                          ),
                          child: _BoardGrid(
                            engine: _engine,
                            theme: _theme,
                            hoverRow: _hoverRow,
                            hoverCol: _hoverCol,
                            hoverPiece: _hoverPieceIndex == null
                                ? null
                                : _pieces[_hoverPieceIndex!],
                            cellSize: cellSize,
                          ),
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 18),
                  Expanded(
                    child: Align(
                      alignment: Alignment.topCenter,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: List<Widget>.generate(3, (index) {
                          final piece = _pieces[index];
                          return Expanded(
                            child: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 5),
                              child: _PieceSlot(
                                piece: piece,
                                index: index,
                                theme: _theme,
                              ),
                            ),
                          );
                        }),
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  void _showHowToPlay(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF111111),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: (_) => const Padding(
        padding: EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              'NASIL OYNANIR?',
              style: TextStyle(
                color: Color(0xFFFFD98B),
                fontWeight: FontWeight.w800,
                letterSpacing: 1.7,
              ),
            ),
            SizedBox(height: 18),
            _Rule(text: '1. Alttaki blokları sürükleyip tahtaya yerleştir.'),
            _Rule(text: '2. Bir satır veya sütunu tamamen doldur ve temizle.'),
            _Rule(text: '3. Arka arkaya temizlik yaparak combo puanını büyüt.'),
            _Rule(text: '4. Hiçbir blok yerleşemediğinde oyun biter.'),
          ],
        ),
      ),
    );
  }
}

class _TopBar extends StatelessWidget {
  const _TopBar({
    required this.score,
    required this.best,
    required this.onBack,
    required this.onHelp,
  });

  final int score;
  final int best;
  final VoidCallback onBack;
  final VoidCallback onHelp;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 6, 8, 10),
      child: Row(
        children: <Widget>[
          IconButton(onPressed: onBack, icon: const Icon(Icons.arrow_back_rounded)),
          Expanded(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                _ScoreBlock(label: 'EN YÜKSEK', value: '$best', icon: Icons.emoji_events_rounded),
                const SizedBox(width: 28),
                _ScoreBlock(label: 'SKOR', value: '$score'),
              ],
            ),
          ),
          IconButton(onPressed: onHelp, icon: const Icon(Icons.help_outline_rounded)),
        ],
      ),
    );
  }
}

class _ScoreBlock extends StatelessWidget {
  const _ScoreBlock({required this.label, required this.value, this.icon});

  final String label;
  final String value;
  final IconData? icon;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        Row(
          children: <Widget>[
            if (icon != null) ...<Widget>[
              Icon(icon, size: 16, color: const Color(0xFFFFC66D)),
              const SizedBox(width: 5),
            ],
            Text(
              value,
              style: const TextStyle(
                fontSize: 21,
                fontWeight: FontWeight.w800,
                color: Colors.white,
              ),
            ),
          ],
        ),
        Text(
          label,
          style: const TextStyle(
            color: Colors.white38,
            fontSize: 8,
            fontWeight: FontWeight.w600,
            letterSpacing: 1.2,
          ),
        ),
      ],
    );
  }
}

class _BoardGrid extends StatelessWidget {
  const _BoardGrid({
    required this.engine,
    required this.theme,
    required this.hoverRow,
    required this.hoverCol,
    required this.hoverPiece,
    required this.cellSize,
  });

  final BoardEngine engine;
  final GameThemeData theme;
  final int? hoverRow;
  final int? hoverCol;
  final BlockPiece? hoverPiece;
  final double cellSize;

  bool _isHoveredCell(int row, int col) {
    final piece = hoverPiece;
    final originRow = hoverRow;
    final originCol = hoverCol;
    if (piece == null || originRow == null || originCol == null) {
      return false;
    }
    return piece.cells.any(
      (cell) => originRow + cell.row == row && originCol + cell.col == col,
    );
  }

  @override
  Widget build(BuildContext context) {
    final canPlace = hoverPiece != null && hoverRow != null && hoverCol != null
        ? engine.canPlace(hoverPiece!, hoverRow!, hoverCol!)
        : false;

    return GridView.builder(
      physics: const NeverScrollableScrollPhysics(),
      padding: EdgeInsets.zero,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: _GameScreenState._boardSize,
        mainAxisSpacing: 2,
        crossAxisSpacing: 2,
      ),
      itemCount: engine.size * engine.size,
      itemBuilder: (context, index) {
        final row = index ~/ engine.size;
        final col = index % engine.size;
        final filled = engine.grid[row][col];
        final hovered = _isHoveredCell(row, col);
        final hoverColor = canPlace
            ? theme.blockAccent.withValues(alpha: 0.55)
            : const Color(0xFFFF4D4D).withValues(alpha: 0.42);
        return AnimatedContainer(
          duration: const Duration(milliseconds: 90),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(max(2.5, cellSize * 0.10)),
            color: filled
                ? null
                : hovered
                    ? hoverColor
                    : theme.cell,
            gradient: filled
                ? LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: <Color>[theme.blockAccent, theme.block],
                  )
                : null,
            border: Border.all(
              color: filled
                  ? theme.blockAccent.withValues(alpha: 0.55)
                  : Colors.white.withValues(alpha: 0.035),
              width: 0.7,
            ),
            boxShadow: filled
                ? <BoxShadow>[
                    BoxShadow(
                      color: theme.blockAccent.withValues(alpha: 0.18),
                      blurRadius: 7,
                    ),
                  ]
                : null,
          ),
        );
      },
    );
  }
}

class _PieceSlot extends StatelessWidget {
  const _PieceSlot({
    required this.piece,
    required this.index,
    required this.theme,
  });

  final BlockPiece? piece;
  final int index;
  final GameThemeData theme;

  @override
  Widget build(BuildContext context) {
    final child = Container(
      height: 116,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.035),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withValues(alpha: 0.045)),
      ),
      child: piece == null
          ? const SizedBox.shrink()
          : PiecePreview(
              piece: piece!,
              color: theme.block,
              accent: theme.blockAccent,
              cellSize: piece!.rows >= 3 || piece!.cols >= 3 ? 22 : 27,
            ),
    );

    if (piece == null) {
      return child;
    }

    return Draggable<int>(
      data: index,
      feedback: Material(
        color: Colors.transparent,
        child: PiecePreview(
          piece: piece!,
          color: theme.block,
          accent: theme.blockAccent,
          cellSize: 28,
        ),
      ),
      childWhenDragging: Opacity(opacity: 0.2, child: child),
      child: child,
    );
  }
}

class _Rule extends StatelessWidget {
  const _Rule({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Text(text, style: const TextStyle(color: Colors.white70, height: 1.35)),
    );
  }
}
