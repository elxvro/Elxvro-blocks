import 'package:flutter/material.dart';

import '../app_state.dart';
import '../models/game_theme.dart';
import '../widgets/crystal_mark.dart';
import '../widgets/premium_background.dart';
import '../widgets/premium_button.dart';
import 'game_screen.dart';
import 'themes_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key, required this.appState});

  final AppState appState;

  @override
  Widget build(BuildContext context) {
    final selectedTheme = gameThemes.firstWhere(
      (theme) => theme.id == appState.themeId,
      orElse: () => gameThemes.first,
    );

    return Scaffold(
      body: PremiumBackground(
        top: selectedTheme.backgroundTop,
        bottom: selectedTheme.backgroundBottom,
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 28),
            child: Column(
              children: <Widget>[
                const Spacer(flex: 2),
                const Text(
                  'ELXVRO',
                  style: TextStyle(
                    fontSize: 38,
                    fontWeight: FontWeight.w300,
                    letterSpacing: 10,
                    color: Color(0xFFFFD99A),
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'B L O C K S',
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 7,
                    color: Colors.white.withValues(alpha: 0.78),
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  'SIMPLE MOVES  •  BIG MOMENTS',
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w500,
                    letterSpacing: 2.2,
                    color: Colors.white.withValues(alpha: 0.42),
                  ),
                ),
                const Spacer(),
                const CrystalMark(size: 150),
                const Spacer(),
                if (appState.bestScore > 0)
                  Text(
                    'EN YÜKSEK  ${appState.bestScore}',
                    style: const TextStyle(
                      color: Color(0xFFFFD98B),
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 1.8,
                    ),
                  ),
                const SizedBox(height: 18),
                SizedBox(
                  width: double.infinity,
                  child: PremiumButton(
                    label: 'OYNA',
                    icon: Icons.play_arrow_rounded,
                    onPressed: () {
                      Navigator.of(context).push(
                        MaterialPageRoute<void>(
                          builder: (_) => GameScreen(appState: appState),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: <Widget>[
                    Expanded(
                      child: _HomeTile(
                        icon: Icons.palette_outlined,
                        label: 'TEMALAR',
                        onTap: () {
                          Navigator.of(context).push(
                            MaterialPageRoute<void>(
                              builder: (_) => ThemesScreen(appState: appState),
                            ),
                          );
                        },
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _HomeTile(
                        icon: Icons.emoji_events_outlined,
                        label: 'BAŞARIMLAR',
                        onTap: () => _showComingSoon(context, 'Başarımlar'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _HomeTile(
                        icon: Icons.bar_chart_rounded,
                        label: 'İSTATİSTİK',
                        onTap: () => _showStats(context),
                      ),
                    ),
                  ],
                ),
                const Spacer(flex: 2),
                Text(
                  'ELXVRO  •  PLAY BEAUTIFULLY',
                  style: TextStyle(
                    color: Colors.white.withValues(alpha: 0.30),
                    fontSize: 9,
                    letterSpacing: 2.0,
                  ),
                ),
                const SizedBox(height: 18),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showComingSoon(BuildContext context, String title) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF111111),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
      ),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(28),
        child: Text(
          '$title sonraki sürümde aktif olacak.',
          style: const TextStyle(color: Colors.white70, fontSize: 16),
        ),
      ),
    );
  }

  void _showStats(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF111111),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
      ),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            _StatRow(label: 'En yüksek skor', value: '${appState.bestScore}'),
            _StatRow(label: 'Oynanan oyun', value: '${appState.gamesPlayed}'),
            _StatRow(label: 'Maksimum combo', value: 'x${appState.maxCombo}'),
          ],
        ),
      ),
    );
  }
}

class _HomeTile extends StatelessWidget {
  const _HomeTile({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white.withValues(alpha: 0.045),
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 16),
          child: Column(
            children: <Widget>[
              const SizedBox(height: 2),
              Icon(icon, color: const Color(0xFFFFCF7A), size: 23),
              const SizedBox(height: 8),
              Text(
                label,
                maxLines: 1,
                style: const TextStyle(
                  color: Colors.white70,
                  fontSize: 9,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.8,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StatRow extends StatelessWidget {
  const _StatRow({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        children: <Widget>[
          Expanded(
            child: Text(label, style: const TextStyle(color: Colors.white60)),
          ),
          Text(
            value,
            style: const TextStyle(
              color: Color(0xFFFFD98B),
              fontWeight: FontWeight.w800,
              fontSize: 18,
            ),
          ),
        ],
      ),
    );
  }
}
