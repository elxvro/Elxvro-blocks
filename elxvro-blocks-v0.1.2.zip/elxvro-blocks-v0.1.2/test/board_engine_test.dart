import 'package:elxvro_blocks/game/board_engine.dart';
import 'package:elxvro_blocks/models/block_piece.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('BoardEngine', () {
    test('places a piece when cells are empty', () {
      final engine = BoardEngine(size: 10);
      const piece = BlockPiece(
        id: 'test',
        cells: <CellOffset>[CellOffset(0, 0), CellOffset(0, 1)],
      );

      final result = engine.place(piece, 2, 3);

      expect(result, isNotNull);
      expect(engine.grid[2][3], isTrue);
      expect(engine.grid[2][4], isTrue);
    });

    test('rejects overlapping placement', () {
      final engine = BoardEngine(size: 10);
      const piece = BlockPiece(
        id: 'test',
        cells: <CellOffset>[CellOffset(0, 0)],
      );

      expect(engine.place(piece, 0, 0), isNotNull);
      expect(engine.place(piece, 0, 0), isNull);
    });

    test('clears a completed row', () {
      final engine = BoardEngine(size: 4);
      const single = BlockPiece(
        id: 'single',
        cells: <CellOffset>[CellOffset(0, 0)],
      );

      for (var col = 0; col < 3; col++) {
        engine.place(single, 0, col);
      }
      final result = engine.place(single, 0, 3);

      expect(result, isNotNull);
      expect(result!.clearedRows, contains(0));
      expect(engine.grid[0].every((value) => value == false), isTrue);
    });
  });
}
