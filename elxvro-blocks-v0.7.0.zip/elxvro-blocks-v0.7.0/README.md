# ELXVRO Blocks v0.7.0 — Social Ready & Weekly League

Bu sürüm Play Console kurulumu yapılmadan önce sosyal/online katmanı oyuna güvenli şekilde hazırlar. Gerçek Google Play Games bağlantısı taklit edilmez; uygulama çevrimdışı çalışmaya devam eder.

## Yeni özellikler

- Liderlik Merkezi ekranı
- Klasik, 2 Dakika, Hedef ve Günlük mod için kişisel rekor kartları
- Haftalık lig ilerlemesi
  - Haftalık toplam skor hedefi: 25.000
  - Haftalık oyun sayısı
  - Haftalık en iyi skor
  - Hedef tamamlanınca tek seferlik +250 coin
  - Pazartesi başlayan otomatik haftalık sıfırlama
- Profilde değiştirilebilir oyuncu adı (maksimum 18 karakter)
- Oyun sonunda yeni kişisel rekor rozeti
- Google Play Games için servis/adaptör katmanı
  - Şimdilik LocalSocialService kullanılır
  - Sahte online sıralama gösterilmez
  - Play Console yapılandırılınca gerçek servis aynı arayüze bağlanabilir
- Ayarlar ekranında Play Games hazırlık durumu
- v0.6.0 özelliklerinin tamamı korunur

## Google Play Games notu

Gerçek Play Games entegrasyonu için Play Console'da uygulama kaydı, sabit paket adı, yayın/imza SHA-1 bilgisi, leaderboard ve achievement kimlikleri gerekir. Android üretiminde kullanılan hedef paket adı `com.elxvro.elxvro_blocks` olarak korunmalıdır.

## Build

Repo köküne `elxvro-blocks-v0.7.0.zip` yüklenebilir. Workflow ZIP'i açar, Flutter Android platform dosyalarını üretir, `flutter analyze`, `flutter test` ve release APK build çalıştırır.

Beklenen artifact: `ELXVRO-Blocks-v0.7.0`
