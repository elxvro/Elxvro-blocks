# ELXVRO Blocks v0.10.0 — Market / Gameplay Research

Research date: 2026-09-18

This update studies interaction patterns from successful block-puzzle games, then re-implements the useful principles in ELXVRO's own visual/audio language. No competitor artwork, audio, branding, layouts, or proprietary assets are copied.

## Benchmarks reviewed

### Block Blast! — HungryStudio
- Current Google Play listing: 1B+ downloads, 4.8 rating, 8x8 drag-and-drop board.
- Core retention loop emphasizes quick placement, row/column clears, combos/streaks, daily content, and offline play.
- Store copy repeatedly frames the experience as smooth, relaxing, and rewarding rather than mechanically complex.
- Source: https://play.google.com/store/apps/details?id=com.block.juggle

### Woodoku — Tripledot Studios
- Current Google Play listing: 100M+ downloads.
- Uses a 9x9 board and rewards line, column, and square clears.
- Explicitly promotes satisfying sound effects and daily puzzle content.
- Source: https://play.google.com/store/apps/details?id=com.tripledot.woodoku

### Blockudoku — Easybrain
- Current Google Play listing: 100M+ downloads.
- Strong emphasis on streaks, combos, daily challenges, tournaments, and watching blocks blast away.
- Source: https://play.google.com/store/apps/details?id=com.easybrain.block.puzzle.games

### Hexa Sort / current sort-puzzle design patterns
- Current listings emphasize polished 3D surfaces, smooth motion, responsive haptics, chain reactions, optional boosts, and autosave.
- These patterns are relevant to game feel even though the board mechanic differs from ELXVRO.

### Community feedback reviewed
- Block-puzzle players frequently call out FX / block design and the feeling of combo streaks as a major source of satisfaction.
- Separate feedback in the category also shows that effects that are much louder than the music can break the relaxing flow, so ELXVRO keeps strong event hierarchy instead of making every move loud.

## Design rules applied to ELXVRO

1. **Board first** — score and mode information are compact; the board and three-piece tray remain the visual focus.
2. **Tray next to playfield** — pieces now sit immediately below the board; tools are secondary.
3. **Feedback hierarchy** — normal placement is subtle, clear is stronger, multi-clear / combo adds shockwave + punch, Perfect Clear is premium, live record is celebratory.
4. **Score where the action happens** — points rise from the cleared area instead of only changing in the HUD.
5. **Persistent streak readability** — combo becomes a dedicated streak meter rather than a single text label.
6. **Record chase visibility** — best-score progress is always visible and crossing it triggers an in-run celebration.
7. **Danger without panic** — a nearly full board gains a restrained warning tint instead of a disruptive modal.
8. **Tactile placement** — freshly placed cells perform a short snap/bounce so drag-and-drop feels physical.
9. **Controlled camera punch** — multi-line / high-combo clears produce a short board impulse; Performance Mode reduces it.
10. **Audio hierarchy** — real material SFX remain the base. Big events briefly duck background music so combo / record cues read clearly without permanently raising SFX volume.
11. **Anti-frustration tray** — when a newly generated tray is completely unusable, the game makes a few reroll attempts. It does not prevent genuine game-over states.
12. **No clone design** — ELXVRO keeps its material themes, progression, modes, tools, economy, and 10x10 identity rather than duplicating a competitor's screen or art direction.

## v0.10.0 implementation

- Rebuilt in-game HUD with score hierarchy + live record progress.
- New streak meter and board-danger state.
- Board shockwave, controlled punch/shake, and radial clear feedback.
- Floating score / combo feedback at the clear location.
- Placement snap animation per newly placed cell.
- Live record celebration while the run is still active.
- Piece tray moved directly below the board and given reveal animation.
- Tools reduced to a secondary row below the tray.
- Fair-tray reroll protection for completely dead random trays.
- Dynamic background-music ducking for major combo, Perfect Clear, reward, and record moments.
- Existing real material sound pipeline and theme-specific particles retained.
