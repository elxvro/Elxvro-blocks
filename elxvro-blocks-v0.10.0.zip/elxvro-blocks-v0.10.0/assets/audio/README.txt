ELXVRO Blocks v0.9.7 audio assets

Direction: modern casual-puzzle sound design: short, clean, material-readable, non-fatiguing.
All sounds are original procedural synthesis created for ELXVRO. No third-party recordings or copied game audio.

Material language:
- Glass: delicate tap + crystal shimmer; clears sweep/chime rather than smash.
- Wood/Dal: hollow knock + soft twig texture.
- Stone: muted rock knock + pebble roll; no explosive boom.
- Leaf: airy rustle/swipe.
- Crystal: bell-like resonances and rising sparkle.
- Marble: polished ceramic/stone knock + restrained ring.
- UI: short tactile soft taps, intentionally not DTMF/keypad-like.
- New record: rising celebratory fanfare + confetti sparkle.
- Music: sparse 32s warm ambient pad loop with rare soft chimes.

Build note: These bundled assets are fallback/dev assets. GitHub Actions v0.10.0 replaces material recordings and puzzle music with the verified CC0 build pipeline before release artifacts are created.
