# ELXVRO Blocks v0.10.0 — Gameplay Rebuild

v0.10.0 is a research-driven in-game feel update. The core ELXVRO systems remain intact, but the play screen, clear feedback, combo presentation, record chase, piece tray, audio hierarchy and moment-to-moment motion were rebuilt around the strongest patterns seen in successful modern block-puzzle games.

## Main gameplay changes

- Cleaner **board-first HUD** with large live score and visible record progress.
- **Streak meter** replaces the old plain combo label.
- **Floating score feedback** appears at the clear location (`+score`, combo multiplier on important clears).
- Multi-line / high-combo clears add a restrained **shockwave + board punch**.
- Newly placed cells have a short **snap/bounce** so drop feedback feels tactile.
- Near-full boards get a subtle **danger state** instead of an intrusive warning.
- Crossing the previous best score triggers an in-run **YENİ REKOR** celebration.
- Piece tray moved immediately below the board and pieces reveal with a short animation.
- Undo / Refresh / Special controls are visually secondary to the core board + tray loop.
- Completely dead random trays get a small number of reroll attempts to avoid unfair instant dead-ends; genuine no-move states still end the run.

## Effects and audio

- Existing theme-specific material debris remains: glass shards, wood chips, stone fragments, leaves, crystal and marble particles.
- Clear hierarchy is now: placement < clear < multi-clear/combo < Perfect Clear < live record.
- Strong moments briefly **duck background music** so important material and celebration sounds read clearly without making normal SFX louder all the time.
- Real material audio pipeline from earlier releases is preserved.
- Human-composed CC0 puzzle music pipeline is preserved.
- Performance Mode automatically reduces heavy visual feedback.

## Research notes

See `MARKET_RESEARCH.md` for the benchmark review and the design principles used for this update. The update borrows interaction principles only; competitor assets, audio, branding and trade dress are not copied.

## Build

Upload `elxvro-blocks-v0.10.0.zip` to the repository root and use `.github/workflows/build-apk.yml`.

The workflow:
1. validates and extracts the ZIP,
2. generates the Android platform,
3. applies ELXVRO branding/signing configuration,
4. fetches verified real material recordings and CC0 puzzle music,
5. runs `flutter analyze` and `flutter test`,
6. builds release APK + AAB,
7. packages obfuscation symbols and SHA-256 checksums.

Flutter package version: `0.10.0+26`.
