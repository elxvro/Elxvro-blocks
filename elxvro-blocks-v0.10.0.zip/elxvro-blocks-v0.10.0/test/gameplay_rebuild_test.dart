import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

void main() {
  test('v0.10.0 gameplay feedback stack is wired', () {
    final game = File('lib/screens/game_screen.dart').readAsStringSync();
    final audio = File('lib/services/audio_service.dart').readAsStringSync();

    expect(game, contains('class _StreakMeter'));
    expect(game, contains('class _FloatingScoreOverlay'));
    expect(game, contains('class _ClearShockwavePainter'));
    expect(game, contains('class _LiveRecordOverlay'));
    expect(game, contains('_generateRawPieces'));
    expect(audio, contains('playLiveRecordCue'));
    expect(audio, contains('_duckMusic'));
  });
}
