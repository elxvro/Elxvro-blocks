# ELXVRO Blocks v0.9.8 — Real Material Audio

This release replaces synthesized material imitations in the GitHub-built APK/AAB with real recorded material audio.

## Material audio
- Glass: real glass taps + real glass break.
- Wood/Dal: real wood knocks + real twig snap.
- Leaf: real recorded leaf rustle.
- Stone: real stone/boulder impact and movement.
- Marble: real marble-floor resonance plus restrained stone body for clears.
- Crystal: real glass resonance with filtering only.

The build downloads only public-domain / CC0-compatible source recordings and creates short game-ready WAV assets. See `REAL_AUDIO_CREDITS.md`.

## Build
Upload `elxvro-blocks-v0.9.8.zip` to the repository root and use `.github/workflows/build-apk.yml`. The workflow installs FFmpeg, fetches the real recordings, runs analyze/tests, then builds APK and AAB.

Flutter package version: `0.9.8+22`.
