# ELXVRO Blocks v0.10.1 — 2D FX Engine

v0.10.1 keeps the v0.10.0 gameplay rebuild and replaces the light UI-style clear feedback with a stronger **theme-aware 2D effects layer**. The board remains Flutter-based; no heavy game-engine migration is required.

## New 2D gameplay effects

- **Glass:** transparent flying shards, bright edge highlights, radial crack lines and a short glass-flare streak.
- **Wood / Branch:** rotating splinters, wood chips and radial break lines.
- **Stone:** irregular rock fragments, impact cracks and expanding dust puffs.
- **Leaf:** drifting leaf silhouettes plus curved wind trails instead of generic particles.
- **Crystal:** faceted crystal pieces, white light beams and diamond-shaped burst accents.
- **Marble Gold:** marble chips, curved gold vein streaks and fine gold/white dust.
- Theme fragments now use both the material base color and accent instead of one generic particle color.
- Material-specific gravity and motion make stone fall heavy, leaves float, and glass/crystal scatter quickly.
- **COMBO x3+** now gets a short 2D starburst splash on the board; x5+ escalates to MEGA COMBO and x8+ to OVERDRIVE.
- Existing shockwave, board punch, floating `+score`, Perfect Clear, record celebration and themed game-over debris are preserved and layered with the new system.
- **Performance Mode** disables the heavier material overlay and combo starburst while keeping core gameplay readable.

## Audio

The verified real-material audio pipeline and composed CC0 puzzle music from v0.10.0 are unchanged. This release focuses on visual feel rather than replacing the audio set again.

## Build

Upload `elxvro-blocks-v0.10.1.zip` to the repository root and use `.github/workflows/build-apk.yml`.

The workflow validates/extracts the ZIP, generates Android, applies ELXVRO branding/signing, fetches verified audio, runs `flutter analyze` + `flutter test`, builds APK/AAB and packages symbols/checksums.

Flutter package version: `0.10.1+27`.
