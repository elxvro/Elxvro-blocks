import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

void main() {
  test('v0.10.1 2D FX engine is wired into gameplay', () {
    final game = File('lib/screens/game_screen.dart').readAsStringSync();

    expect(game, contains('class _Material2DOverlayPainter'));
    expect(game, contains('class _Combo2DSplash'));
    expect(game, contains('class _ComboStarburstPainter'));
    expect(game, contains('baseColor: _theme.block'));
    expect(game, contains('ThemeMaterial.glass'));
    expect(game, contains('ThemeMaterial.wood'));
    expect(game, contains('ThemeMaterial.stone'));
    expect(game, contains('ThemeMaterial.leaf'));
    expect(game, contains('ThemeMaterial.crystal'));
    expect(game, contains('ThemeMaterial.marble'));
  });
}
