# ELXVRO Blocks v0.4.1

Economy & Rewards sürümü.

## Yeni özellikler

- Kalıcı coin sistemi
- 7 günlük giriş serisi ve günlük ödül ekranı
- Günlük görevlerden claim edilebilir coin ödülleri
- Başarımlardan claim edilebilir coin ödülleri
- Mağaza ekranı
- Geri Al paketleri
- Yenile paketleri
- Özel Blok paketleri
- Power Bundle
- Tema kilidi ve coin ile kalıcı tema açma
- Eski oyuncunun seçili teması otomatik açık tutulur
- Oyun içinde 1 ücretsiz Geri Al + satın alınmış ekstra haklar
- Oyun içinde 1 ücretsiz Yenile + satın alınmış ekstra haklar
- Özel güç butonu ile eldeki bir parçayı özel bloğa çevirme
- Coin, envanter, ödül serisi ve satın alımlar SharedPreferences ile saklanır
- v0.3.1 premium gameplay özellikleri korunur

## GitHub ZIP build

Repo kökünde `elxvro-blocks-v0.4.1.zip` bulunmalı. ZIP açıldığında proje klasörü `elxvro-blocks-v0.4.1/` olarak oluşur.
