# ELXVRO Blocks v0.8.0 — Visual & Audio Polish

Bu sürüm v0.7.0 sosyal/haftalık altyapının üzerine mağaza sürümüne yaklaşan görsel ve ses katmanını ekler.

## Yeni

- Siyah/altın ELXVRO Blocks uygulama ikonu.
- Android adaptive icon üretimi.
- Android 12 dahil native siyah/altın splash.
- Flutter içinde kısa ELXVRO açılış animasyonu.
- Paket kimliği: `com.elxvro.elxvro_blocks`.
- Android uygulama etiketi: `ELXVRO Blocks`.
- Portre ekran kilidi.
- Bundled premium ambient arka plan müziği.
- Ayrı blok koyma, çizgi temizleme, combo, Perfect Clear, ödül, buton ve oyun sonu sesleri.
- Müzik aç/kapat ve efekt sesi aç/kapat.
- Ayrı müzik ve efekt ses seviyesi ayarları; değerler cihazda saklanır.
- Ayarlardan efekt sesi önizleme.
- Premium ana OYNA butonuna basma mikro animasyonu.
- Ana menü butonlarına dokunma sesi.
- Ödül, başarım, günlük görev, haftalık ödül, mağaza ve tema açma işlemlerinde ödül sesleri.
- Oyun sonu skor sayacı animasyonu.
- Ayarlar/About alanı v0.8.0 ve paket kimliği ile güncellendi.

## GitHub Actions

Repo kökünde `elxvro-blocks-v0.8.0.zip` bulunmalı. Workflow:

1. ZIP'i doğrular ve açar.
2. Flutter Android platformunu `com.elxvro.elxvro_blocks` paketiyle üretir.
3. Android uygulama adı/portre ayarını uygular.
4. `flutter pub get` çalıştırır.
5. Launcher/adaptive icon üretir.
6. Native splash üretir.
7. `flutter analyze` ve `flutter test` çalıştırır.
8. Release APK üretir.
9. Artifact olarak `ELXVRO-Blocks-v0.8.0` yükler.

## İlk test sırası

- Native splash ve uygulama ikonu.
- Açılış ELXVRO animasyonu.
- Ayarlar > Müzik / Ses Efektleri / ses seviyesi sliderları.
- Oyun > blok koyma / çizgi / combo / Perfect Clear sesleri.
- Oyun sonu skor animasyonu.
- Günlük ödül veya mağaza işlemi sonrası ödül sesi.

Not: Bu çalışma ortamında Flutter SDK bulunmadığı için kesin `flutter analyze`, `flutter test` ve Android build doğrulamasını GitHub Actions yapacaktır.
