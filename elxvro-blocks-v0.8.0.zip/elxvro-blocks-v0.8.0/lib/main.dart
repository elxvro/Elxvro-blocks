import 'dart:async';

import 'package:flutter/material.dart';

import 'app_state.dart';
import 'screens/launch_screen.dart';
import 'services/audio_service.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  final appState = AppState();

  ErrorWidget.builder = (FlutterErrorDetails details) {
    return const Material(
      color: Color(0xFF050505),
      child: SafeArea(
        child: Center(
          child: Padding(
            padding: EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Icon(
                  Icons.warning_amber_rounded,
                  color: Color(0xFFFFC86E),
                  size: 42,
                ),
                SizedBox(height: 14),
                Text(
                  'ELXVRO Blocks',
                  style: TextStyle(
                    color: Color(0xFFFFD99A),
                    fontSize: 24,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 2,
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  'Arayüz yüklenirken bir sorun oluştu.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white70),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  };

  runApp(ElxvroBlocksApp(appState: appState));
  unawaited(appState.load());
}

class ElxvroBlocksApp extends StatefulWidget {
  const ElxvroBlocksApp({super.key, required this.appState});

  final AppState appState;

  @override
  State<ElxvroBlocksApp> createState() => _ElxvroBlocksAppState();
}

class _ElxvroBlocksAppState extends State<ElxvroBlocksApp> {
  @override
  void initState() {
    super.initState();
    widget.appState.addListener(_handleAppStateChanged);
    unawaited(_syncAudio());
  }

  void _handleAppStateChanged() {
    unawaited(_syncAudio());
  }

  Future<void> _syncAudio() async {
    await AudioService.instance.configure(
      musicEnabled: widget.appState.isLoaded && widget.appState.musicEnabled,
      sfxEnabled: widget.appState.soundEnabled,
      musicVolume: widget.appState.musicVolume,
      sfxVolume: widget.appState.sfxVolume,
    );
  }

  @override
  void dispose() {
    widget.appState.removeListener(_handleAppStateChanged);
    unawaited(AudioService.instance.dispose());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: widget.appState,
      builder: (context, _) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'ELXVRO Blocks',
          theme: ThemeData(
            brightness: Brightness.dark,
            scaffoldBackgroundColor: const Color(0xFF050505),
            colorScheme: ColorScheme.fromSeed(
              seedColor: const Color(0xFFD79A4B),
              brightness: Brightness.dark,
            ),
            sliderTheme: const SliderThemeData(
              activeTrackColor: Color(0xFFD69A4B),
              inactiveTrackColor: Color(0xFF2A241E),
              thumbColor: Color(0xFFFFD98B),
              overlayColor: Color(0x22FFD98B),
            ),
            useMaterial3: true,
          ),
          home: LaunchScreen(appState: widget.appState),
        );
      },
    );
  }
}
