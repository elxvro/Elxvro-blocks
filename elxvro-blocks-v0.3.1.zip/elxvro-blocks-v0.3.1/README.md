# ELXVRO Blocks v0.3.1

Premium Gameplay sürümü.

## Yeni özellikler

- Altın parıltılı satır/sütun temizleme efekti
- Parçacık patlama animasyonu
- Geliştirilmiş COMBO / MEGA COMBO / ULTRA COMBO geri bildirimi
- Özel bloklar: Bomba, Satır Temizleyici, Sütun Temizleyici, Joker
- Her oyun için 1 adet Geri Al hakkı
- Her oyun için 1 adet Blok Yenileme hakkı
- Geçerli/geçersiz hayalet yerleştirme önizlemesi
- Ses efektleri aç/kapat
- Titreşim aç/kapat
- Geliştirilmiş oyun sonu istatistik ekranı
- v0.2.0 görev, başarım, istatistik ve tema sistemi korunur

## GitHub ZIP build

Repo köküne `elxvro-blocks-v0.3.1.zip` yükleniyorsa workflow içindeki sürüm yollarını `v0.3.1` olarak kullan.
