import 'package:flutter/material.dart';

import '../app_state.dart';
import '../models/game_theme.dart';
import '../widgets/premium_background.dart';

class DailyMissionsScreen extends StatelessWidget {
  const DailyMissionsScreen({super.key, required this.appState});

  final AppState appState;

  @override
  Widget build(BuildContext context) {
    final selectedTheme = gameThemes.firstWhere(
      (theme) => theme.id == appState.themeId,
      orElse: () => gameThemes.first,
    );

    final missions = <_MissionData>[
      _MissionData(
        title: 'Bugünün Oyunu',
        subtitle: '1 oyun tamamla',
        current: appState.dailyGames,
        target: 1,
        icon: Icons.sports_esports_rounded,
      ),
      _MissionData(
        title: 'Temizlik Serisi',
        subtitle: '8 satır veya sütun temizle',
        current: appState.dailyLines,
        target: 8,
        icon: Icons.auto_awesome_rounded,
      ),
      _MissionData(
        title: 'Skor Avcısı',
        subtitle: 'Tek oyunda 2.500 puan yap',
        current: appState.dailyBestScore,
        target: 2500,
        icon: Icons.emoji_events_rounded,
      ),
    ];

    return Scaffold(
      body: PremiumBackground(
        top: selectedTheme.backgroundTop,
        bottom: selectedTheme.backgroundBottom,
        child: SafeArea(
          child: Column(
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.fromLTRB(8, 8, 20, 12),
                child: Row(
                  children: <Widget>[
                    IconButton(
                      onPressed: () => Navigator.of(context).pop(),
                      icon: const Icon(Icons.arrow_back_rounded),
                    ),
                    const SizedBox(width: 4),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            'GÜNLÜK GÖREVLER',
                            style: TextStyle(
                              color: Color(0xFFFFD99A),
                              fontSize: 20,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 1.8,
                            ),
                          ),
                          SizedBox(height: 2),
                          Text(
                            'Her gün yeni hedefler',
                            style: TextStyle(color: Colors.white54, fontSize: 12),
                          ),
                        ],
                      ),
                    ),
                    _ProgressBadge(
                      completed: appState.completedDailyMissions,
                      total: missions.length,
                    ),
                  ],
                ),
              ),
              Expanded(
                child: ListView.separated(
                  padding: const EdgeInsets.fromLTRB(18, 12, 18, 28),
                  itemCount: missions.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder: (context, index) => _MissionCard(
                    data: missions[index],
                    accent: selectedTheme.blockAccent,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ProgressBadge extends StatelessWidget {
  const _ProgressBadge({required this.completed, required this.total});

  final int completed;
  final int total;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        color: const Color(0xFFFFC86E).withValues(alpha: 0.10),
        border: Border.all(
          color: const Color(0xFFFFC86E).withValues(alpha: 0.25),
        ),
      ),
      child: Text(
        '$completed/$total',
        style: const TextStyle(
          color: Color(0xFFFFD98B),
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}

class _MissionCard extends StatelessWidget {
  const _MissionCard({required this.data, required this.accent});

  final _MissionData data;
  final Color accent;

  @override
  Widget build(BuildContext context) {
    final completed = data.current >= data.target;
    final progress = (data.current / data.target).clamp(0.0, 1.0).toDouble();
    final shownCurrent = data.current > data.target ? data.target : data.current;

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        color: Colors.white.withValues(alpha: 0.045),
        border: Border.all(
          color: completed
              ? const Color(0xFF79D993).withValues(alpha: 0.35)
              : Colors.white.withValues(alpha: 0.07),
        ),
      ),
      child: Column(
        children: <Widget>[
          Row(
            children: <Widget>[
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: accent.withValues(alpha: 0.12),
                ),
                child: Icon(data.icon, color: accent),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      data.title,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w800,
                        fontSize: 15,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      data.subtitle,
                      style: const TextStyle(color: Colors.white54, fontSize: 12),
                    ),
                  ],
                ),
              ),
              Icon(
                completed ? Icons.check_circle_rounded : Icons.timelapse_rounded,
                color: completed ? const Color(0xFF79D993) : Colors.white30,
              ),
            ],
          ),
          const SizedBox(height: 16),
          ClipRRect(
            borderRadius: BorderRadius.circular(999),
            child: LinearProgressIndicator(
              minHeight: 8,
              value: progress,
              backgroundColor: Colors.white.withValues(alpha: 0.07),
              valueColor: AlwaysStoppedAnimation<Color>(
                completed ? const Color(0xFF79D993) : accent,
              ),
            ),
          ),
          const SizedBox(height: 8),
          Align(
            alignment: Alignment.centerRight,
            child: Text(
              '$shownCurrent / ${data.target}',
              style: const TextStyle(color: Colors.white38, fontSize: 11),
            ),
          ),
        ],
      ),
    );
  }
}

class _MissionData {
  const _MissionData({
    required this.title,
    required this.subtitle,
    required this.current,
    required this.target,
    required this.icon,
  });

  final String title;
  final String subtitle;
  final int current;
  final int target;
  final IconData icon;
}
