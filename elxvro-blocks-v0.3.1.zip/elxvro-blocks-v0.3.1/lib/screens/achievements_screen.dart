import 'package:flutter/material.dart';

import '../app_state.dart';
import '../models/game_theme.dart';
import '../widgets/premium_background.dart';

class AchievementsScreen extends StatelessWidget {
  const AchievementsScreen({super.key, required this.appState});

  final AppState appState;

  static const List<_AchievementData> _items = <_AchievementData>[
    _AchievementData(
      id: 'first_game',
      title: 'İlk Adım',
      subtitle: 'İlk oyununu tamamla',
      icon: Icons.flag_rounded,
    ),
    _AchievementData(
      id: 'score_1000',
      title: 'Isınma Turu',
      subtitle: 'Tek oyunda 1.000 puana ulaş',
      icon: Icons.local_fire_department_rounded,
    ),
    _AchievementData(
      id: 'combo_3',
      title: 'Combo Ustası',
      subtitle: 'x3 combo yap',
      icon: Icons.bolt_rounded,
    ),
    _AchievementData(
      id: 'lines_25',
      title: 'Tahta Temizleyici',
      subtitle: 'Toplam 25 satır veya sütun temizle',
      icon: Icons.auto_awesome_rounded,
    ),
    _AchievementData(
      id: 'games_10',
      title: 'Deneyimli',
      subtitle: '10 oyun tamamla',
      icon: Icons.sports_esports_rounded,
    ),
    _AchievementData(
      id: 'blocks_250',
      title: 'Blok Koleksiyoncusu',
      subtitle: '250 parça yerleştir',
      icon: Icons.grid_view_rounded,
    ),
    _AchievementData(
      id: 'score_10000',
      title: 'Efsane',
      subtitle: 'Tek oyunda 10.000 puana ulaş',
      icon: Icons.workspace_premium_rounded,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final selectedTheme = gameThemes.firstWhere(
      (theme) => theme.id == appState.themeId,
      orElse: () => gameThemes.first,
    );

    return Scaffold(
      body: PremiumBackground(
        top: selectedTheme.backgroundTop,
        bottom: selectedTheme.backgroundBottom,
        child: SafeArea(
          child: Column(
            children: <Widget>[
              _Header(
                unlocked: appState.unlockedAchievements,
                total: _items.length,
              ),
              Expanded(
                child: ListView.separated(
                  padding: const EdgeInsets.fromLTRB(18, 10, 18, 28),
                  itemCount: _items.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 10),
                  itemBuilder: (context, index) {
                    final item = _items[index];
                    final unlocked = appState.achievementUnlocked(item.id);
                    return _AchievementCard(
                      item: item,
                      unlocked: unlocked,
                      accent: selectedTheme.blockAccent,
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Header extends StatelessWidget {
  const _Header({required this.unlocked, required this.total});

  final int unlocked;
  final int total;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 8, 20, 14),
      child: Row(
        children: <Widget>[
          IconButton(
            onPressed: () => Navigator.of(context).pop(),
            icon: const Icon(Icons.arrow_back_rounded),
          ),
          const SizedBox(width: 4),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  'BAŞARIMLAR',
                  style: TextStyle(
                    color: Color(0xFFFFD99A),
                    fontSize: 21,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 2.2,
                  ),
                ),
                SizedBox(height: 2),
                Text(
                  'Oynadıkça koleksiyonunu tamamla',
                  style: TextStyle(color: Colors.white54, fontSize: 12),
                ),
              ],
            ),
          ),
          Text(
            '$unlocked/$total',
            style: const TextStyle(
              color: Color(0xFFFFD98B),
              fontWeight: FontWeight.w800,
              fontSize: 16,
            ),
          ),
        ],
      ),
    );
  }
}

class _AchievementCard extends StatelessWidget {
  const _AchievementCard({
    required this.item,
    required this.unlocked,
    required this.accent,
  });

  final _AchievementData item;
  final bool unlocked;
  final Color accent;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: Colors.white.withValues(alpha: unlocked ? 0.055 : 0.028),
        border: Border.all(
          color: unlocked
              ? accent.withValues(alpha: 0.45)
              : Colors.white.withValues(alpha: 0.06),
        ),
      ),
      child: Row(
        children: <Widget>[
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: unlocked
                  ? accent.withValues(alpha: 0.16)
                  : Colors.white.withValues(alpha: 0.04),
            ),
            child: Icon(
              unlocked ? item.icon : Icons.lock_outline_rounded,
              color: unlocked ? accent : Colors.white24,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  item.title,
                  style: TextStyle(
                    color: unlocked ? Colors.white : Colors.white38,
                    fontWeight: FontWeight.w800,
                    fontSize: 15,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  item.subtitle,
                  style: TextStyle(
                    color: unlocked ? Colors.white54 : Colors.white24,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
          Icon(
            unlocked ? Icons.check_circle_rounded : Icons.lock_rounded,
            color: unlocked ? const Color(0xFF79D993) : Colors.white12,
            size: 22,
          ),
        ],
      ),
    );
  }
}

class _AchievementData {
  const _AchievementData({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.icon,
  });

  final String id;
  final String title;
  final String subtitle;
  final IconData icon;
}
