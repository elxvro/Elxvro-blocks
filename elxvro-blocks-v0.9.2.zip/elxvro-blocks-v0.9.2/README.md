# ELXVRO Blocks v0.9.2 — Audio Engine Fix

Bu sürüm önceki sürümdeki ses çıkmaması ve ses açıldığında oluşan takılma sorunlarını hedefleyen ses motoru düzeltmesidir. Tema yenilemeleri korunur.

## Yeni premium temalar

Önceki tema kimlikleri kayıt uyumluluğu için korunur; kullanıcıların daha önce açtığı temalar kaybolmaz.

- **Cam** — parlak buzlu cam bloklar, kristal yüzey çizgileri ve cam tınıları.
- **Dal** — sıcak ahşap/dal görünümü, damar çizgileri ve tok ahşap vuruşları.
- **Taş** — oyulmuş kaya yüzeyi, çatlak detayları ve güçlü taş kırılma sesleri.
- **Yaprak** — canlı yeşil palet, yaprak damarları ve yumuşak rustle/rüzgâr efektleri.
- **Kristal** — mor-mavi parlak yüzey, facet çizgileri ve yüksek kristal rezonansı.
- **Mermer Altın** — siyah mermer hissi, altın damarlar ve ağır/premium vurgu sesleri.

Dolu blok hücreleri ve parça önizlemeleri artık temaya göre farklı yüzey deseni çiziyor.

## Ses yenilemesi

- Arka plan müziği baştan değiştirildi.
- Yeni parça ELXVRO için programatik olarak oluşturulmuş özgün, sakin ambient loop'tur; harici müzik veya üçüncü taraf kayıt içermez.
- Her tema için ayrı **yerleştirme**, **temizleme**, **combo** ve **Perfect Clear** efekt seti bulunur.
- Efektlerin kaynak seviyesi yükseltildi.
- Varsayılan efekt seviyesi `%100`, müzik seviyesi `%42` olarak güncellendi.
- Ayarlar ekranındaki efekt önizlemesi aktif temanın sesini çalar.
- Kısa efektler `AudioPool` ile önceden hazırlanır; her hamlede yeni `AudioPlayer` oluşturulmaz.
- Android ses odağı oyun içi müzik ve efektlerin birbirini susturmaması için birlikte çalacak şekilde yapılandırıldı.
- WAV dosyaları 44.1 kHz PCM olarak yeniden kodlandı.
- Ses sliderı kayıtları debounce edildi; slider sürüklerken SharedPreferences yazımı artık her karede yapılmaz.
- Aynı ayarlar değişmediyse native audio katmanına tekrar tekrar konfigürasyon gönderilmez.

## Sürüm

- Flutter package version: `0.9.2+16`
- Android package: `com.elxvro.elxvro_blocks`
- Build çıktıları: APK + AAB + debug symbols + SHA-256

## GitHub dosya adı

Repo kökünde:

```text
elxvro-blocks-v0.9.2.zip
```

bulunmalıdır. `.github/workflows/build-apk.yml` dosyası ZIP tabanlı build akışına göre günceldir.

## Test sırası

1. Cam temasında blok yerleştir ve satır temizle; cam efektlerini dinle.
2. Dal temasına geç; ahşap yüzey ve vuruş sesini kontrol et.
3. Taş temasında temizleme/Perfect Clear seslerini test et.
4. Yaprak temasında yerleştirme ve combo sesini kontrol et.
5. Kristal ve Mermer Altın tema önizlemelerini dene.
6. Ayarlar > Efekt Seviyesi'ni `%100` yapıp önizleme butonunu kullan.
7. Arka plan müziğini aç/kapat ve seviye sliderını test et.
8. APK'yı farklı ekran boyutlarında en az 10 dakika oynayıp ses üst üste binmesi veya takılma olup olmadığını kontrol et.
