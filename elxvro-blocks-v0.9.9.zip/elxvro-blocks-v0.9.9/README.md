# ELXVRO Blocks v0.9.9 — Real Material Audio

This release replaces synthesized material imitations in the GitHub-built APK/AAB with real recorded material audio.

## Material audio
- Glass: real glass taps + real glass break.
- Wood/Dal: real wood knocks + real twig snap.
- Leaf: real recorded leaf rustle.
- Stone: real stone/boulder impact and movement.
- Marble: real marble-floor resonance plus restrained stone body for clears.
- Crystal: real glass resonance with filtering only.

The build downloads only public-domain / CC0-compatible source recordings and creates short game-ready WAV assets. See `REAL_AUDIO_CREDITS.md`.

## Build
Upload `elxvro-blocks-v0.9.9.zip` to the repository root and use `.github/workflows/build-apk.yml`. The workflow installs FFmpeg, fetches the real recordings, runs analyze/tests, then builds APK and AAB.

Flutter package version: `0.9.9+23`.

## v0.9.9 — Human-composed background music

The procedural ambient loop used in earlier builds is no longer played. During GitHub Actions, ELXVRO downloads **Cozy Puzzle In-Game 1** by MintoDog from OpenGameArt, licensed CC0. The source track is authored as loopable puzzle-game music and uses saxophone, flute, mallets and bossa-nova elements. The build only converts the file to OGG and normalizes loudness; it does not synthesize or rewrite the composition. Material SFX from v0.9.8 remain unchanged.
