# ELXVRO Blocks v0.9.9 — Real Material Audio Sources

The material SFX in the GitHub-built APK/AAB are derived from real-world recordings, not synthesized material imitations. The build script downloads the sources and trims/normalizes them into short game-ready clips.

## Public-domain / CC0 sources

- **Glass taps — “Binging glass.ogg”** by hugh, PDSounds, mirrored on Wikimedia Commons. Public domain. Recorded by striking a half-filled glass with a plastic pen.
  - https://commons.wikimedia.org/wiki/File:Binging_glass.ogg
- **Glass break — “Glass Break” / `glass_breaking.wav`** by Till Behrend, submitted by TinyWorlds on OpenGameArt. CC0.
  - https://opengameart.org/content/glass-break
- **Wood knock — “Knocking on wood or door.ogg”** by stephan, PDSounds, mirrored on Wikimedia Commons. Public domain.
  - https://commons.wikimedia.org/wiki/File:Knocking_on_wood_or_door.ogg
- **Twig snap — “Snapping twig (single).ogg”** by stephan, Wikimedia Commons. CC0/public domain dedication.
  - https://commons.wikimedia.org/wiki/File:Snapping_twig_(single).ogg
- **Leaves — “moving leaves stereo.ogg”** by Augmentality (Brandon Morris), submitted by HaelDB on OpenGameArt. CC0 / OGA-BY; ELXVRO uses it under CC0.
  - https://opengameart.org/content/random-sounds-samples
- **Stone/boulder — “Moving Boulder” (`boulder_drop.ogg`, `move_boulder.ogg`)** by themightyglider on OpenGameArt. CC0.
  - https://opengameart.org/content/moving-boulder
- **Marble-floor impact — “Pen dropped.ogg”** by Kapoios2026 on Wikimedia Commons. CC0. Used for the real marble-floor resonance component.
  - https://commons.wikimedia.org/wiki/File:Pen_dropped.ogg

## Processing

Only game-oriented editing is performed: trimming, channel conversion, level normalization/limiting, and light high/low-pass filtering. No synthesized “fake material” tone is mixed into these theme SFX.

## Background music (v0.9.9)

**Cozy Puzzle In-Game 1** — MintoDog, OpenGameArt.
- Source: https://opengameart.org/content/cozy-puzzle-in-game-1
- License: CC0 1.0
- Described by the author as loopable puzzle-game music using saxophone, flute, mallets and bossa-nova elements.
- ELXVRO build processing is limited to mobile-friendly OGG encoding and loudness normalization. The composition itself is not synthesized or rewritten by ELXVRO.
