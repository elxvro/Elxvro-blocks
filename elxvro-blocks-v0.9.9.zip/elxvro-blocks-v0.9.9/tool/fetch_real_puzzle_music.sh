#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ASSETS="$ROOT/assets/audio"
TMP="$ROOT/build/real_music_source"
mkdir -p "$ASSETS" "$TMP"
URL="https://opengameart.org/sites/default/files/cozy_puzzle_in-game_1_bpm118.mp3"
SRC="$TMP/cozy_puzzle_in-game_1_bpm118.mp3"
OUT="$ASSETS/cozy_puzzle_music.ogg"
UA="ELXVRO-Blocks/0.9.9 (CC0-puzzle-music build)"

echo "[music] Downloading human-composed CC0 puzzle track..."
curl -fL --retry 6 --retry-delay 3 --connect-timeout 20 -A "$UA" "$URL" -o "$SRC"
test -s "$SRC"

# Keep the original composition intact. Only encode to a mobile-friendly OGG and
# normalize playback level so it sits under game effects.
ffmpeg -hide_banner -loglevel error -y \
  -i "$SRC" \
  -af "loudnorm=I=-20:TP=-2:LRA=11" \
  -c:a libvorbis -q:a 5 \
  "$OUT"

test -s "$OUT"
cat > "$ASSETS/REAL_MUSIC_BUILD.txt" <<'TXT'
ELXVRO Blocks v0.9.9
Background music replaced during build with a human-composed CC0 puzzle track.
Track: Cozy Puzzle In-Game 1
Author: MintoDog
Source: https://opengameart.org/content/cozy-puzzle-in-game-1
License: CC0 1.0 / public-domain dedication
Processing: format conversion + loudness normalization only; composition unchanged.
TXT

echo "[music] Real composed puzzle music ready: $OUT"
