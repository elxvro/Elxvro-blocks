import 'dart:math';

import '../l10n/app_strings.dart';

enum PiecePower {
  normal,
  bomb,
  rowClear,
  columnClear,
  crossClear,
  megaBomb,
  wild,
}

class CellOffset {
  const CellOffset(this.row, this.col);

  final int row;
  final int col;
}

class BlockPiece {
  const BlockPiece({
    required this.id,
    required this.cells,
    this.power = PiecePower.normal,
  });

  final String id;
  final List<CellOffset> cells;
  final PiecePower power;

  int get rows => cells.map((cell) => cell.row).reduce(max) + 1;
  int get cols => cells.map((cell) => cell.col).reduce(max) + 1;
  int get size => cells.length;
  bool get isSpecial => power != PiecePower.normal;

  String get powerLabel {
    switch (power) {
      case PiecePower.bomb:
        return AppStrings.current.f10('BOMBA', 'BOMB', 'BOMBE', 'BOMBA', 'BOMBE', 'BOMBA', 'BOMBA', 'BOM', 'BOMBA', 'БОМБА');
      case PiecePower.rowClear:
        return AppStrings.current.f10('SATIR', 'ROW', 'REIHE', 'FILA', 'LIGNE', 'RIGA', 'LINHA', 'RIJ', 'WIERSZ', 'СТРОКА');
      case PiecePower.columnClear:
        return AppStrings.current.f10('SÜTUN', 'COLUMN', 'SPALTE', 'COLUMNA', 'COLONNE', 'COLONNA', 'COLUNA', 'KOLOM', 'KOLUMNA', 'СТОЛБЕЦ');
      case PiecePower.crossClear:
        return AppStrings.current.f10('ARTI', 'CROSS', 'KREUZ', 'CRUZ', 'CROIX', 'CROCE', 'CRUZ', 'KRUIS', 'KRZYŻ', 'КРЕСТ');
      case PiecePower.megaBomb:
        return AppStrings.current.f10('MEGA', 'MEGA', 'MEGA', 'MEGA', 'MÉGA', 'MEGA', 'MEGA', 'MEGA', 'MEGA', 'МЕГА');
      case PiecePower.wild:
        return AppStrings.current.f10('JOKER', 'WILD', 'JOKER', 'COMODÍN', 'JOKER', 'JOLLY', 'CORINGA', 'JOKER', 'JOKER', 'ДЖОКЕР');
      case PiecePower.normal:
        return '';
    }
  }
}

const List<BlockPiece> blockCatalog = <BlockPiece>[
  BlockPiece(id: 'single', cells: <CellOffset>[CellOffset(0, 0)]),
  BlockPiece(
    id: 'domino_h',
    cells: <CellOffset>[CellOffset(0, 0), CellOffset(0, 1)],
  ),
  BlockPiece(
    id: 'domino_v',
    cells: <CellOffset>[CellOffset(0, 0), CellOffset(1, 0)],
  ),
  BlockPiece(
    id: 'line_3_h',
    cells: <CellOffset>[
      CellOffset(0, 0),
      CellOffset(0, 1),
      CellOffset(0, 2),
    ],
  ),
  BlockPiece(
    id: 'line_3_v',
    cells: <CellOffset>[
      CellOffset(0, 0),
      CellOffset(1, 0),
      CellOffset(2, 0),
    ],
  ),
  BlockPiece(
    id: 'line_4_h',
    cells: <CellOffset>[
      CellOffset(0, 0),
      CellOffset(0, 1),
      CellOffset(0, 2),
      CellOffset(0, 3),
    ],
  ),
  BlockPiece(
    id: 'line_4_v',
    cells: <CellOffset>[
      CellOffset(0, 0),
      CellOffset(1, 0),
      CellOffset(2, 0),
      CellOffset(3, 0),
    ],
  ),
  BlockPiece(
    id: 'square_2',
    cells: <CellOffset>[
      CellOffset(0, 0),
      CellOffset(0, 1),
      CellOffset(1, 0),
      CellOffset(1, 1),
    ],
  ),
  BlockPiece(
    id: 'l_small',
    cells: <CellOffset>[
      CellOffset(0, 0),
      CellOffset(1, 0),
      CellOffset(1, 1),
    ],
  ),
  BlockPiece(
    id: 'l_medium',
    cells: <CellOffset>[
      CellOffset(0, 0),
      CellOffset(1, 0),
      CellOffset(2, 0),
      CellOffset(2, 1),
      CellOffset(2, 2),
    ],
  ),
  BlockPiece(
    id: 't',
    cells: <CellOffset>[
      CellOffset(0, 0),
      CellOffset(0, 1),
      CellOffset(0, 2),
      CellOffset(1, 1),
    ],
  ),
  BlockPiece(
    id: 'z',
    cells: <CellOffset>[
      CellOffset(0, 0),
      CellOffset(0, 1),
      CellOffset(1, 1),
      CellOffset(1, 2),
    ],
  ),
  BlockPiece(
    id: 'corner_5',
    cells: <CellOffset>[
      CellOffset(0, 0),
      CellOffset(1, 0),
      CellOffset(2, 0),
      CellOffset(2, 1),
      CellOffset(2, 2),
    ],
  ),
  BlockPiece(
    id: 'square_3',
    cells: <CellOffset>[
      CellOffset(0, 0),
      CellOffset(0, 1),
      CellOffset(0, 2),
      CellOffset(1, 0),
      CellOffset(1, 1),
      CellOffset(1, 2),
      CellOffset(2, 0),
      CellOffset(2, 1),
      CellOffset(2, 2),
    ],
  ),
  BlockPiece(
    id: 'line_5_h',
    cells: <CellOffset>[
      CellOffset(0, 0),
      CellOffset(0, 1),
      CellOffset(0, 2),
      CellOffset(0, 3),
      CellOffset(0, 4),
    ],
  ),
  BlockPiece(
    id: 'line_5_v',
    cells: <CellOffset>[
      CellOffset(0, 0),
      CellOffset(1, 0),
      CellOffset(2, 0),
      CellOffset(3, 0),
      CellOffset(4, 0),
    ],
  ),
  BlockPiece(
    id: 'plus_5',
    cells: <CellOffset>[
      CellOffset(0, 1),
      CellOffset(1, 0),
      CellOffset(1, 1),
      CellOffset(1, 2),
      CellOffset(2, 1),
    ],
  ),
  BlockPiece(
    id: 'u_5',
    cells: <CellOffset>[
      CellOffset(0, 0),
      CellOffset(1, 0),
      CellOffset(1, 1),
      CellOffset(1, 2),
      CellOffset(0, 2),
    ],
  ),
  BlockPiece(
    id: 'step_5',
    cells: <CellOffset>[
      CellOffset(0, 0),
      CellOffset(1, 0),
      CellOffset(1, 1),
      CellOffset(2, 1),
      CellOffset(2, 2),
    ],
  ),
  BlockPiece(
    id: 'hook_5',
    cells: <CellOffset>[
      CellOffset(0, 0),
      CellOffset(1, 0),
      CellOffset(2, 0),
      CellOffset(2, 1),
      CellOffset(1, 1),
    ],
  ),
];

const List<BlockPiece> specialBlockCatalog = <BlockPiece>[
  BlockPiece(
    id: 'special_bomb',
    cells: <CellOffset>[CellOffset(0, 0)],
    power: PiecePower.bomb,
  ),
  BlockPiece(
    id: 'special_row',
    cells: <CellOffset>[CellOffset(0, 0)],
    power: PiecePower.rowClear,
  ),
  BlockPiece(
    id: 'special_column',
    cells: <CellOffset>[CellOffset(0, 0)],
    power: PiecePower.columnClear,
  ),
  BlockPiece(
    id: 'special_cross',
    cells: <CellOffset>[CellOffset(0, 0)],
    power: PiecePower.crossClear,
  ),
  BlockPiece(
    id: 'special_mega_bomb',
    cells: <CellOffset>[CellOffset(0, 0)],
    power: PiecePower.megaBomb,
  ),
  BlockPiece(
    id: 'special_wild',
    cells: <CellOffset>[CellOffset(0, 0)],
    power: PiecePower.wild,
  ),
];
