import '../l10n/app_strings.dart';

class AdventureLevel {
  const AdventureLevel({
    required this.number,
    required this.targetScore,
    required this.reward,
    required this.startingBlocks,
    required this.scoreMultiplier,
    required this.hardPieces,
    this.durationSeconds,
  });

  final int number;
  final int targetScore;
  final int reward;
  final int startingBlocks;
  final double scoreMultiplier;
  final bool hardPieces;
  final int? durationSeconds;

  int get chapter => ((number - 1) ~/ 10) + 1;

  String get title => AppStrings.current.f10(
        'BÖLÜM $number', 'LEVEL $number', 'STUFE $number', 'NIVEL $number',
        'NIVEAU $number', 'LIVELLO $number', 'NÍVEL $number', 'NIVEAU $number',
        'POZIOM $number', 'УРОВЕНЬ $number',
      );

  String get difficultyLabel => AppStrings.current.adventureDifficulty(
        hardPieces: hardPieces,
        timed: durationSeconds != null,
      );

  int get fallingTargetScore => targetScore;

  int get fallingTargetLines =>
      (5 + ((number - 1) ~/ 5)).clamp(5, 18).toInt();

  int get fallingIntervalMs {
    final step = number - 1;
    final chapterPenalty = (chapter - 1) * 12;
    return (710 - step * 9 - chapterPenalty).clamp(135, 710).toInt();
  }

  int get colorCycle => (number - 1) % 7;

  String get objective => AppStrings.current.f10(
        '$fallingTargetScore puana ulaş • hız ve renk her bölüm değişir',
        'Reach $fallingTargetScore points • speed and colors change each level',
        '$fallingTargetScore Punkte erreichen • Geschwindigkeit und Farben ändern sich pro Stufe',
        'Alcanza $fallingTargetScore puntos • la velocidad y los colores cambian en cada nivel',
        'Atteins $fallingTargetScore points • la vitesse et les couleurs changent à chaque niveau',
        'Raggiungi $fallingTargetScore punti • velocità e colori cambiano a ogni livello',
        'Alcance $fallingTargetScore pontos • velocidade e cores mudam a cada nível',
        'Behaal $fallingTargetScore punten • snelheid en kleuren veranderen per niveau',
        'Zdobądź $fallingTargetScore punktów • prędkość i kolory zmieniają się na każdym poziomie',
        'Наберите $fallingTargetScore очков • скорость и цвета меняются на каждом уровне',
      );
}

const int adventureLevelCount = 60;

AdventureLevel adventureLevelFor(int number) {
  final safe = number.clamp(1, adventureLevelCount).toInt();
  final hard = safe % 5 == 0;
  final timed = safe % 3 == 0;
  final chapter = ((safe - 1) ~/ 10) + 1;
  final step = safe - 1;
  final target = 1000 + step * 650 + step * step * 6 + (chapter - 1) * 500;
  final duration = timed
      ? (190 - chapter * 8 - (hard ? 10 : 0)).clamp(125, 190).toInt()
      : null;
  return AdventureLevel(
    number: safe,
    targetScore: target,
    reward: 35 + safe * 5 + (hard ? 40 : 0),
    startingBlocks:
        (4 + chapter * 2 + (safe ~/ 4) + (hard ? 4 : 0)).clamp(4, 32).toInt(),
    scoreMultiplier: hard ? 1.22 : (timed ? 1.08 : 1.0),
    hardPieces: hard,
    durationSeconds: duration,
  );
}

final List<AdventureLevel> adventureLevels = List<AdventureLevel>.unmodifiable(
  List<AdventureLevel>.generate(
    adventureLevelCount,
    (index) => adventureLevelFor(index + 1),
  ),
);
