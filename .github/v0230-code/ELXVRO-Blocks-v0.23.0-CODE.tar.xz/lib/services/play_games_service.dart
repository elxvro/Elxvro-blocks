import 'package:flutter/foundation.dart';

import '../l10n/app_strings.dart';
import 'package:games_services/games_services.dart';

import 'play_games_ids.dart';
import 'social_service.dart';

abstract interface class GamesPlatformAdapter {
  Future<bool> signIn();

  Future<void> submitScore({
    required String leaderboardId,
    required int score,
  });

  Future<void> unlockAchievement(String achievementId);

  Future<void> showLeaderboards();

  Future<void> showLeaderboard({required String leaderboardId});

  Future<void> showAchievements();
}

class GamesServicesPlatformAdapter implements GamesPlatformAdapter {
  const GamesServicesPlatformAdapter();

  @override
  Future<bool> signIn() async {
    await GamesServices.signIn();
    return GamesServices.isSignedIn;
  }

  @override
  Future<void> submitScore({
    required String leaderboardId,
    required int score,
  }) async {
    await GamesServices.submitScore(
      score: Score(
        androidLeaderboardID: leaderboardId,
        value: score,
      ),
    );
  }

  @override
  Future<void> unlockAchievement(String achievementId) async {
    await GamesServices.unlock(
      achievement: Achievement(
        androidID: achievementId,
        percentComplete: 100,
      ),
    );
  }

  @override
  Future<void> showLeaderboards() async {
    await GamesServices.showLeaderboards();
  }

  @override
  Future<void> showLeaderboard({required String leaderboardId}) async {
    await GamesServices.showLeaderboards(
      androidLeaderboardID: leaderboardId,
    );
  }

  @override
  Future<void> showAchievements() async {
    await GamesServices.showAchievements();
  }
}

class PlayGamesService implements SocialService {
  PlayGamesService({
    required this.ids,
    GamesPlatformAdapter? adapter,
  }) : _adapter = adapter ?? const GamesServicesPlatformAdapter();

  factory PlayGamesService.production() => PlayGamesService(
        ids: const PlayGamesIds.fromEnvironment(),
      );

  final PlayGamesIds ids;
  final GamesPlatformAdapter _adapter;

  bool _connected = false;
  bool _signInAttempted = false;
  String? _lastError;

  @override
  Future<SocialConnectionInfo> connectionInfo() async {
    if (_connected) {
      return SocialConnectionInfo(
        connected: true,
        provider: 'Google Play Games',
        message: AppStrings.current.f10('Google Play Games bağlı. Skor ve başarımlar senkronize edilebilir.', 'Google Play Games connected. Scores and achievements can sync.', 'Google Play Games verbunden. Punkte und Erfolge können synchronisiert werden.', 'Google Play Games conectado. Las puntuaciones y logros se pueden sincronizar.', 'Google Play Games connecté. Les scores et succès peuvent être synchronisés.', 'Google Play Games connesso. Punteggi e obiettivi possono essere sincronizzati.', 'Google Play Games conectado. Pontuações e conquistas podem ser sincronizadas.', 'Google Play Games verbonden. Scores en prestaties kunnen worden gesynchroniseerd.', 'Połączono z Google Play Games. Wyniki i osiągnięcia mogą się synchronizować.', 'Google Play Games подключён. Результаты и достижения можно синхронизировать.'),
      );
    }

    return SocialConnectionInfo(
      connected: false,
      provider: 'Google Play Games',
      message: _lastError == null
          ? ids.hasAnyRemoteConfiguration
              ? AppStrings.current.f10('Play Games bağlantısı hazır. Yerel kayıtlar çevrimdışı da korunur.', 'Play Games is ready. Local progress is also kept offline.', 'Play Games ist bereit. Lokaler Fortschritt bleibt auch offline erhalten.', 'Play Games está listo. El progreso local también se conserva sin conexión.', 'Play Games est prêt. La progression locale est aussi conservée hors ligne.', 'Play Games è pronto. I progressi locali vengono conservati anche offline.', 'Play Games está pronto. O progresso local também é mantido offline.', 'Play Games is gereed. Lokale voortgang blijft ook offline bewaard.', 'Play Games jest gotowe. Lokalny postęp jest zachowywany także offline.', 'Play Games готов. Локальный прогресс сохраняется и офлайн.')
              : AppStrings.current.f10('Play Games kimlikleri henüz yapılandırılmadı. Yerel kayıtlar kullanılmaya devam eder.', 'Play Games IDs are not configured yet. Local progress will continue to be used.', 'Play-Games-IDs sind noch nicht konfiguriert. Lokaler Fortschritt wird weiterhin verwendet.', 'Los ID de Play Games aún no están configurados. Se seguirá usando el progreso local.', 'Les identifiants Play Games ne sont pas encore configurés. La progression locale reste utilisée.', 'Gli ID di Play Games non sono ancora configurati. Continueranno a essere usati i progressi locali.', 'Os IDs do Play Games ainda não estão configurados. O progresso local continuará sendo usado.', 'Play Games-ID’s zijn nog niet ingesteld. Lokale voortgang blijft in gebruik.', 'Identyfikatory Play Games nie są jeszcze skonfigurowane. Lokalny postęp będzie nadal używany.', 'Идентификаторы Play Games ещё не настроены. Локальный прогресс продолжит использоваться.')
          : AppStrings.current.f10('Play Games bağlantısı kurulamadı. Oyun çevrimdışı çalışmaya devam eder.', 'Could not connect to Play Games. The game will continue offline.', 'Verbindung zu Play Games fehlgeschlagen. Das Spiel läuft offline weiter.', 'No se pudo conectar con Play Games. El juego continuará sin conexión.', 'Impossible de se connecter à Play Games. Le jeu continue hors ligne.', 'Impossibile connettersi a Play Games. Il gioco continuerà offline.', 'Não foi possível conectar ao Play Games. O jogo continuará offline.', 'Kan geen verbinding maken met Play Games. Het spel gaat offline verder.', 'Nie udało się połączyć z Play Games. Gra będzie działać offline.', 'Не удалось подключиться к Play Games. Игра продолжит работать офлайн.'),
    );
  }

  @override
  Future<bool> signIn() async {
    _signInAttempted = true;
    try {
      _connected = await _adapter.signIn();
      _lastError = _connected ? null : 'not_connected';
      return _connected;
    } catch (error, stackTrace) {
      _connected = false;
      _lastError = error.toString();
      debugPrint('ELXVRO Play Games sign-in failed: $error');
      debugPrintStack(stackTrace: stackTrace);
      return false;
    }
  }

  Future<bool> _ensureConnected() async {
    if (_connected) return true;
    if (_signInAttempted && _lastError != null) {
      return false;
    }
    return signIn();
  }

  @override
  Future<void> submitScore({
    required String leaderboardId,
    required int score,
  }) async {
    final id = leaderboardId.trim();
    if (id.isEmpty) return;
    if (!await _ensureConnected()) return;
    try {
      await _adapter.submitScore(
        leaderboardId: id,
        score: score < 0 ? 0 : score,
      );
    } catch (error, stackTrace) {
      _lastError = error.toString();
      debugPrint('ELXVRO Play Games score sync failed: $error');
      debugPrintStack(stackTrace: stackTrace);
    }
  }

  @override
  Future<void> unlockAchievement({required String achievementId}) async {
    final id = achievementId.trim();
    if (id.isEmpty) return;
    if (!await _ensureConnected()) return;
    try {
      await _adapter.unlockAchievement(id);
    } catch (error, stackTrace) {
      _lastError = error.toString();
      debugPrint('ELXVRO Play Games achievement sync failed: $error');
      debugPrintStack(stackTrace: stackTrace);
    }
  }

  @override
  Future<void> showLeaderboards() async {
    try {
      if (!await _ensureConnected()) return;
      await _adapter.showLeaderboards();
    } catch (error, stackTrace) {
      _lastError = error.toString();
      debugPrint('ELXVRO Play Games leaderboard UI failed: $error');
      debugPrintStack(stackTrace: stackTrace);
    }
  }

  Future<void> showLeaderboard({required String leaderboardId}) async {
    final id = leaderboardId.trim();
    if (id.isEmpty) return;
    try {
      if (!await _ensureConnected()) return;
      await _adapter.showLeaderboard(leaderboardId: id);
    } catch (error, stackTrace) {
      _lastError = error.toString();
      debugPrint('ELXVRO Play Games tournament UI failed: $error');
      debugPrintStack(stackTrace: stackTrace);
    }
  }

  @override
  Future<void> showAchievements() async {
    try {
      if (!await _ensureConnected()) return;
      await _adapter.showAchievements();
    } catch (error, stackTrace) {
      _lastError = error.toString();
      debugPrint('ELXVRO Play Games achievements UI failed: $error');
      debugPrintStack(stackTrace: stackTrace);
    }
  }
}
