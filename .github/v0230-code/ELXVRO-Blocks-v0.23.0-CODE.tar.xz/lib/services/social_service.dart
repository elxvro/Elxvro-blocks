import '../l10n/app_strings.dart';

class SocialConnectionInfo {
  const SocialConnectionInfo({
    required this.connected,
    required this.provider,
    required this.message,
  });

  final bool connected;
  final String provider;
  final String message;
}

abstract interface class SocialService {
  Future<SocialConnectionInfo> connectionInfo();

  Future<bool> signIn();

  Future<void> submitScore({
    required String leaderboardId,
    required int score,
  });

  Future<void> unlockAchievement({required String achievementId});

  Future<void> showLeaderboards();

  Future<void> showAchievements();
}

/// Offline implementation used when Play Games is unavailable or not yet
/// configured. Every remote action is intentionally a safe no-op so gameplay
/// and local progress never depend on a network/account connection.
class LocalSocialService implements SocialService {
  const LocalSocialService();

  @override
  Future<SocialConnectionInfo> connectionInfo() async {
    return SocialConnectionInfo(
      connected: false,
      provider: 'Google Play Games',
      message: AppStrings.current.f10('Play Games bağlı değil. Yerel kayıtlar kullanılmaya devam eder.', 'Play Games is not connected. Local progress will continue to be used.', 'Play Games ist nicht verbunden. Lokaler Fortschritt wird weiterhin verwendet.', 'Play Games no está conectado. Se seguirá usando el progreso local.', 'Play Games n’est pas connecté. La progression locale reste utilisée.', 'Play Games non è connesso. Continueranno a essere usati i progressi locali.', 'Play Games não está conectado. O progresso local continuará sendo usado.', 'Play Games is niet verbonden. Lokale voortgang blijft in gebruik.', 'Play Games nie jest połączone. Lokalny postęp będzie nadal używany.', 'Play Games не подключён. Локальный прогресс продолжит использоваться.'),
    );
  }

  @override
  Future<bool> signIn() async => false;

  @override
  Future<void> submitScore({
    required String leaderboardId,
    required int score,
  }) async {}

  @override
  Future<void> unlockAchievement({required String achievementId}) async {}

  @override
  Future<void> showLeaderboards() async {}

  @override
  Future<void> showAchievements() async {}
}
