import 'dart:async';

import 'package:flutter/material.dart';

import '../app_state.dart';
import '../l10n/app_strings.dart';
import '../models/game_theme.dart';
import '../services/audio_service.dart';
import '../widgets/coin_badge.dart';
import '../widgets/premium_background.dart';

class RewardsScreen extends StatelessWidget {
  const RewardsScreen({super.key, required this.appState});

  final AppState appState;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: appState,
      builder: (context, _) {
        final selectedTheme = gameThemes.firstWhere(
          (theme) => theme.id == appState.themeId,
          orElse: () => gameThemes.first,
        );
        const rewards = <int>[50, 75, 100, 125, 150, 200, 300];
        final activeDay = appState.dailyRewardDay;

        return Scaffold(
          body: PremiumBackground(
            top: selectedTheme.backgroundTop,
            bottom: selectedTheme.backgroundBottom,
            material: selectedTheme.material,
            accent: selectedTheme.blockAccent,
            child: SafeArea(
              child: Column(
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.fromLTRB(8, 8, 18, 10),
                    child: Row(
                      children: <Widget>[
                        IconButton(
                          onPressed: () => Navigator.of(context).pop(),
                          icon: const Icon(Icons.arrow_back_rounded),
                        ),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                AppStrings.current.f10("GÜNLÜK ÖDÜL", "DAILY REWARD", "TAGESBELOHNUNG", "RECOMPENSA DIARIA", "RÉCOMPENSE QUOTIDIENNE", "RICOMPENSA GIORNALIERA", "RECOMPENSA DIÁRIA", "DAGELIJKSE BELONING", "DZIENNA NAGRODA", "ЕЖЕДНЕВНАЯ НАГРАДА"),
                                style: TextStyle(
                                  color: Color(0xFFFFD99A),
                                  fontSize: 21,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: 2,
                                ),
                              ),
                              SizedBox(height: 2),
                              Text(
                                AppStrings.current.f10("Her gün gel, seriyi büyüt", "Return every day and grow your streak", "Komm jeden Tag zurück und verlängere deine Serie", "Vuelve cada día y aumenta tu racha", "Reviens chaque jour et prolonge ta série", "Torna ogni giorno e aumenta la tua serie", "Volte todos os dias e aumente sua sequência", "Kom elke dag terug en bouw je reeks uit", "Wracaj codziennie i wydłużaj serię", "Возвращайтесь каждый день и увеличивайте серию"),
                                style: TextStyle(
                                  color: Colors.white54,
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ),
                        ),
                        CoinBadge(coins: appState.coins, compact: true),
                      ],
                    ),
                  ),
                  Expanded(
                    child: ListView(
                      padding: const EdgeInsets.fromLTRB(18, 12, 18, 28),
                      children: <Widget>[
                        Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(24),
                            color: Colors.white.withValues(alpha: 0.045),
                            border: Border.all(
                              color: selectedTheme.blockAccent
                                  .withValues(alpha: 0.20),
                            ),
                          ),
                          child: Column(
                            children: <Widget>[
                              const Icon(
                                Icons.local_fire_department_rounded,
                                color: Color(0xFFFFC86E),
                                size: 42,
                              ),
                              const SizedBox(height: 10),
                              Text(
                                AppStrings.current.f10("${appState.loginStreak} GÜNLÜK SERİ", "${appState.loginStreak} DAY STREAK", "${appState.loginStreak} TAG SERIE", "${appState.loginStreak} DÍA RACHA", "${appState.loginStreak} JOUR SÉRIE", "${appState.loginStreak} GIORNO SERIE", "${appState.loginStreak} DIA SEQUÊNCIA", "${appState.loginStreak} DAG REEKS", "${appState.loginStreak} DZIEŃ SERIA", "${appState.loginStreak} ДЕНЬ СЕРИЯ"),
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w900,
                                  fontSize: 18,
                                  letterSpacing: 1.2,
                                ),
                              ),
                              const SizedBox(height: 6),
                              Text(
                                appState.dailyRewardAvailable
                                    ? AppStrings.current.f10("Bugünün ödülü hazır.", "Daily reward is ready.", "Die Tagesbelohnung ist bereit.", "La recompensa diaria está lista.", "La récompense quotidienne est prête.", "La ricompensa giornaliera è pronta.", "A recompensa diária está pronta.", "De dagelijkse beloning is klaar.", "Dzienna nagroda jest gotowa.", "Ежедневная награда готова.")
                                    : AppStrings.current.f10("Bugünün ödülünü aldın. Yarın tekrar gel.", "Daily reward claimed. Return tomorrow.", "Tagesbelohnung abgeholt. Komm morgen wieder.", "Recompensa diaria reclamada. Vuelve mañana.", "Récompense quotidienne récupérée. Reviens demain.", "Ricompensa giornaliera riscossa. Torna domani.", "Recompensa diária resgatada. Volte amanhã.", "Dagelijkse beloning geclaimd. Kom morgen terug.", "Dzienna nagroda odebrana. Wróć jutro.", "Ежедневная награда получена. Возвращайтесь завтра."),
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                  color: Colors.white54,
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),
                        GridView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          gridDelegate:
                              const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,
                            crossAxisSpacing: 10,
                            mainAxisSpacing: 10,
                            childAspectRatio: 1.35,
                          ),
                          itemCount: rewards.length,
                          itemBuilder: (context, index) {
                            final day = index + 1;
                            final claimed = !appState.dailyRewardAvailable &&
                                day <= appState.loginStreak;
                            final isCurrent = appState.dailyRewardAvailable
                                ? day == activeDay
                                : day == appState.loginStreak;
                            return Container(
                              padding: const EdgeInsets.all(14),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(18),
                                color: isCurrent
                                    ? const Color(0xFFFFC86E)
                                        .withValues(alpha: 0.12)
                                    : Colors.white.withValues(alpha: 0.035),
                                border: Border.all(
                                  color: isCurrent
                                      ? const Color(0xFFFFC86E)
                                          .withValues(alpha: 0.55)
                                      : Colors.white.withValues(alpha: 0.07),
                                ),
                              ),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Text(
                                    AppStrings.current.f10("$day. GÜN", "DAY $day", "TAG $day", "DÍA $day", "JOUR $day", "GIORNO $day", "DIA $day", "DAG $day", "DZIEŃ $day", "ДЕНЬ $day"),
                                    style: TextStyle(
                                      color: isCurrent
                                          ? const Color(0xFFFFD98B)
                                          : Colors.white54,
                                      fontWeight: FontWeight.w800,
                                      fontSize: 11,
                                    ),
                                  ),
                                  const SizedBox(height: 7),
                                  Icon(
                                    claimed
                                        ? Icons.check_circle_rounded
                                        : Icons.monetization_on_rounded,
                                    color: claimed
                                        ? const Color(0xFF79D993)
                                        : const Color(0xFFFFC86E),
                                    size: 26,
                                  ),
                                  const SizedBox(height: 5),
                                  Text(
                                    '+${rewards[index]}',
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 17,
                                      fontWeight: FontWeight.w900,
                                    ),
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                        const SizedBox(height: 18),
                        SizedBox(
                          width: double.infinity,
                          height: 54,
                          child: FilledButton.icon(
                            onPressed: appState.dailyRewardAvailable
                                ? () async {
                                    final amount = appState.dailyRewardAmount;
                                    final claimed =
                                        await appState.claimDailyReward();
                                    if (!context.mounted || !claimed) return;
                                    unawaited(AudioService.instance.playReward());
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                        content: Text(
                                          AppStrings.current.f10("+$amount coin hesabına eklendi.", "+$amount coins added.", "+$amount münzen hinzugefügt.", "+$amount monedas añadidas.", "+$amount pièces ajoutées.", "+$amount monete aggiunte.", "+$amount moedas adicionadas.", "+$amount munten toegevoegd.", "+$amount monety dodano.", "+$amount монеты добавлено."),
                                        ),
                                      ),
                                    );
                                  }
                                : null,
                            icon: const Icon(Icons.card_giftcard_rounded),
                            label: Text(
                              appState.dailyRewardAvailable
                                  ? AppStrings.current.f10("+${appState.dailyRewardAmount} COIN AL", "CLAIM +${appState.dailyRewardAmount} COINS", "ABHOLEN +${appState.dailyRewardAmount} MÜNZEN", "RECLAMAR +${appState.dailyRewardAmount} MONEDAS", "RÉCUPÉRER +${appState.dailyRewardAmount} PIÈCES", "RISCUOTI +${appState.dailyRewardAmount} MONETE", "RESGATAR +${appState.dailyRewardAmount} MOEDAS", "OPHALEN +${appState.dailyRewardAmount} MUNTEN", "ODBIERZ +${appState.dailyRewardAmount} MONETY", "ПОЛУЧИТЬ +${appState.dailyRewardAmount} МОНЕТЫ")
                                  : AppStrings.current.f10("BUGÜN ALINDI", "CLAIMED TODAY", "ABGEHOLT HEUTE", "RECLAMADO HOY", "RÉCUPÉRÉ AUJOURD’HUI", "RISCOSSO OGGI", "RESGATADO HOJE", "GECLAIMD VANDAAG", "ODEBRANO DZISIAJ", "ПОЛУЧЕНО СЕГОДНЯ"),
                              style: const TextStyle(
                                fontWeight: FontWeight.w900,
                                letterSpacing: 0.8,
                              ),
                            ),
                            style: FilledButton.styleFrom(
                              backgroundColor: const Color(0xFFC98B42),
                              disabledBackgroundColor:
                                  Colors.white.withValues(alpha: 0.08),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
