import 'package:flutter/material.dart';

import '../app_state.dart';
import '../l10n/app_strings.dart';
import '../models/game_theme.dart';
import '../widgets/premium_background.dart';

class StatsScreen extends StatelessWidget {
  const StatsScreen({super.key, required this.appState});

  final AppState appState;

  @override
  Widget build(BuildContext context) {
    final selectedTheme = gameThemes.firstWhere(
      (theme) => theme.id == appState.themeId,
      orElse: () => gameThemes.first,
    );

    final stats = <_StatData>[
      _StatData(
        title: AppStrings.current.f10("Oyuncu Seviyesi", "Player Level", "Spielerlevel", "Nivel del jugador", "Niveau du joueur", "Livello giocatore", "Nível do jogador", "Spelerniveau", "Poziom gracza", "Уровень игрока"),
        value: 'LV ${appState.playerLevel}',
        icon: Icons.workspace_premium_rounded,
      ),
      _StatData(
        title: AppStrings.current.f10("Toplam XP", "Total XP", "Gesamt-XP", "XP total", "XP total", "XP totali", "XP total", "Totale XP", "Łączne XP", "Всего XP"),
        value: '${appState.xp}',
        icon: Icons.trending_up_rounded,
      ),
      _StatData(
        title: AppStrings.current.f10("Perfect Clear", "Perfect Clear", "Perfekte Leerung", "Limpieza perfecta", "Nettoyage parfait", "Pulizia perfetta", "Limpeza perfeita", "Perfect leeg", "Idealne czyszczenie", "Идеальная очистка"),
        value: '${appState.perfectClears}',
        icon: Icons.auto_awesome_rounded,
      ),
      _StatData(
        title: AppStrings.current.f10("En Yüksek Skor", "Best Score", "Beste Punkte", "Mejor Puntuación", "Meilleur Score", "Migliore Punteggio", "Melhor Pontuação", "Beste Score", "Najlepszy Wynik", "Лучший Счёт"),
        value: '${appState.bestScore}',
        icon: Icons.emoji_events_rounded,
      ),
      _StatData(
        title: AppStrings.current.f10("Oynanan Oyun", "Games Played", "Spiele Gespielt", "Partidas Jugadas", "Parties Jouées", "Partite Giocate", "Partidas Jogadas", "Spellen Gespeeld", "Gry Rozegrane", "Игры Сыграно"),
        value: '${appState.gamesPlayed}',
        icon: Icons.sports_esports_rounded,
      ),
      _StatData(
        title: AppStrings.current.f10("Maksimum Combo", "Max Combo", "Maximale Combo", "Combo máxima", "Combo maximale", "Combo massima", "Combo máxima", "Maximale combo", "Maksymalne combo", "Максимальное комбо"),
        value: 'x${appState.maxCombo}',
        icon: Icons.bolt_rounded,
      ),
      _StatData(
        title: AppStrings.current.f10("Toplam Puan", "Total Score", "Gesamtpunktzahl", "Puntuación total", "Score total", "Punteggio totale", "Pontuação total", "Totale score", "Łączny wynik", "Общий счёт"),
        value: '${appState.totalScore}',
        icon: Icons.stars_rounded,
      ),
      _StatData(
        title: AppStrings.current.f10("Temizlenen Çizgi", "Lines Cleared", "Geräumte Linien", "Líneas limpiadas", "Lignes effacées", "Linee eliminate", "Linhas limpas", "Gewiste lijnen", "Wyczyszczone linie", "Очищенные линии"),
        value: '${appState.totalLines}',
        icon: Icons.auto_awesome_rounded,
      ),
      _StatData(
        title: AppStrings.current.f10("Yerleştirilen Parça", "Pieces Placed", "Teile Platziert", "Piezas Colocadas", "Pièces Placées", "Pezzi Posizionati", "Peças Posicionadas", "Stukken Geplaatst", "Elementy Umieszczone", "Фигуры Размещено"),
        value: '${appState.totalBlocks}',
        icon: Icons.grid_view_rounded,
      ),
      _StatData(
        title: AppStrings.current.f10("2 Dakika Rekoru", "2 Minute Best", "Bestwert in 2 Minuten", "Mejor en 2 minutos", "Meilleur en 2 minutes", "Migliore in 2 minuti", "Melhor em 2 minutos", "Beste in 2 minuten", "Najlepszy wynik w 2 minuty", "Лучший результат за 2 минуты"),
        value: '${appState.timedBestScore}',
        icon: Icons.timer_outlined,
      ),
      _StatData(
        title: AppStrings.current.f10("Hedef 5000 Rekoru", "Target 5000 Best", "Bestwert Ziel 5000", "Mejor objetivo 5000", "Meilleur objectif 5000", "Migliore obiettivo 5000", "Melhor alvo 5000", "Beste doel 5000", "Najlepszy cel 5000", "Лучший результат цели 5000"),
        value: '${appState.targetBestScore}',
        icon: Icons.flag_rounded,
      ),
      _StatData(
        title: AppStrings.current.f10("Günlük Rekor", "Daily Best", "Tagesbestwert", "Mejor diario", "Meilleur quotidien", "Migliore giornaliero", "Melhor diário", "Dagrecord", "Najlepszy dzienny", "Лучший дневной результат"),
        value: '${appState.dailyChallengeBestScore}',
        icon: Icons.local_fire_department_rounded,
      ),
      _StatData(
        title: AppStrings.current.f10("Zen Rekoru", "Zen Best", "Zen Beste", "Zen Mejor", "Zen Meilleur", "Zen Migliore", "Zen Melhor", "Zen Beste", "Zen Najlepszy", "Zen Лучший"),
        value: '${appState.zenBestScore}',
        icon: Icons.spa_rounded,
      ),
      _StatData(
        title: AppStrings.current.f10("Zor Mod Rekoru", "Hard Mode Best", "Bestwert im schweren Modus", "Mejor en modo difícil", "Meilleur en mode difficile", "Migliore in modalità difficile", "Melhor no modo difícil", "Beste in moeilijke modus", "Najlepszy w trybie trudnym", "Лучший результат в сложном режиме"),
        value: '${appState.hardBestScore}',
        icon: Icons.whatshot_rounded,
      ),
    ];

    return Scaffold(
      body: PremiumBackground(
        top: selectedTheme.backgroundTop,
        bottom: selectedTheme.backgroundBottom,
        material: selectedTheme.material,
        accent: selectedTheme.blockAccent,
        child: SafeArea(
          child: Column(
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.fromLTRB(8, 8, 20, 14),
                child: Row(
                  children: <Widget>[
                    IconButton(
                      onPressed: () => Navigator.of(context).pop(),
                      icon: const Icon(Icons.arrow_back_rounded),
                    ),
                    const SizedBox(width: 4),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            AppStrings.current.f10("İSTATİSTİKLER", "STATISTICS", "STATISTIKEN", "ESTADÍSTICAS", "STATISTIQUES", "STATISTICHE", "ESTATÍSTICAS", "STATISTIEKEN", "STATYSTYKI", "СТАТИСТИКА"),
                            style: TextStyle(
                              color: selectedTheme.blockAccent,
                              fontSize: 21,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 2.0,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            AppStrings.current.f10("ELXVRO Blocks kariyerin", "Your ELXVRO Blocks career", "Deine ELXVRO-Blocks-Karriere", "Tu carrera en ELXVRO Blocks", "Ta carrière ELXVRO Blocks", "La tua carriera in ELXVRO Blocks", "Sua carreira no ELXVRO Blocks", "Je ELXVRO Blocks-carrière", "Twoja kariera w ELXVRO Blocks", "Ваша карьера в ELXVRO Blocks"),
                            style: TextStyle(color: Colors.white54, fontSize: 12),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: GridView.builder(
                  padding: const EdgeInsets.fromLTRB(18, 8, 18, 28),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    mainAxisSpacing: 12,
                    crossAxisSpacing: 12,
                    childAspectRatio: 1.12,
                  ),
                  itemCount: stats.length,
                  itemBuilder: (context, index) => _StatCard(
                    data: stats[index],
                    accent: selectedTheme.blockAccent,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard({required this.data, required this.accent});

  final _StatData data;
  final Color accent;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        color: Colors.white.withValues(alpha: 0.045),
        border: Border.all(color: Colors.white.withValues(alpha: 0.07)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Icon(data.icon, color: accent, size: 25),
          const Spacer(),
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Text(
              data.value,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 28,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          const SizedBox(height: 5),
          Text(
            data.title,
            style: const TextStyle(color: Colors.white54, fontSize: 11),
          ),
        ],
      ),
    );
  }
}

class _StatData {
  const _StatData({
    required this.title,
    required this.value,
    required this.icon,
  });

  final String title;
  final String value;
  final IconData icon;
}
