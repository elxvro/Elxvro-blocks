import 'dart:async';

import 'package:flutter/material.dart';

import '../app_state.dart';
import '../l10n/app_strings.dart';
import '../models/game_theme.dart';
import '../services/audio_service.dart';
import '../widgets/premium_background.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key, required this.appState});

  final AppState appState;

  @override
  Widget build(BuildContext context) {
    final selectedTheme = gameThemes.firstWhere(
      (theme) => theme.id == appState.themeId,
      orElse: () => gameThemes.first,
    );

    return Scaffold(
      body: PremiumBackground(
        top: selectedTheme.backgroundTop,
        bottom: selectedTheme.backgroundBottom,
        material: selectedTheme.material,
        accent: selectedTheme.blockAccent,
        child: SafeArea(
          child: AnimatedBuilder(
            animation: appState,
            builder: (context, _) {
              final l = AppStrings(appState.languageCode);
              return Column(
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.fromLTRB(8, 6, 14, 8),
                    child: Row(
                      children: <Widget>[
                        IconButton(
                          onPressed: () => Navigator.of(context).pop(),
                          icon: const Icon(Icons.arrow_back_rounded),
                        ),
                        Expanded(
                          child: Text(
                            l.t('settings.title'),
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              color: Color(0xFFFFD98B),
                              fontWeight: FontWeight.w800,
                              letterSpacing: 2,
                            ),
                          ),
                        ),
                        const SizedBox(width: 48),
                      ],
                    ),
                  ),
                  Expanded(
                    child: ListView(
                      padding: const EdgeInsets.fromLTRB(18, 12, 18, 28),
                      children: <Widget>[
                        _LanguageCard(
                          title: l.t('settings.language'),
                          subtitle: l.t('settings.language_subtitle'),
                          selected: appState.languageCode,
                          onChanged: appState.setLanguage,
                        ),
                        const SizedBox(height: 12),
                        _SettingCard(
                          icon: Icons.music_note_rounded,
                          title: l.t('settings.music'),
                          subtitle: l.t('settings.music_subtitle'),
                          value: appState.musicEnabled,
                          onChanged: appState.setMusicEnabled,
                        ),
                        const SizedBox(height: 12),
                        _VolumeCard(
                          icon: Icons.graphic_eq_rounded,
                          title: l.t('settings.music_level'),
                          value: appState.musicVolume,
                          enabled: appState.musicEnabled,
                          onChanged: (value) {
                            unawaited(appState.setMusicVolume(value));
                          },
                        ),
                        const SizedBox(height: 12),
                        _SettingCard(
                          icon: Icons.volume_up_rounded,
                          title: l.t('settings.sfx'),
                          subtitle: l.t('settings.sfx_subtitle'),
                          value: appState.soundEnabled,
                          onChanged: appState.setSoundEnabled,
                        ),
                        const SizedBox(height: 12),
                        _VolumeCard(
                          icon: Icons.surround_sound_rounded,
                          title: l.t('settings.sfx_level'),
                          value: appState.sfxVolume,
                          enabled: appState.soundEnabled,
                          onChanged: (value) {
                            unawaited(appState.setSfxVolume(value));
                          },
                          onPreview: appState.soundEnabled
                              ? () => unawaited(
                                  AudioService.instance.playThemePreview(
                                    selectedTheme.audioProfile,
                                  ),
                                )
                              : null,
                        ),
                        const SizedBox(height: 12),
                        _SettingCard(
                          icon: Icons.touch_app_rounded,
                          title: l.t('settings.ui'),
                          subtitle: l.t('settings.ui_subtitle'),
                          value: appState.uiSoundEnabled,
                          onChanged: appState.setUiSoundEnabled,
                        ),
                        const SizedBox(height: 12),
                        _VolumeCard(
                          icon: Icons.tune_rounded,
                          title: l.t('settings.ui_level'),
                          value: appState.uiVolume,
                          enabled: appState.uiSoundEnabled,
                          onChanged: (value) {
                            unawaited(appState.setUiVolume(value));
                          },
                          onPreview: appState.uiSoundEnabled
                              ? () => unawaited(AudioService.instance.playClick())
                              : null,
                        ),
                        const SizedBox(height: 12),
                        _SettingCard(
                          icon: Icons.vibration_rounded,
                          title: l.t('settings.haptics'),
                          subtitle: l.t('settings.haptics_subtitle'),
                          value: appState.hapticsEnabled,
                          onChanged: appState.setHapticsEnabled,
                        ),
                        const SizedBox(height: 12),
                        _SettingCard(
                          icon: Icons.speed_rounded,
                          title: l.t('settings.performance'),
                          subtitle: l.t('settings.performance_subtitle'),
                          value: appState.performanceMode,
                          onChanged: appState.setPerformanceMode,
                        ),
                        const SizedBox(height: 12),
                        _ActionCard(
                          icon: Icons.school_outlined,
                          title: l.t('settings.tutorial'),
                          subtitle: l.t('settings.tutorial_subtitle'),
                          onTap: () async {
                            await appState.resetTutorial();
                            if (!context.mounted) return;
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text(
                                  AppStrings.current.f10("Eğitim bir sonraki oyunda gösterilecek.", "The tutorial will be shown in the next game.", "Das Tutorial wird im nächsten Spiel angezeigt.", "El tutorial se mostrará en la próxima partida.", "Le tutoriel sera affiché à la prochaine partie.", "Il tutorial verrà mostrato nella prossima partita.", "O tutorial será exibido na próxima partida.", "De tutorial wordt in het volgende spel getoond.", "Samouczek zostanie pokazany w następnej grze.", "Обучение будет показано в следующей игре."),
                                ),
                              ),
                            );
                          },
                        ),
                        const SizedBox(height: 12),
                        _StatusCard(
                          icon: Icons.sports_esports_rounded,
                          title: 'GOOGLE PLAY GAMES',
                          subtitle: AppStrings.current.f10("Altyapı hazır • Play Console bağlantısı sonraki sürümde açılabilir", "Infrastructure ready • Play Console connection can be enabled later", "Infrastruktur bereit • Play-Console-Verbindung kann später aktiviert werden", "Infraestructura lista • La conexión con Play Console puede activarse más adelante", "Infrastructure prête • La connexion Play Console pourra être activée plus tard", "Infrastruttura pronta • La connessione a Play Console potrà essere attivata in seguito", "Infraestrutura pronta • A conexão com o Play Console pode ser ativada depois", "Infrastructuur gereed • Play Console-verbinding kan later worden ingeschakeld", "Infrastruktura gotowa • Połączenie z Play Console można włączyć później", "Инфраструктура готова • Подключение Play Console можно включить позже"),
                          status: AppStrings.current.f10("HAZIRLIK", "PREPARING", "VORBEREITUNG", "PREPARANDO", "PRÉPARATION", "PREPARAZIONE", "PREPARANDO", "VOORBEREIDEN", "PRZYGOTOWANIE", "ПОДГОТОВКА"),
                        ),
                        const SizedBox(height: 22),
                        Container(
                          padding: const EdgeInsets.all(18),
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.035),
                            borderRadius: BorderRadius.circular(22),
                            border: Border.all(
                              color: Colors.white.withValues(alpha: 0.05),
                            ),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                'ELXVRO BLOCKS',
                                style: TextStyle(
                                  color: Color(0xFFFFD98B),
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: 1.4,
                                ),
                              ),
                              SizedBox(height: 8),
                              Text(
                                AppStrings.current.f10("v0.23.0  •  10 DİL + TAM ÇEVİRİ", "v0.23.0  •  10 LANGUAGES + FULL LOCALIZATION", "v0.23.0  •  10 SPRACHEN + VOLLSTÄNDIGE LOKALISIERUNG", "v0.23.0  •  10 IDIOMAS + LOCALIZACIÓN COMPLETA", "v0.23.0  •  10 LANGUES + LOCALISATION COMPLÈTE", "v0.23.0  •  10 LINGUE + LOCALIZZAZIONE COMPLETA", "v0.23.0  •  10 IDIOMAS + LOCALIZAÇÃO COMPLETA", "v0.23.0  •  10 TALEN + VOLLEDIGE LOKALISATIE", "v0.23.0  •  10 JĘZYKÓW + PEŁNA LOKALIZACJA", "v0.23.0  •  10 ЯЗЫКОВ + ПОЛНАЯ ЛОКАЛИЗАЦИЯ"),
                                style: TextStyle(color: Colors.white54),
                              ),
                              SizedBox(height: 6),
                              Text(
                                'com.elxvro.elxvro_blocks',
                                style: TextStyle(
                                  color: Colors.white30,
                                  fontSize: 10,
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}

class _LanguageCard extends StatelessWidget {
  const _LanguageCard({
    required this.title,
    required this.subtitle,
    required this.selected,
    required this.onChanged,
  });

  final String title;
  final String subtitle;
  final String selected;
  final ValueChanged<String> onChanged;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.045),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: Colors.white.withValues(alpha: 0.065)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              const Icon(Icons.language_rounded, color: Color(0xFFFFCF7A)),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      title,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.7,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      subtitle,
                      style: const TextStyle(color: Colors.white38, fontSize: 11),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.045),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Colors.white.withValues(alpha: 0.07)),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: selected,
                isExpanded: true,
                dropdownColor: const Color(0xFF121719),
                icon: const Icon(Icons.expand_more_rounded),
                items: AppStrings.languages
                    .map(
                      (language) => DropdownMenuItem<String>(
                        value: language.code,
                        child: Row(
                          children: <Widget>[
                            SizedBox(
                              width: 34,
                              child: Text(
                                language.shortCode,
                                style: const TextStyle(
                                  color: Color(0xFFFFCF7A),
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                            ),
                            Expanded(
                              child: Text(
                                language.name,
                                style: const TextStyle(color: Colors.white),
                              ),
                            ),
                          ],
                        ),
                      ),
                    )
                    .toList(growable: false),
                onChanged: (value) {
                  if (value != null) onChanged(value);
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _VolumeCard extends StatelessWidget {
  const _VolumeCard({
    required this.icon,
    required this.title,
    required this.value,
    required this.enabled,
    required this.onChanged,
    this.onPreview,
  });

  final IconData icon;
  final String title;
  final double value;
  final bool enabled;
  final ValueChanged<double> onChanged;
  final VoidCallback? onPreview;

  @override
  Widget build(BuildContext context) {
    final percent = (value * 100).round();
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 12, 12, 10),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: enabled ? 0.04 : 0.025),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: Colors.white.withValues(alpha: 0.055)),
      ),
      child: Column(
        children: <Widget>[
          Row(
            children: <Widget>[
              Icon(
                icon,
                color: enabled ? const Color(0xFFFFCF7A) : Colors.white24,
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Text(
                  title,
                  style: TextStyle(
                    color: enabled ? Colors.white : Colors.white38,
                    fontSize: 13,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.7,
                  ),
                ),
              ),
              Text(
                '%$percent',
                style: TextStyle(
                  color: enabled ? const Color(0xFFFFD98B) : Colors.white30,
                  fontSize: 11,
                  fontWeight: FontWeight.w800,
                ),
              ),
              if (onPreview != null) ...<Widget>[
                const SizedBox(width: 4),
                IconButton(
                  tooltip: AppStrings.current.t('settings.preview'),
                  visualDensity: VisualDensity.compact,
                  onPressed: onPreview,
                  icon: const Icon(
                    Icons.play_circle_outline_rounded,
                    color: Color(0xFFFFD98B),
                  ),
                ),
              ],
            ],
          ),
          Slider(
            value: value,
            onChanged: enabled ? onChanged : null,
          ),
        ],
      ),
    );
  }
}

class _ActionCard extends StatelessWidget {
  const _ActionCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white.withValues(alpha: 0.04),
      borderRadius: BorderRadius.circular(22),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(22),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
          child: Row(
            children: <Widget>[
              Icon(icon, color: const Color(0xFFFFCF7A)),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      title,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.7,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      subtitle,
                      style: const TextStyle(
                        color: Colors.white38,
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right_rounded, color: Colors.white38),
            ],
          ),
        ),
      ),
    );
  }
}

class _StatusCard extends StatelessWidget {
  _StatusCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.status,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final String status;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.04),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: Colors.white.withValues(alpha: 0.055)),
      ),
      child: Row(
        children: <Widget>[
          Icon(icon, color: const Color(0xFFFFCF7A)),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  title,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.7,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  subtitle,
                  style: const TextStyle(color: Colors.white38, fontSize: 11),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
            decoration: BoxDecoration(
              color: const Color(0xFFFFC86E).withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(999),
            ),
            child: Text(
              status,
              style: const TextStyle(
                color: Color(0xFFFFD98B),
                fontSize: 8,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SettingCard extends StatelessWidget {
  const _SettingCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.value,
    required this.onChanged,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.04),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: Colors.white.withValues(alpha: 0.055)),
      ),
      child: SwitchListTile(
        value: value,
        onChanged: onChanged,
        secondary: Icon(icon, color: const Color(0xFFFFCF7A)),
        title: Text(
          title,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 13,
            fontWeight: FontWeight.w800,
            letterSpacing: 0.9,
          ),
        ),
        subtitle: Text(
          subtitle,
          style: const TextStyle(color: Colors.white38, fontSize: 11),
        ),
        activeThumbColor: const Color(0xFFFFD98B),
        activeTrackColor: const Color(0xFFC7863C),
      ),
    );
  }
}
