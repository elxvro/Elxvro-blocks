import 'dart:async';

import 'package:flutter/material.dart';

import '../app_state.dart';
import '../l10n/app_strings.dart';
import '../models/game_theme.dart';
import '../services/audio_service.dart';
import '../services/social_service.dart';
import '../widgets/coin_badge.dart';
import '../widgets/premium_background.dart';

class SocialHubScreen extends StatelessWidget {
  const SocialHubScreen({
    super.key,
    required this.appState,
    this.socialService = const LocalSocialService(),
  });

  final AppState appState;
  final SocialService socialService;

  @override
  Widget build(BuildContext context) {
    final selectedTheme = gameThemes.firstWhere(
      (theme) => theme.id == appState.themeId,
      orElse: () => gameThemes.first,
    );

    return Scaffold(
      body: PremiumBackground(
        top: selectedTheme.backgroundTop,
        bottom: selectedTheme.backgroundBottom,
        material: selectedTheme.material,
        accent: selectedTheme.blockAccent,
        child: SafeArea(
          child: AnimatedBuilder(
            animation: appState,
            builder: (context, _) {
              return Column(
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.fromLTRB(8, 6, 14, 8),
                    child: Row(
                      children: <Widget>[
                        IconButton(
                          onPressed: () => Navigator.of(context).pop(),
                          icon: const Icon(Icons.arrow_back_rounded),
                        ),
                        Expanded(
                          child: Text(
                            AppStrings.current.f10("LİDERLİK MERKEZİ", "LEADERBOARD HUB", "BESTENLISTEN-ZENTRALE", "CENTRO DE CLASIFICACIONES", "CENTRE DES CLASSEMENTS", "CENTRO CLASSIFICHE", "CENTRAL DE RANKINGS", "RANGLIJSTCENTRUM", "CENTRUM RANKINGÓW", "ЦЕНТР РЕЙТИНГОВ"),
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: Color(0xFFFFD98B),
                              fontWeight: FontWeight.w800,
                              letterSpacing: 1.7,
                            ),
                          ),
                        ),
                        CoinBadge(coins: appState.coins, compact: true),
                      ],
                    ),
                  ),
                  Expanded(
                    child: ListView(
                      padding: const EdgeInsets.fromLTRB(18, 10, 18, 30),
                      children: <Widget>[
                        _PlayerCard(appState: appState),
                        const SizedBox(height: 14),
                        _SectionTitle(AppStrings.current.f10("KİŞİSEL REKORLAR", "PERSONAL BESTS", "PERSÖNLICHE BESTWERTE", "MEJORES MARCAS", "RECORDS PERSONNELS", "RECORD PERSONALI", "MELHORES RESULTADOS", "PERSOONLIJKE RECORDS", "REKORDY OSOBISTE", "ЛИЧНЫЕ РЕКОРДЫ")),
                        const SizedBox(height: 10),
                        _RecordGrid(appState: appState),
                        const SizedBox(height: 18),
                        _SectionTitle(AppStrings.current.f10("BU HAFTA", "THIS WEEK", "DIESE WOCHE", "ESTA SEMANA", "CETTE SEMAINE", "QUESTA SETTIMANA", "ESTA SEMANA", "DEZE WEEK", "TEN TYDZIEŃ", "ЭТА НЕДЕЛЯ")),
                        const SizedBox(height: 10),
                        _WeeklyCard(appState: appState),
                        const SizedBox(height: 18),
                        const _SectionTitle('GOOGLE PLAY GAMES'),
                        const SizedBox(height: 10),
                        _ConnectionCard(service: socialService),
                        const SizedBox(height: 12),
                        Text(
                          AppStrings.current.f10("Play Console yapılandırıldığında bu ekran global sıralama ve başarımları aynı kayıt mimarisi üzerinden gösterecek. Şimdilik hiçbir çevrimiçi sıralama taklit edilmez.", "Global leaderboards and achievements will appear here after Play Console setup.", "Globale Bestenlisten und Erfolge erscheinen hier nach der Play-Console-Einrichtung.", "Las clasificaciones globales y los logros aparecerán aquí tras configurar Play Console.", "Les classements mondiaux et les succès apparaîtront ici après la configuration de Play Console.", "Classifiche globali e obiettivi appariranno qui dopo la configurazione di Play Console.", "Rankings globais e conquistas aparecerão aqui após configurar o Play Console.", "Wereldwijde ranglijsten en prestaties verschijnen hier na de Play Console-configuratie.", "Globalne rankingi i osiągnięcia pojawią się tutaj po konfiguracji Play Console.", "Глобальные таблицы лидеров и достижения появятся здесь после настройки Play Console."),
                          style: TextStyle(
                            color: Colors.white.withValues(alpha: 0.38),
                            fontSize: 10,
                            height: 1.45,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}

class _PlayerCard extends StatelessWidget {
  const _PlayerCard({required this.appState});

  final AppState appState;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        color: const Color(0xFFFFC86E).withValues(alpha: 0.07),
        border: Border.all(
          color: const Color(0xFFFFC86E).withValues(alpha: 0.22),
        ),
      ),
      child: Row(
        children: <Widget>[
          Container(
            width: 52,
            height: 52,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                colors: <Color>[Color(0xFFFFD98B), Color(0xFF9B5E24)],
              ),
            ),
            alignment: Alignment.center,
            child: Text(
              '${appState.playerLevel}',
              style: const TextStyle(
                color: Color(0xFF1A0F06),
                fontSize: 20,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  appState.playerName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.6,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  AppStrings.current.f10("SEVİYE ${appState.playerLevel}  •  ${appState.xp} XP", "LEVEL ${appState.playerLevel}  •  ${appState.xp} XP", "STUFE ${appState.playerLevel}  •  ${appState.xp} XP", "NIVEL ${appState.playerLevel}  •  ${appState.xp} XP", "NIVEAU ${appState.playerLevel}  •  ${appState.xp} XP", "LIVELLO ${appState.playerLevel}  •  ${appState.xp} XP", "NÍVEL ${appState.playerLevel}  •  ${appState.xp} XP", "NIVEAU ${appState.playerLevel}  •  ${appState.xp} XP", "POZIOM ${appState.playerLevel}  •  ${appState.xp} XP", "УРОВЕНЬ ${appState.playerLevel}  •  ${appState.xp} XP"),
                  style: const TextStyle(
                    color: Color(0xFFFFD98B),
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
          const Icon(Icons.shield_outlined, color: Color(0xFFFFCF7A)),
        ],
      ),
    );
  }
}

class _RecordGrid extends StatelessWidget {
  const _RecordGrid({required this.appState});

  final AppState appState;

  @override
  Widget build(BuildContext context) {
    final records = <({IconData icon, String label, int score})>[
      (icon: Icons.grid_view_rounded, label: AppStrings.current.f10("KLASİK", "CLASSIC", "KLASSISCH", "CLÁSICO", "CLASSIQUE", "CLASSICA", "CLÁSSICO", "KLASSIEK", "KLASYCZNY", "КЛАССИКА"), score: appState.bestScore),
      (icon: Icons.timer_outlined, label: AppStrings.current.f10("2 DAKİKA", "2 MINUTES", "2 MINUTEN", "2 MINUTOS", "2 MINUTES", "2 MINUTI", "2 MINUTOS", "2 MINUTEN", "2 MINUTY", "2 МИНУТЫ"), score: appState.timedBestScore),
      (icon: Icons.flag_outlined, label: AppStrings.current.f10("HEDEF", "TARGET", "ZIEL", "OBJETIVO", "OBJECTIF", "OBIETTIVO", "ALVO", "DOEL", "CEL", "ЦЕЛЬ"), score: appState.targetBestScore),
      (icon: Icons.today_outlined, label: AppStrings.current.f10("GÜNLÜK", "DAILY", "TÄGLICH", "DIARIO", "QUOTIDIEN", "GIORNALIERO", "DIÁRIO", "DAGELIJKS", "DZIENNE", "ЕЖЕДНЕВНЫЙ"), score: appState.dailyChallengeBestScore),
      (icon: Icons.spa_outlined, label: 'ZEN', score: appState.zenBestScore),
      (icon: Icons.whatshot_outlined, label: AppStrings.current.f10("ZOR", "HARD", "SCHWER", "DIFÍCIL", "DIFFICILE", "DIFFICILE", "DIFÍCIL", "MOEILIJK", "TRUDNY", "СЛОЖНЫЙ"), score: appState.hardBestScore),
    ];

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        childAspectRatio: 1.65,
      ),
      itemCount: records.length,
      itemBuilder: (context, index) {
        final record = records[index];
        return Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.04),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Colors.white.withValues(alpha: 0.05)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Icon(record.icon, color: const Color(0xFFFFCF7A), size: 20),
              const Spacer(),
              Text(
                '${record.score}',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                ),
              ),
              Text(
                record.label,
                style: const TextStyle(
                  color: Colors.white38,
                  fontSize: 8,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 0.8,
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _WeeklyCard extends StatelessWidget {
  const _WeeklyCard({required this.appState});

  final AppState appState;

  @override
  Widget build(BuildContext context) {
    final completed = appState.weeklyScore >= AppState.weeklyGoal;
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.04),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
          color: completed
              ? const Color(0xFFFFC86E).withValues(alpha: 0.24)
              : Colors.white.withValues(alpha: 0.055),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              const Icon(Icons.calendar_view_week_rounded, color: Color(0xFFFFCF7A)),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  AppStrings.current.f10("HAFTALIK HEDEF", "WEEKLY TARGET", "WOCHENZIEL", "OBJETIVO SEMANAL", "OBJECTIF HEBDOMADAIRE", "OBIETTIVO SETTIMANALE", "META SEMANAL", "WEEKDOEL", "CEL TYGODNIOWY", "НЕДЕЛЬНАЯ ЦЕЛЬ"),
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1,
                  ),
                ),
              ),
              Text(
                '${appState.weeklyScore}/${AppState.weeklyGoal}',
                style: const TextStyle(
                  color: Color(0xFFFFD98B),
                  fontSize: 10,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          ClipRRect(
            borderRadius: BorderRadius.circular(999),
            child: LinearProgressIndicator(
              value: appState.weeklyProgress,
              minHeight: 8,
              backgroundColor: Colors.white.withValues(alpha: 0.06),
              valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFFFFC86E)),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: <Widget>[
              Expanded(child: _MiniStat(label: AppStrings.current.f10("OYUN", "GAMES", "SPIELE", "PARTIDAS", "PARTIES", "PARTITE", "PARTIDAS", "SPELLEN", "GRY", "ИГРЫ"), value: '${appState.weeklyGames}')),
              const SizedBox(width: 8),
              Expanded(child: _MiniStat(label: AppStrings.current.f10("EN İYİ", "BEST", "BESTE", "MEJOR", "MEILLEUR", "MIGLIORE", "MELHOR", "BESTE", "NAJLEPSZY", "ЛУЧШИЙ"), value: '${appState.weeklyBestScore}')),
              const SizedBox(width: 8),
              Expanded(child: _MiniStat(label: AppStrings.current.f10("ÖDÜL", "REWARD", "BELOHNUNG", "RECOMPENSA", "RÉCOMPENSE", "RICOMPENSA", "RECOMPENSA", "BELONING", "NAGRODA", "НАГРАДА"), value: '250 C')),
            ],
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: appState.weeklyRewardAvailable
                  ? () async {
                      final claimed = await appState.claimWeeklyReward();
                      if (!context.mounted || !claimed) return;
                      unawaited(AudioService.instance.playReward());
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text(AppStrings.current.f10("+250 coin haftalık ödül alındı.", "+250 weekly coins claimed.", "+250 wöchentlich münzen abgeholt.", "+250 semanal monedas reclamado.", "+250 hebdomadaire pièces récupéré.", "+250 settimanale monete riscosso.", "+250 semanal moedas resgatado.", "+250 wekelijks munten geclaimd.", "+250 tygodniowe monety odebrano.", "+250 недельный монеты получено."))),
                      );
                    }
                  : null,
              icon: Icon(
                appState.weeklyRewardClaimed
                    ? Icons.check_circle_rounded
                    : Icons.redeem_rounded,
              ),
              label: Text(
                appState.weeklyRewardClaimed
                    ? AppStrings.current.f10("BU HAFTA ALINDI", "CLAIMED THIS WEEK", "ABGEHOLT DIESE WOCHE", "RECLAMADO ESTA SEMANA", "RÉCUPÉRÉ CETTE SEMAINE", "RISCOSSO QUESTA SETTIMANA", "RESGATADO ESTA SEMANA", "DEZE WEEK OPGEHAALD", "ODEBRANO TEN TYDZIEŃ", "ПОЛУЧЕНО ЭТА НЕДЕЛЯ")
                    : completed
                        ? AppStrings.current.f10("250 COIN AL", "CLAIM 250 COINS", "ABHOLEN 250 MÜNZEN", "RECLAMAR 250 MONEDAS", "RÉCUPÉRER 250 PIÈCES", "RISCUOTI 250 MONETE", "RESGATAR 250 MOEDAS", "250 MUNTEN OPHALEN", "ODBIERZ 250 MONETY", "ПОЛУЧИТЬ 250 МОНЕТЫ")
                        : AppStrings.current.f10("HEDEFİ TAMAMLA", "COMPLETE TARGET", "ABSCHLIESSEN ZIEL", "COMPLETAR OBJETIVO", "TERMINER OBJECTIF", "COMPLETA OBIETTIVO", "CONCLUIR ALVO", "VOLTOOIEN DOEL", "UKOŃCZ CEL", "ВЫПОЛНИТЬ ЦЕЛЬ"),
              ),
              style: FilledButton.styleFrom(
                backgroundColor: const Color(0xFFC7863C),
                foregroundColor: const Color(0xFF160D06),
                disabledBackgroundColor: Colors.white.withValues(alpha: 0.06),
                disabledForegroundColor: Colors.white38,
                padding: const EdgeInsets.symmetric(vertical: 13),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ConnectionCard extends StatelessWidget {
  const _ConnectionCard({required this.service});

  final SocialService service;

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<SocialConnectionInfo>(
      future: service.connectionInfo(),
      builder: (context, snapshot) {
        final info = snapshot.data;
        return Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.04),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: Colors.white.withValues(alpha: 0.055)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Row(
                children: <Widget>[
                  const Icon(Icons.sports_esports_rounded, color: Color(0xFFFFCF7A)),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      info?.provider ?? 'Google Play Games',
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(999),
                      color: Colors.white.withValues(alpha: 0.06),
                    ),
                    child: Text(
                      info?.connected == true ? AppStrings.current.f10("BAĞLI", "CONNECTED", "VERBUNDEN", "CONECTADO", "CONNECTÉ", "CONNESSO", "CONECTADO", "VERBONDEN", "POŁĄCZONO", "ПОДКЛЮЧЕНО") : AppStrings.current.f10("ÇEVRİMDIŞI", "OFFLINE", "OFFLINE", "SIN CONEXIÓN", "HORS LIGNE", "OFFLINE", "OFFLINE", "OFFLINE", "OFFLINE", "ОФЛАЙН"),
                      style: const TextStyle(
                        color: Color(0xFFFFD98B),
                        fontSize: 8,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Text(
                info?.message ?? AppStrings.current.f10("Bağlantı durumu kontrol ediliyor...", "Checking connection status...", "Verbindungsstatus wird geprüft...", "Comprobando el estado de conexión...", "Vérification de l’état de la connexion...", "Controllo dello stato della connessione...", "Verificando o status da conexão...", "Verbindingsstatus controleren...", "Sprawdzanie stanu połączenia...", "Проверка состояния подключения..."),
                style: const TextStyle(color: Colors.white54, fontSize: 11, height: 1.4),
              ),
              const SizedBox(height: 14),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: null,
                  icon: const Icon(Icons.cloud_outlined),
                  label: Text(AppStrings.current.f10("PLAY CONSOLE SONRASI AKTİF", "ACTIVE AFTER PLAY CONSOLE", "AKTIV NACH PLAY CONSOLE", "ACTIVO TRAS PLAY CONSOLE", "ACTIF APRÈS PLAY CONSOLE", "ATTIVO DOPO PLAY CONSOLE", "ATIVO APÓS PLAY CONSOLE", "ACTIEF NA PLAY CONSOLE", "AKTYWNE PO PLAY CONSOLE", "АКТИВНО ПОСЛЕ PLAY CONSOLE")),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _MiniStat extends StatelessWidget {
  const _MiniStat({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.14),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        children: <Widget>[
          Text(
            value,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 13,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            label,
            style: const TextStyle(
              color: Colors.white38,
              fontSize: 7,
              fontWeight: FontWeight.w800,
              letterSpacing: 0.7,
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: const TextStyle(
        color: Color(0xFFFFD98B),
        fontSize: 12,
        fontWeight: FontWeight.w900,
        letterSpacing: 1.3,
      ),
    );
  }
}
