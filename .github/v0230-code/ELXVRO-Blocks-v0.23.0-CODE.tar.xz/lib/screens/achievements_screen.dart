import 'dart:async';

import 'package:flutter/material.dart';

import '../app_state.dart';
import '../l10n/app_strings.dart';
import '../models/game_theme.dart';
import '../services/audio_service.dart';
import '../widgets/coin_badge.dart';
import '../widgets/premium_background.dart';

class AchievementsScreen extends StatelessWidget {
  const AchievementsScreen({super.key, required this.appState});

  final AppState appState;

  List<_AchievementData> get _items => <_AchievementData>[
    _AchievementData(id: 'first_game', title: AppStrings.current.f10("İlk Adım", "First Step", "Erster Schritt", "Primer Paso", "Premier Pas", "Primo Passo", "Primeiro Passo", "Eerste Stap", "Pierwszy Krok", "Первый Шаг"), subtitle: AppStrings.current.f10("İlk oyununu tamamla", "Complete your first game", "Beende dein erstes Spiel", "Completa tu primera partida", "Termine ta première partie", "Completa la tua prima partita", "Conclua sua primeira partida", "Voltooi je eerste spel", "Ukończ swoją pierwszą grę", "Завершите первую игру"), reward: 100, icon: Icons.flag_rounded),
    _AchievementData(id: 'score_1000', title: AppStrings.current.f10("Isınma Turu", "Warm Up", "Aufwärmrunde", "Calentamiento", "Échauffement", "Riscaldamento", "Aquecimento", "Opwarming", "Rozgrzewka", "Разминка"), subtitle: AppStrings.current.f10("Tek oyunda 1.000 puana ulaş", "Reach 1000 points in one game", "Erreiche 1000 Punkte in einem Spiel", "Alcanza 1000 puntos en una partida", "Atteins 1000 points en une partie", "Raggiungi 1000 punti in una partita", "Alcance 1000 pontos em uma partida", "Behaal 1000 punten in één spel", "Zdobądź 1000 punktów w jednej grze", "Наберите 1000 очков за одну игру"), reward: 125, icon: Icons.local_fire_department_rounded),
    _AchievementData(id: 'combo_3', title: AppStrings.current.f10("Combo Ustası", "Combo Master", "Combo Meister", "Combo Maestro", "Combo Maître", "Combo Maestro", "Combo Mestre", "Combo Meester", "Combo Mistrz", "Combo Мастер"), subtitle: AppStrings.current.f10('x3 combo yap', 'Make an x3 combo', 'Erziele eine x3-Combo', 'Haz un combo x3', 'Réalise un combo x3', 'Realizza una combo x3', 'Faça um combo x3', 'Maak een x3-combo', 'Wykonaj combo x3', 'Сделайте комбо x3'), reward: 150, icon: Icons.bolt_rounded),
    _AchievementData(id: 'lines_25', title: AppStrings.current.f10("Tahta Temizleyici", "Board Cleaner", "Feldreiniger", "Limpiador de tablero", "Nettoyeur de plateau", "Pulitore del tabellone", "Limpador de tabuleiro", "Bordreiniger", "Czyściciel planszy", "Чистильщик поля"), subtitle: AppStrings.current.f10("Toplam 25 satır veya sütun temizle", "Clear 25 rows or columns in total", "Räume insgesamt 25 Reihen oder Spalten ab", "Limpia 25 filas o columnas en total", "Efface 25 lignes ou colonnes au total", "Elimina in totale 25 righe o colonne", "Limpe 25 linhas ou colunas no total", "Wis in totaal 25 rijen of kolommen", "Wyczyść łącznie 25 wierszy lub kolumn", "Очистите всего 25 строк или столбцов"), reward: 200, icon: Icons.auto_awesome_rounded),
    _AchievementData(id: 'games_10', title: AppStrings.current.f10("Deneyimli", "Experienced", "Erfahren", "Experimentado", "Expérimenté", "Esperto", "Experiente", "Ervaren", "Doświadczony", "Опытный"), subtitle: AppStrings.current.f10("10 oyun tamamla", "Complete 10 games", "Beende 10 Spiele", "Completa 10 partidas", "Termine 10 parties", "Completa 10 partite", "Conclua 10 partidas", "Voltooi 10 spellen", "Ukończ 10 gier", "Завершите 10 игр"), reward: 250, icon: Icons.sports_esports_rounded),
    _AchievementData(id: 'blocks_250', title: AppStrings.current.f10("Blok Koleksiyoncusu", "Block Collector", "Blocksammler", "Coleccionista de bloques", "Collectionneur de blocs", "Collezionista di blocchi", "Colecionador de blocos", "Blokverzamelaar", "Kolekcjoner bloków", "Коллекционер блоков"), subtitle: AppStrings.current.f10("250 parça yerleştir", "Place 250 pieces", "Platziere 250 Teile", "Coloca 250 piezas", "Place 250 pièces", "Posiziona 250 pezzi", "Posicione 250 peças", "Plaats 250 stukken", "Umieść 250 elementów", "Разместите 250 фигур"), reward: 300, icon: Icons.grid_view_rounded),
    _AchievementData(id: 'score_10000', title: AppStrings.current.f10("Efsane", "Legend", "Legende", "Leyenda", "Légende", "Leggenda", "Lenda", "Legende", "Legenda", "Легенда"), subtitle: AppStrings.current.f10("Tek oyunda 10.000 puana ulaş", "Reach 10000 points in one game", "Erreiche 10000 Punkte in einem Spiel", "Alcanza 10000 puntos en una partida", "Atteins 10000 points en une partie", "Raggiungi 10000 punti in una partita", "Alcance 10000 pontos em uma partida", "Behaal 10000 punten in één spel", "Zdobądź 10000 punktów w jednej grze", "Наберите 10000 очков за одну игру"), reward: 500, icon: Icons.workspace_premium_rounded),
    _AchievementData(id: 'level_5', title: AppStrings.current.f10("Yükseliş", "Rising Star", "Aufsteigender Stern", "Estrella emergente", "Étoile montante", "Stella nascente", "Estrela ascendente", "Rijzende ster", "Wschodząca gwiazda", "Восходящая звезда"), subtitle: AppStrings.current.f10("Seviye 5 ol", "Reach level 5", "Erreiche Stufe 5", "Alcanza el nivel 5", "Atteins le niveau 5", "Raggiungi il livello 5", "Alcance o nível 5", "Bereik niveau 5", "Osiągnij poziom 5", "Достигните 5 уровня"), reward: 250, icon: Icons.trending_up_rounded),
    _AchievementData(id: 'perfect_3', title: AppStrings.current.f10("Kusursuz", "Flawless", "Makellos", "Impecable", "Parfait", "Perfetto", "Perfeito", "Foutloos", "Bezbłędny", "Безупречно"), subtitle: AppStrings.current.f10("Toplam 3 Perfect Clear yap", "Complete 3 Perfect Clears", "Schaffe 3 perfekte Leerungen", "Haz 3 limpiezas perfectas", "Réalise 3 nettoyages parfaits", "Esegui 3 pulizie perfette", "Faça 3 limpezas perfeitas", "Voltooi 3 perfecte leegbeurten", "Wykonaj 3 idealne czyszczenia", "Выполните 3 идеальные очистки"), reward: 350, icon: Icons.diamond_outlined),
    _AchievementData(id: 'level_15', title: AppStrings.current.f10("ELXVRO Ustası", "ELXVRO Master", "ELXVRO Meister", "ELXVRO Maestro", "ELXVRO Maître", "ELXVRO Maestro", "ELXVRO Mestre", "ELXVRO Meester", "ELXVRO Mistrz", "ELXVRO Мастер"), subtitle: AppStrings.current.f10("Seviye 15 ol", "Reach level 15", "Erreiche Stufe 15", "Alcanza el nivel 15", "Atteins le niveau 15", "Raggiungi il livello 15", "Alcance o nível 15", "Bereik niveau 15", "Osiągnij poziom 15", "Достигните 15 уровня"), reward: 650, icon: Icons.military_tech_rounded),
  ];

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: appState,
      builder: (context, _) {
        final selectedTheme = gameThemes.firstWhere(
          (theme) => theme.id == appState.themeId,
          orElse: () => gameThemes.first,
        );

        return Scaffold(
          body: PremiumBackground(
            top: selectedTheme.backgroundTop,
            bottom: selectedTheme.backgroundBottom,
            material: selectedTheme.material,
            accent: selectedTheme.blockAccent,
            child: SafeArea(
              child: Column(
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.fromLTRB(8, 8, 18, 14),
                    child: Row(
                      children: <Widget>[
                        IconButton(
                          onPressed: () => Navigator.of(context).pop(),
                          icon: const Icon(Icons.arrow_back_rounded),
                        ),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                AppStrings.current.f10("BAŞARIMLAR", "ACHIEVEMENTS", "ERFOLGE", "LOGROS", "SUCCÈS", "OBIETTIVI", "CONQUISTAS", "PRESTATIES", "OSIĄGNIĘCIA", "ДОСТИЖЕНИЯ"),
                                style: TextStyle(
                                  color: Color(0xFFFFD99A),
                                  fontSize: 21,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: 2.2,
                                ),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                AppStrings.current.f10("${appState.unlockedAchievements}/${_items.length} açıldı", "${appState.unlockedAchievements}/${_items.length} unlocked", "${appState.unlockedAchievements}/${_items.length} freigeschaltet", "${appState.unlockedAchievements}/${_items.length} desbloqueado", "${appState.unlockedAchievements}/${_items.length} débloqué", "${appState.unlockedAchievements}/${_items.length} sbloccato", "${appState.unlockedAchievements}/${_items.length} desbloqueado", "${appState.unlockedAchievements}/${_items.length} ontgrendeld", "${appState.unlockedAchievements}/${_items.length} odblokowano", "${appState.unlockedAchievements}/${_items.length} открыто"),
                                style: const TextStyle(color: Colors.white54, fontSize: 12),
                              ),
                            ],
                          ),
                        ),
                        CoinBadge(coins: appState.coins, compact: true),
                      ],
                    ),
                  ),
                  Expanded(
                    child: ListView.separated(
                      padding: const EdgeInsets.fromLTRB(18, 10, 18, 28),
                      itemCount: _items.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 10),
                      itemBuilder: (context, index) {
                        final item = _items[index];
                        final unlocked = appState.achievementUnlocked(item.id);
                        final claimed = appState.isAchievementClaimed(item.id);
                        return _AchievementCard(
                          item: item,
                          unlocked: unlocked,
                          claimed: claimed,
                          accent: selectedTheme.blockAccent,
                          onClaim: () async {
                            final success = await appState.claimAchievement(
                              id: item.id,
                              reward: item.reward,
                            );
                            if (!context.mounted || !success) return;
                            unawaited(AudioService.instance.playReward());
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text(AppStrings.current.f10("+${item.reward} coin kazandın.", "+${item.reward} coins earned.", "+${item.reward} münzen verdient.", "+${item.reward} monedas ganadas.", "+${item.reward} pièces gagnées.", "+${item.reward} monete ottenute.", "+${item.reward} moedas ganhas.", "+${item.reward} munten verdiend.", "+${item.reward} monety zdobyto.", "+${item.reward} монеты получено."))),
                            );
                          },
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class _AchievementCard extends StatelessWidget {
  const _AchievementCard({
    required this.item,
    required this.unlocked,
    required this.claimed,
    required this.accent,
    required this.onClaim,
  });

  final _AchievementData item;
  final bool unlocked;
  final bool claimed;
  final Color accent;
  final VoidCallback onClaim;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: Colors.white.withValues(alpha: unlocked ? 0.055 : 0.028),
        border: Border.all(
          color: unlocked
              ? accent.withValues(alpha: 0.45)
              : Colors.white.withValues(alpha: 0.06),
        ),
      ),
      child: Row(
        children: <Widget>[
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: unlocked
                  ? accent.withValues(alpha: 0.16)
                  : Colors.white.withValues(alpha: 0.04),
            ),
            child: Icon(
              unlocked ? item.icon : Icons.lock_outline_rounded,
              color: unlocked ? accent : Colors.white24,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  item.title,
                  style: TextStyle(
                    color: unlocked ? Colors.white : Colors.white38,
                    fontWeight: FontWeight.w800,
                    fontSize: 15,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  item.subtitle,
                  style: TextStyle(
                    color: unlocked ? Colors.white54 : Colors.white24,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          SizedBox(
            height: 38,
            child: FilledButton(
              onPressed: unlocked && !claimed ? onClaim : null,
              style: FilledButton.styleFrom(
                backgroundColor: const Color(0xFFC98B42),
                disabledBackgroundColor: Colors.white.withValues(alpha: 0.07),
                padding: const EdgeInsets.symmetric(horizontal: 11),
              ),
              child: claimed
                  ? const Icon(Icons.check_rounded, size: 18)
                  : unlocked
                      ? Row(
                          mainAxisSize: MainAxisSize.min,
                          children: <Widget>[
                            const Icon(Icons.monetization_on_rounded, size: 15),
                            const SizedBox(width: 4),
                            Text('+${item.reward}'),
                          ],
                        )
                      : const Icon(Icons.lock_rounded, size: 16),
            ),
          ),
        ],
      ),
    );
  }
}

class _AchievementData {
  const _AchievementData({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.reward,
    required this.icon,
  });

  final String id;
  final String title;
  final String subtitle;
  final int reward;
  final IconData icon;
}
