import 'package:flutter/material.dart';

import '../app_state.dart';
import '../l10n/app_strings.dart';
import '../models/game_theme.dart';
import '../widgets/coin_badge.dart';
import '../widgets/premium_background.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key, required this.appState});

  final AppState appState;

  Future<void> _editName(BuildContext context) async {
    final controller = TextEditingController(text: appState.playerName);
    final value = await showDialog<String>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          backgroundColor: const Color(0xFF12100E),
          title: Text(AppStrings.current.f10("OYUNCU ADI", "PLAYER NAME", "SPIELERNAME", "NOMBRE DEL JUGADOR", "NOM DU JOUEUR", "NOME GIOCATORE", "NOME DO JOGADOR", "SPELERSNAAM", "NAZWA GRACZA", "ИМЯ ИГРОКА")),
          content: TextField(
            controller: controller,
            autofocus: true,
            maxLength: 18,
            textCapitalization: TextCapitalization.words,
            decoration: const InputDecoration(
              hintText: 'ELXVRO',
              counterText: '',
            ),
            onSubmitted: (text) => Navigator.of(dialogContext).pop(text),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(),
              child: Text(AppStrings.current.f10("İPTAL", "CANCEL", "ABBRECHEN", "CANCELAR", "ANNULER", "ANNULLA", "CANCELAR", "ANNULEREN", "ANULUJ", "ОТМЕНА")),
            ),
            FilledButton(
              onPressed: () => Navigator.of(dialogContext).pop(controller.text),
              child: Text(AppStrings.current.f10("KAYDET", "SAVE", "SPEICHERN", "GUARDAR", "ENREGISTRER", "SALVA", "SALVAR", "OPSLAAN", "ZAPISZ", "СОХРАНИТЬ")),
            ),
          ],
        );
      },
    );
    controller.dispose();
    if (value == null || value.trim().isEmpty) return;
    await appState.setPlayerName(value);
  }

  @override
  Widget build(BuildContext context) {
    final selectedTheme = gameThemes.firstWhere(
      (theme) => theme.id == appState.themeId,
      orElse: () => gameThemes.first,
    );

    return Scaffold(
      body: PremiumBackground(
        top: selectedTheme.backgroundTop,
        bottom: selectedTheme.backgroundBottom,
        material: selectedTheme.material,
        accent: selectedTheme.blockAccent,
        child: SafeArea(
          child: AnimatedBuilder(
            animation: appState,
            builder: (context, _) {
              final nextMilestone = ((appState.playerLevel ~/ 5) + 1) * 5;
              return Column(
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.fromLTRB(8, 6, 14, 8),
                    child: Row(
                      children: <Widget>[
                        IconButton(
                          onPressed: () => Navigator.of(context).pop(),
                          icon: const Icon(Icons.arrow_back_rounded),
                        ),
                        Expanded(
                          child: Text(
                            AppStrings.current.f10("PROFİL", "PROFILE", "PROFIL", "PERFIL", "PROFIL", "PROFILO", "PERFIL", "PROFIEL", "PROFIL", "ПРОФИЛЬ"),
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: Color(0xFFFFD98B),
                              fontWeight: FontWeight.w800,
                              letterSpacing: 2,
                            ),
                          ),
                        ),
                        CoinBadge(coins: appState.coins, compact: true),
                      ],
                    ),
                  ),
                  Expanded(
                    child: ListView(
                      padding: const EdgeInsets.fromLTRB(18, 10, 18, 30),
                      children: <Widget>[
                        Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(28),
                            color: Colors.white.withValues(alpha: 0.045),
                            border: Border.all(
                              color: const Color(0xFFFFC86E)
                                  .withValues(alpha: 0.22),
                            ),
                          ),
                          child: Column(
                            children: <Widget>[
                              Container(
                                width: 76,
                                height: 76,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: const LinearGradient(
                                    colors: <Color>[
                                      Color(0xFFFFD98B),
                                      Color(0xFF9B5E24),
                                    ],
                                  ),
                                  boxShadow: <BoxShadow>[
                                    BoxShadow(
                                      color: const Color(0xFFFFB84D)
                                          .withValues(alpha: 0.18),
                                      blurRadius: 24,
                                    ),
                                  ],
                                ),
                                alignment: Alignment.center,
                                child: Text(
                                  '${appState.playerLevel}',
                                  style: const TextStyle(
                                    color: Color(0xFF1B1007),
                                    fontSize: 30,
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 12),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Flexible(
                                    child: Text(
                                      appState.playerName,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.w900,
                                        letterSpacing: 1.3,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 4),
                                  IconButton(
                                    tooltip: AppStrings.current.f10("Oyuncu adını değiştir", "Change player name", "Spielername ändern", "Cambiar nombre del jugador", "Changer le nom du joueur", "Cambia nome giocatore", "Alterar nome do jogador", "Spelersnaam wijzigen", "Zmień nazwę gracza", "Изменить имя игрока"),
                                    visualDensity: VisualDensity.compact,
                                    onPressed: () => _editName(context),
                                    icon: const Icon(
                                      Icons.edit_rounded,
                                      size: 17,
                                      color: Color(0xFFFFCF7A),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 2),
                              Text(
                                AppStrings.current.f10("SEVİYE ${appState.playerLevel}", "LEVEL ${appState.playerLevel}", "STUFE ${appState.playerLevel}", "NIVEL ${appState.playerLevel}", "NIVEAU ${appState.playerLevel}", "LIVELLO ${appState.playerLevel}", "NÍVEL ${appState.playerLevel}", "NIVEAU ${appState.playerLevel}", "POZIOM ${appState.playerLevel}", "УРОВЕНЬ ${appState.playerLevel}"),
                                style: const TextStyle(
                                  color: Color(0xFFFFD98B),
                                  fontSize: 11,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                              const SizedBox(height: 16),
                              ClipRRect(
                                borderRadius: BorderRadius.circular(999),
                                child: LinearProgressIndicator(
                                  value: appState.levelProgress,
                                  minHeight: 9,
                                  backgroundColor:
                                      Colors.white.withValues(alpha: 0.07),
                                  valueColor: const AlwaysStoppedAnimation<Color>(
                                    Color(0xFFFFC86E),
                                  ),
                                ),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                '${appState.currentLevelXp} / ${appState.currentLevelXpTarget} XP  •  ${AppStrings.current.f10("TOPLAM", "TOTAL", "GESAMT", "TOTAL", "TOTAL", "TOTALE", "TOTAL", "TOTAAL", "ŁĄCZNIE", "ВСЕГО")} ${appState.xp} XP',
                                style: const TextStyle(
                                  color: Colors.white54,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 14),
                        Row(
                          children: <Widget>[
                            Expanded(
                              child: _ProfileStat(
                                icon: Icons.emoji_events_rounded,
                                label: AppStrings.current.f10("EN İYİ", "BEST", "BESTE", "MEJOR", "MEILLEUR", "MIGLIORE", "MELHOR", "BESTE", "NAJLEPSZY", "ЛУЧШИЙ"),
                                value: '${appState.bestScore}',
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: _ProfileStat(
                                icon: Icons.local_fire_department_rounded,
                                label: AppStrings.current.f10("MAKS COMBO", "MAX COMBO", "MAXIMALE COMBO", "COMBO MÁXIMA", "COMBO MAXIMALE", "COMBO MASSIMA", "COMBO MÁXIMA", "MAXIMALE COMBO", "MAKSYMALNE COMBO", "МАКСИМАЛЬНОЕ КОМБО"),
                                value: 'x${appState.maxCombo}',
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: <Widget>[
                            Expanded(
                              child: _ProfileStat(
                                icon: Icons.grid_view_rounded,
                                label: AppStrings.current.f10("BLOK", "BLOCK", "BLOCK", "BLOQUE", "BLOC", "BLOCCO", "BLOCO", "BLOK", "BLOK", "БЛОК"),
                                value: '${appState.totalBlocks}',
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: _ProfileStat(
                                icon: Icons.auto_awesome_rounded,
                                label: AppStrings.current.f10("KUSURSUZ TEMİZLİK", "PERFECT CLEAR", "PERFEKTE LEERUNG", "LIMPIEZA PERFECTA", "NETTOYAGE PARFAIT", "PULIZIA PERFETTA", "LIMPEZA PERFEITA", "PERFECT LEEG", "IDEALNE CZYSZCZENIE", "ИДЕАЛЬНАЯ ОЧИСТКА"),
                                value: '${appState.perfectClears}',
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 18),
                        Text(
                          AppStrings.current.f10("SEVİYE ÖDÜLLERİ", "LEVEL REWARDS", "STUFENBELOHNUNGEN", "RECOMPENSAS DE NIVEL", "RÉCOMPENSES DE NIVEAU", "RICOMPENSE DI LIVELLO", "RECOMPENSAS DE NÍVEL", "NIVEAUBELONINGEN", "NAGRODY ZA POZIOM", "НАГРАДЫ ЗА УРОВЕНЬ"),
                          style: TextStyle(
                            color: Color(0xFFFFD98B),
                            fontSize: 12,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.3,
                          ),
                        ),
                        const SizedBox(height: 10),
                        _MilestoneCard(
                          level: nextMilestone,
                          currentLevel: appState.playerLevel,
                        ),
                        const SizedBox(height: 10),
                        Text(
                          AppStrings.current.f10("Her 5 seviyede coin + 2 özel blok kazanırsın. Seviye 5, 10, 15, 20 ve 25 ilerlemelerinde premium temalar da otomatik açılır.", "Every 5 levels you earn coins and 2 special blocks. Premium themes unlock at levels 5, 10, 15, 20 and 25.", "Alle 5 Level erhältst du Münzen und 2 Spezialblöcke. Premium-Themen werden auf Level 5, 10, 15, 20 und 25 freigeschaltet.", "Cada 5 niveles ganas monedas y 2 bloques especiales. Los temas prémium se desbloquean en los niveles 5, 10, 15, 20 y 25.", "Tous les 5 niveaux, tu gagnes des pièces et 2 blocs spéciaux. Les thèmes premium se débloquent aux niveaux 5, 10, 15, 20 et 25.", "Ogni 5 livelli ottieni monete e 2 blocchi speciali. I temi premium si sbloccano ai livelli 5, 10, 15, 20 e 25.", "A cada 5 níveis você ganha moedas e 2 blocos especiais. Temas premium são liberados nos níveis 5, 10, 15, 20 e 25.", "Elke 5 levels verdien je munten en 2 speciale blokken. Premiumthema’s worden ontgrendeld op level 5, 10, 15, 20 en 25.", "Co 5 poziomów zdobywasz monety i 2 bloki specjalne. Motywy premium odblokowują się na poziomach 5, 10, 15, 20 i 25.", "Каждые 5 уровней вы получаете монеты и 2 специальных блока. Премиум-темы открываются на уровнях 5, 10, 15, 20 и 25."),
                          style: TextStyle(
                            color: Colors.white.withValues(alpha: 0.45),
                            fontSize: 10,
                            height: 1.45,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}

class _ProfileStat extends StatelessWidget {
  const _ProfileStat({
    required this.icon,
    required this.label,
    required this.value,
  });

  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 16),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.04),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withValues(alpha: 0.05)),
      ),
      child: Row(
        children: <Widget>[
          Icon(icon, color: const Color(0xFFFFCF7A), size: 22),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  value,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 17,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                Text(
                  label,
                  style: const TextStyle(
                    color: Colors.white38,
                    fontSize: 8,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.8,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _MilestoneCard extends StatelessWidget {
  const _MilestoneCard({required this.level, required this.currentLevel});

  final int level;
  final int currentLevel;

  @override
  Widget build(BuildContext context) {
    final themeName = switch (level) {
      5 => AppStrings.current.f10('GECE TEMASI', 'NIGHT THEME', 'NACHTTHEMA', 'TEMA NOCTURNO', 'THÈME NUIT', 'TEMA NOTTE', 'TEMA NOTURNO', 'NACHTTHEMA', 'MOTYW NOCNY', 'НОЧНАЯ ТЕМА'),
      10 => AppStrings.current.f10('MERMER TEMASI', 'MARBLE THEME', 'MARMORTHEMA', 'TEMA DE MÁRMOL', 'THÈME MARBRE', 'TEMA MARMO', 'TEMA DE MÁRMORE', 'MARMERTHEMA', 'MOTYW MARMUROWY', 'МРАМОРНАЯ ТЕМА'),
      15 => AppStrings.current.f10("ATEŞ TEMASI", "FIRE THEME", "FEUER THEMA", "FUEGO TEMA", "FEU THÈME", "FUOCO TEMA", "FOGO TEMA", "VUUR THEMA", "OGIEŃ MOTYW", "ОГОНЬ ТЕМА"),
      20 => AppStrings.current.f10("DOĞA TEMASI", "NATURE THEME", "NATUR THEMA", "NATURALEZA TEMA", "NATURE THÈME", "NATURA TEMA", "NATUREZA TEMA", "NATUUR THEMA", "NATURA MOTYW", "ПРИРОДА ТЕМА"),
      25 => AppStrings.current.f10('AURORA TEMASI', 'AURORA THEME', 'AURORA-THEMA', 'TEMA AURORA', 'THÈME AURORE', 'TEMA AURORA', 'TEMA AURORA', 'AURORA-THEMA', 'MOTYW AURORA', 'ТЕМА АВРОРА'),
      _ => AppStrings.current.f10("PREMIUM ÖDÜL", "PREMIUM REWARD", "PREMIUM BELOHNUNG", "PRÉMIUM RECOMPENSA", "PREMIUM RÉCOMPENSE", "PREMIUM RICOMPENSA", "PREMIUM RECOMPENSA", "PREMIUM BELONING", "PREMIUM NAGRODA", "ПРЕМИУМ НАГРАДА"),
    };
    final coinReward = 200 + level * 10;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFFFFC86E).withValues(alpha: 0.07),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(
          color: const Color(0xFFFFC86E).withValues(alpha: 0.20),
        ),
      ),
      child: Row(
        children: <Widget>[
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: const Color(0xFFFFC86E).withValues(alpha: 0.12),
            ),
            alignment: Alignment.center,
            child: Text(
              '$level',
              style: const TextStyle(
                color: Color(0xFFFFD98B),
                fontSize: 18,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  AppStrings.current.f10("SEVİYE $level ÖDÜLÜ", "LEVEL $level REWARD", "STUFE $level BELOHNUNG", "NIVEL $level RECOMPENSA", "NIVEAU $level RÉCOMPENSE", "LIVELLO $level RICOMPENSA", "NÍVEL $level RECOMPENSA", "NIVEAU $level BELONING", "POZIOM $level NAGRODA", "УРОВЕНЬ $level НАГРАДА"),
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  AppStrings.current.f10("+$coinReward coin  •  +2 özel blok  •  $themeName", "+$coinReward coins  •  +2 special blocks  •  $themeName", "+$coinReward münzen  •  +2 spezial blöcke  •  $themeName", "+$coinReward monedas  •  +2 especial bloques  •  $themeName", "+$coinReward pièces  •  +2 spécial blocs  •  $themeName", "+$coinReward monete  •  +2 speciale blocchi  •  $themeName", "+$coinReward moedas  •  +2 especial blocos  •  $themeName", "+$coinReward munten  •  +2 speciaal blokken  •  $themeName", "+$coinReward monety  •  +2 specjalny bloki  •  $themeName", "+$coinReward монеты  •  +2 специальный блоки  •  $themeName"),
                  style: const TextStyle(
                    color: Colors.white54,
                    fontSize: 9,
                    height: 1.35,
                  ),
                ),
              ],
            ),
          ),
          Text(
            '${(level - currentLevel).clamp(0, 99)} LV',
            style: const TextStyle(
              color: Color(0xFFFFC86E),
              fontSize: 9,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }
}
