import 'dart:async';

import 'package:flutter/material.dart';

import '../app_state.dart';
import '../l10n/app_strings.dart';
import '../models/block_piece.dart';
import '../models/game_theme.dart';
import '../services/audio_service.dart';
import '../widgets/coin_badge.dart';
import '../widgets/piece_preview.dart';
import '../widgets/premium_background.dart';
import '../widgets/themed_block_tile.dart';

class ThemesScreen extends StatelessWidget {
  const ThemesScreen({super.key, required this.appState});

  final AppState appState;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: appState,
      builder: (context, _) {
        final l = AppStrings(appState.languageCode);
        final selected = gameThemes.firstWhere(
          (theme) => theme.id == appState.themeId,
          orElse: () => gameThemes.first,
        );

        return Scaffold(
          body: PremiumBackground(
            top: selected.backgroundTop,
            bottom: selected.backgroundBottom,
            material: selected.material,
            accent: selected.blockAccent,
            child: SafeArea(
              child: Column(
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.fromLTRB(10, 8, 18, 6),
                    child: Row(
                      children: <Widget>[
                        IconButton(
                          onPressed: () => Navigator.of(context).pop(),
                          icon: const Icon(Icons.arrow_back_rounded),
                        ),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                l.t('themes.title'),
                                style: const TextStyle(
                                  fontSize: 22,
                                  fontWeight: FontWeight.w700,
                                  letterSpacing: 2.5,
                                  color: Color(0xFFFFD99A),
                                ),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                l.t('themes.subtitle'),
                                style: const TextStyle(color: Colors.white54, fontSize: 12),
                              ),
                            ],
                          ),
                        ),
                        CoinBadge(coins: appState.coins, compact: true),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(18, 8, 18, 4),
                    child: _ThemeLivePreview(theme: selected),
                  ),
                  const SizedBox(height: 4),
                  Expanded(
                    child: ListView.separated(
                      padding: const EdgeInsets.fromLTRB(18, 14, 18, 28),
                      itemCount: gameThemes.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 12),
                      itemBuilder: (context, index) {
                        final theme = gameThemes[index];
                        final isSelected = appState.themeId == theme.id;
                        final unlocked = appState.isThemeUnlocked(theme.id);
                        final price = appState.themePrice(theme.id);
                        final adventureRequirement =
                            appState.themeAdventureRequirement(theme.id);
                        return _ThemeCard(
                          theme: theme,
                          isSelected: isSelected,
                          unlocked: unlocked,
                          price: price,
                          unlockLabel: adventureRequirement > 0
                              ? AppStrings.current.f10("MACERA $adventureRequirement", "ADVENTURE $adventureRequirement", "ABENTEUER $adventureRequirement", "AVENTURA $adventureRequirement", "AVENTURE $adventureRequirement", "AVVENTURA $adventureRequirement", "AVENTURA $adventureRequirement", "AVONTUUR $adventureRequirement", "PRZYGODA $adventureRequirement", "ПРИКЛЮЧЕНИЕ $adventureRequirement")
                              : null,
                          onTap: () async {
                            if (unlocked) {
                              await appState.setTheme(theme.id);
                              unawaited(
                                AudioService.instance.playThemePreview(
                                  theme.audioProfile,
                                ),
                              );
                              return;
                            }
                            if (adventureRequirement > 0 &&
                                appState.adventureCompletedCount <
                                    adventureRequirement) {
                              if (!context.mounted) return;
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text(
                                    AppStrings.current.f10("Bu tema için Macera’da $adventureRequirement bölüm tamamla.", "Complete $adventureRequirement Adventure levels to unlock this theme.", "Schließe $adventureRequirement Abenteuer-Level ab, um dieses Thema freizuschalten.", "Completa $adventureRequirement niveles de Aventura para desbloquear este tema.", "Termine $adventureRequirement niveaux Aventure pour débloquer ce thème.", "Completa $adventureRequirement livelli Avventura per sbloccare questo tema.", "Conclua $adventureRequirement níveis de Aventura para desbloquear este tema.", "Voltooi $adventureRequirement Avontuur-levels om dit thema vrij te spelen.", "Ukończ $adventureRequirement poziomów Przygody, aby odblokować ten motyw.", "Пройдите $adventureRequirement уровней Приключения, чтобы открыть эту тему."),
                                  ),
                                ),
                              );
                              return;
                            }
                            final ok = await appState.unlockTheme(theme.id);
                            if (!context.mounted) return;
                            if (ok) {
                              unawaited(AudioService.instance.playReward());
                              unawaited(
                                AudioService.instance.playThemePreview(
                                  theme.audioProfile,
                                ),
                              );
                            }
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text(
                                  ok
                                      ? AppStrings.current.f10(
                                          '${AppStrings.current.themeName(theme.id)} teması açıldı.',
                                          '${AppStrings.current.themeName(theme.id)} theme unlocked.',
                                          '${AppStrings.current.themeName(theme.id)} Thema freigeschaltet.',
                                          'Tema ${AppStrings.current.themeName(theme.id)} desbloqueado.',
                                          'Thème ${AppStrings.current.themeName(theme.id)} débloqué.',
                                          'Tema ${AppStrings.current.themeName(theme.id)} sbloccato.',
                                          'Tema ${AppStrings.current.themeName(theme.id)} desbloqueado.',
                                          'Thema ${AppStrings.current.themeName(theme.id)} ontgrendeld.',
                                          'Motyw ${AppStrings.current.themeName(theme.id)} odblokowany.',
                                          'Тема ${AppStrings.current.themeName(theme.id)} открыта.',
                                        )
                                      : l.t('themes.no_coins'),
                                ),
                              ),
                            );
                          },
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class _ThemeLivePreview extends StatelessWidget {
  const _ThemeLivePreview({required this.theme});

  final GameThemeData theme;

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 320),
      curve: Curves.easeOutCubic,
      height: 190,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[
            theme.backgroundTop.withValues(alpha: 0.96),
            theme.board.withValues(alpha: 0.96),
            theme.backgroundBottom,
          ],
        ),
        border: Border.all(
          color: theme.blockAccent.withValues(alpha: 0.30),
        ),
      ),
      child: Row(
        children: <Widget>[
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text(
                  AppStrings.current.themeName(theme.id).toUpperCase(),
                  style: TextStyle(
                    color: theme.blockAccent,
                    fontWeight: FontWeight.w900,
                    fontSize: 19,
                    letterSpacing: 1.8,
                  ),
                ),
                const SizedBox(height: 7),
                Text(
                  AppStrings.current.themeSubtitle(theme.id),
                  style: const TextStyle(
                    color: Colors.white60,
                    fontSize: 11,
                    height: 1.35,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  AppStrings.current.f10("GERÇEK MATERYAL ÖNİZLEME", "REAL MATERIAL PREVIEW", "ECHTMATERIAL-VORSCHAU", "VISTA PREVIA DE MATERIAL REAL", "APERÇU DU MATÉRIAU RÉEL", "ANTEPRIMA MATERIALE REALE", "PRÉVIA DE MATERIAL REAL", "VOORBEELD VAN ECHT MATERIAAL", "PODGLĄD PRAWDZIWEGO MATERIAŁU", "ПРЕДПРОСМОТР РЕАЛЬНОГО МАТЕРИАЛА"),
                  style: TextStyle(
                    color: Colors.white30,
                    fontSize: 8,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.2,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          SizedBox(
            width: 122,
            height: 122,
            child: Stack(
              children: <Widget>[
                Positioned(
                  left: 6,
                  top: 8,
                  width: 58,
                  height: 58,
                  child: ThemedBlockTile(
                    material: theme.material,
                    base: theme.block,
                    accent: theme.blockAccent,
                  ),
                ),
                Positioned(
                  right: 5,
                  top: 8,
                  width: 58,
                  height: 58,
                  child: ThemedBlockTile(
                    material: theme.material,
                    base: theme.block,
                    accent: theme.blockAccent,
                  ),
                ),
                Positioned(
                  left: 35,
                  bottom: 5,
                  width: 58,
                  height: 58,
                  child: ThemedBlockTile(
                    material: theme.material,
                    base: theme.block,
                    accent: theme.blockAccent,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ThemeCard extends StatelessWidget {
  const _ThemeCard({
    required this.theme,
    required this.isSelected,
    required this.unlocked,
    required this.price,
    this.unlockLabel,
    required this.onTap,
  });

  final GameThemeData theme;
  final bool isSelected;
  final bool unlocked;
  final int price;
  final String? unlockLabel;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white.withValues(alpha: 0.04),
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: isSelected
                  ? theme.blockAccent.withValues(alpha: 0.95)
                  : Colors.white.withValues(alpha: 0.10),
              width: isSelected ? 1.5 : 1,
            ),
          ),
          child: Row(
            children: <Widget>[
              Container(
                width: 76,
                height: 76,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: <Color>[
                      theme.board,
                      theme.backgroundTop.withValues(alpha: 0.96),
                    ],
                  ),
                  border: Border.all(
                    color: theme.blockAccent.withValues(alpha: 0.24),
                  ),
                  boxShadow: <BoxShadow>[
                    BoxShadow(
                      color: theme.blockAccent.withValues(alpha: 0.12),
                      blurRadius: 18,
                    ),
                  ],
                ),
                child: Stack(
                  alignment: Alignment.center,
                  children: <Widget>[
                    Opacity(
                      opacity: unlocked ? 1 : 0.35,
                      child: PiecePreview(
                        piece: blockCatalog[8],
                        color: theme.block,
                        accent: theme.blockAccent,
                        material: theme.material,
                        cellSize: 20,
                      ),
                    ),
                    if (!unlocked)
                      const Icon(Icons.lock_rounded, color: Colors.white70),
                  ],
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      AppStrings.current.themeName(theme.id),
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      AppStrings.current.themeSubtitle(theme.id),
                      style: const TextStyle(color: Colors.white38, fontSize: 12),
                    ),
                    if (!unlocked) ...<Widget>[
                      const SizedBox(height: 8),
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: <Widget>[
                          Icon(
                            unlockLabel != null
                                ? Icons.map_rounded
                                : Icons.monetization_on_rounded,
                            color: const Color(0xFFFFC86E),
                            size: 15,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            unlockLabel ?? '$price',
                            style: const TextStyle(
                              color: Color(0xFFFFD98B),
                              fontWeight: FontWeight.w900,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ],
                ),
              ),
              if (isSelected)
                Container(
                  width: 34,
                  height: 34,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: theme.block.withValues(alpha: 0.38),
                  ),
                  child: Icon(Icons.check_rounded, color: theme.blockAccent),
                )
              else if (unlocked)
                const Icon(Icons.chevron_right_rounded, color: Colors.white30),
            ],
          ),
        ),
      ),
    );
  }
}
