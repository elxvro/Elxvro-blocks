import 'package:flutter/material.dart';

import '../app_state.dart';
import '../l10n/app_strings.dart';
import '../models/game_mode.dart';
import '../models/game_theme.dart';
import '../widgets/coin_badge.dart';
import '../widgets/premium_background.dart';
import '../widgets/themed_block_tile.dart';
import 'adventure_screen.dart';
import 'falling_blocks_screen.dart';
import 'game_screen.dart';

class ModesScreen extends StatelessWidget {
  const ModesScreen({super.key, required this.appState});

  final AppState appState;

  int _bestFor(GameMode mode) {
    switch (mode) {
      case GameMode.classic:
        return appState.bestScore;
      case GameMode.timed:
        return appState.timedBestScore;
      case GameMode.comboRush:
        return appState.comboRushBestScore;
      case GameMode.target:
        return appState.targetBestScore;
      case GameMode.daily:
        return appState.dailyChallengeBestScore;
      case GameMode.zen:
        return appState.zenBestScore;
      case GameMode.hard:
        return appState.hardBestScore;
    }
  }

  IconData _iconFor(GameMode mode) {
    switch (mode) {
      case GameMode.classic:
        return Icons.grid_view_rounded;
      case GameMode.timed:
        return Icons.timer_outlined;
      case GameMode.comboRush:
        return Icons.bolt_rounded;
      case GameMode.target:
        return Icons.flag_rounded;
      case GameMode.daily:
        return Icons.local_fire_department_rounded;
      case GameMode.zen:
        return Icons.spa_rounded;
      case GameMode.hard:
        return Icons.whatshot_rounded;
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = AppStrings(appState.languageCode);
    final selectedTheme = gameThemes.firstWhere(
      (theme) => theme.id == appState.themeId,
      orElse: () => gameThemes.first,
    );
    final accent = selectedTheme.blockAccent;

    return Scaffold(
      body: PremiumBackground(
        top: selectedTheme.backgroundTop,
        bottom: selectedTheme.backgroundBottom,
        material: selectedTheme.material,
        accent: accent,
        child: SafeArea(
          child: Column(
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.fromLTRB(8, 6, 16, 4),
                child: Row(
                  children: <Widget>[
                    IconButton(
                      onPressed: () => Navigator.of(context).pop(),
                      icon: const Icon(Icons.arrow_back_rounded),
                    ),
                    Expanded(
                      child: Text(
                        l.t('modes.title'),
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: accent,
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 2.0,
                        ),
                      ),
                    ),
                    CoinBadge(coins: appState.coins, compact: true),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(24, 4, 24, 14),
                child: Text(
                  AppStrings.current.f10("Macera, Combo Rush, Günlük Meydan Okuma, Klasik, Zen ve Zor mod ile farklı hedeflerde ilerle.", "Choose Adventure, Combo Rush, Daily Challenge, Classic, Zen or Hard mode.", "Wähle Abenteuer, Combo Rush, Tagesherausforderung, Klassisch, Zen oder Schwer.", "Elige Aventura, Combo Rush, Desafío diario, Clásico, Zen o Difícil.", "Choisis Aventure, Combo Rush, Défi quotidien, Classique, Zen ou Difficile.", "Scegli Avventura, Combo Rush, Sfida giornaliera, Classica, Zen o Difficile.", "Escolha Aventura, Combo Rush, Desafio diário, Clássico, Zen ou Difícil.", "Kies Avontuur, Combo Rush, Daguitdaging, Klassiek, Zen of Moeilijk.", "Wybierz Przygodę, Combo Rush, Wyzwanie dzienne, Klasyczny, Zen lub Trudny.", "Выберите Приключение, Combo Rush, Ежедневное испытание, Классику, Zen или Сложный режим."),
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white.withValues(alpha: 0.52),
                    fontSize: 11,
                    height: 1.45,
                  ),
                ),
              ),
              Expanded(
                child: ListView.separated(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
                  itemCount: GameMode.values.length + 2,
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder: (context, index) {
                    if (index == 0) {
                      return _ModeCard(
                        icon: Icons.map_rounded,
                        title: l.t('modes.adventure'),
                        subtitle: l.t('modes.adventure_subtitle'),
                        description:
                            l.t('modes.adventure_description'),
                        best: appState.adventureCompletedCount,
                        bestLabel: l.t('modes.completed'),
                        reward: 0,
                        rewardReady: false,
                        accent: accent,
                        surface: selectedTheme.board,
                        material: selectedTheme.material,
                        block: selectedTheme.block,
                        blockAccent: selectedTheme.blockAccent,
                        onTap: () {
                          Navigator.of(context).push(
                            MaterialPageRoute<void>(
                              builder: (_) => AdventureScreen(appState: appState),
                            ),
                          );
                        },
                      );
                    }

                    if (index == 1) {
                      return _ModeCard(
                        icon: Icons.view_module_rounded,
                        title: l.t('modes.falling'),
                        subtitle: AppStrings.current.f10("Arcade • düşür • döndür • çizgi temizle", "Arcade • drop • rotate • clear lines", "Arcade • fallen lassen • drehen • Linien räumen", "Arcade • soltar • girar • limpiar líneas", "Arcade • déposer • pivoter • effacer les lignes", "Arcade • lascia cadere • ruota • elimina linee", "Arcade • soltar • girar • limpar linhas", "Arcade • laten vallen • draaien • lijnen wissen", "Arcade • upuszczaj • obracaj • czyść linie", "Аркада • сбрасывай • вращай • очищай линии"),
                        description:
                            AppStrings.current.f10("Klasik düşen blok mantığında ayrı 10×20 bölüm. Hız giderek artar.", "A dedicated 10×20 falling block mode where speed increases over time.", "Ein eigener 10×20-Fallblockmodus, in dem die Geschwindigkeit mit der Zeit steigt.", "Un modo de bloques que caen 10×20 donde la velocidad aumenta con el tiempo.", "Un mode de blocs tombants 10×20 où la vitesse augmente progressivement.", "Una modalità a blocchi cadenti 10×20 in cui la velocità aumenta col tempo.", "Um modo de blocos cadentes 10×20 em que a velocidade aumenta com o tempo.", "Een aparte 10×20-modus met vallende blokken waarin de snelheid steeds toeneemt.", "Osobny tryb spadających bloków 10×20, w którym prędkość z czasem rośnie.", "Отдельный режим падающих блоков 10×20, где скорость постепенно растёт."),
                        best: appState.fallingBlocksBestScore,
                        reward: 0,
                        rewardReady: false,
                        accent: accent,
                        surface: selectedTheme.board,
                        material: selectedTheme.material,
                        block: selectedTheme.block,
                        blockAccent: selectedTheme.blockAccent,
                        onTap: () {
                          Navigator.of(context).push(
                            MaterialPageRoute<void>(
                              builder: (_) => FallingBlocksScreen(
                                appState: appState,
                              ),
                            ),
                          );
                        },
                      );
                    }

                    final mode = GameMode.values[index - 2];
                    final data = mode == GameMode.daily
                        ? dailyChallengeData(DateTime.now())
                        : gameModeData[mode]!;
                    final best = _bestFor(mode);
                    final dailyRewardReady = mode == GameMode.daily &&
                        appState.dailyChallengeRewardAvailable;
                    return _ModeCard(
                      icon: _iconFor(mode),
                      title: l.modeTitle(data.id),
                      subtitle: l.modeSubtitle(data.id, deterministicDaily: mode == GameMode.daily),
                      description: l.modeDescription(
                        data.id,
                        durationSeconds: data.durationSeconds,
                        targetScore: data.targetScore,
                        deterministicDaily: mode == GameMode.daily,
                      ),
                      best: best,
                      reward: data.completionReward,
                      rewardReady: dailyRewardReady,
                      accent: accent,
                      surface: selectedTheme.board,
                        material: selectedTheme.material,
                        block: selectedTheme.block,
                        blockAccent: selectedTheme.blockAccent,
                      onTap: () {
                        Navigator.of(context).push(
                          MaterialPageRoute<void>(
                            builder: (_) => GameScreen(
                              appState: appState,
                              mode: mode,
                            ),
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ModeCard extends StatelessWidget {
  const _ModeCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.description,
    required this.best,
    this.bestLabel = '',
    required this.reward,
    required this.rewardReady,
    required this.accent,
    required this.surface,
    required this.material,
    required this.block,
    required this.blockAccent,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final String description;
  final int best;
  final String bestLabel;
  final int reward;
  final bool rewardReady;
  final Color accent;
  final Color surface;
  final ThemeMaterial material;
  final Color block;
  final Color blockAccent;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final effectiveBestLabel = bestLabel.isEmpty
        ? AppStrings.current.t('modes.record')
        : bestLabel;
    return Material(
      color: Color.lerp(surface, Colors.black, 0.14)!.withValues(alpha: 0.84),
      borderRadius: BorderRadius.circular(22),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(22),
        child: Container(
          padding: const EdgeInsets.all(17),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            border: Border.all(
              color: accent.withValues(alpha: rewardReady ? 0.48 : 0.18),
            ),
            boxShadow: <BoxShadow>[
              BoxShadow(
                color: accent.withValues(alpha: 0.07),
                blurRadius: 20,
              ),
            ],
          ),
          child: Row(
            children: <Widget>[
              _ModeMaterialPreview(
                icon: icon,
                material: material,
                base: block,
                accent: blockAccent,
                surface: surface,
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        Expanded(
                          child: Text(
                            title,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1.0,
                            ),
                          ),
                        ),
                        if (rewardReady)
                          _Badge(label: AppStrings.current.f10("ÖDÜL HAZIR", "REWARD READY", "BELOHNUNG BEREIT", "RECOMPENSA LISTO", "RÉCOMPENSE PRÊT", "RICOMPENSA PRONTO", "RECOMPENSA PRONTO", "BELONING GEREED", "NAGRODA GOTOWE", "НАГРАДА ГОТОВО"), accent: accent),
                      ],
                    ),
                    const SizedBox(height: 2),
                    Text(
                      subtitle,
                      style: TextStyle(
                        color: accent,
                        fontSize: 10,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 7),
                    Text(
                      description,
                      style: TextStyle(
                        color: Colors.white.withValues(alpha: 0.52),
                        fontSize: 10,
                        height: 1.35,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Wrap(
                      spacing: 8,
                      runSpacing: 6,
                      children: <Widget>[
                        _Badge(label: '$effectiveBestLabel $best', accent: accent),
                        if (reward > 0)
                          _Badge(label: AppStrings.current.f10("+$reward COIN", "+$reward COINS", "+$reward MÜNZEN", "+$reward MONEDAS", "+$reward PIÈCES", "+$reward MONETE", "+$reward MOEDAS", "+$reward MUNTEN", "+$reward MONETY", "+$reward МОНЕТЫ"), accent: accent),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Icon(
                Icons.chevron_right_rounded,
                color: accent.withValues(alpha: 0.68),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ModeMaterialPreview extends StatelessWidget {
  const _ModeMaterialPreview({
    required this.icon,
    required this.material,
    required this.base,
    required this.accent,
    required this.surface,
  });

  final IconData icon;
  final ThemeMaterial material;
  final Color base;
  final Color accent;
  final Color surface;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 66,
      height: 66,
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[
            Color.lerp(surface, accent, 0.12)!,
            Color.lerp(surface, Colors.black, 0.22)!,
          ],
        ),
        border: Border.all(color: accent.withValues(alpha: 0.28)),
        boxShadow: <BoxShadow>[
          BoxShadow(color: accent.withValues(alpha: 0.12), blurRadius: 16),
        ],
      ),
      child: Stack(
        children: <Widget>[
          Positioned(
            left: 2,
            top: 2,
            width: 29,
            height: 29,
            child: ThemedBlockTile(material: material, base: base, accent: accent),
          ),
          Positioned(
            right: 2,
            bottom: 2,
            width: 29,
            height: 29,
            child: ThemedBlockTile(
              material: material,
              base: Color.lerp(base, accent, 0.20)!,
              accent: Colors.white,
            ),
          ),
          Align(
            alignment: Alignment.center,
            child: Container(
              width: 28,
              height: 28,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.black.withValues(alpha: 0.58),
                border: Border.all(color: accent.withValues(alpha: 0.34)),
              ),
              child: Icon(icon, color: accent, size: 16),
            ),
          ),
        ],
      ),
    );
  }
}

class _Badge extends StatelessWidget {
  const _Badge({required this.label, required this.accent});

  final String label;
  final Color accent;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(999),
        color: accent.withValues(alpha: 0.08),
        border: Border.all(color: accent.withValues(alpha: 0.12)),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: accent,
          fontSize: 8,
          fontWeight: FontWeight.w800,
          letterSpacing: 0.4,
        ),
      ),
    );
  }
}
