import 'dart:async';

import 'package:flutter/material.dart';

import '../app_state.dart';
import '../l10n/app_strings.dart';
import '../models/game_theme.dart';
import '../services/audio_service.dart';
import '../widgets/coin_badge.dart';
import '../widgets/premium_background.dart';

class StoreScreen extends StatelessWidget {
  const StoreScreen({super.key, required this.appState});

  final AppState appState;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: appState,
      builder: (context, _) {
        final selectedTheme = gameThemes.firstWhere(
          (theme) => theme.id == appState.themeId,
          orElse: () => gameThemes.first,
        );
        return Scaffold(
          body: PremiumBackground(
            top: selectedTheme.backgroundTop,
            bottom: selectedTheme.backgroundBottom,
            material: selectedTheme.material,
            accent: selectedTheme.blockAccent,
            child: SafeArea(
              child: Column(
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.fromLTRB(8, 8, 18, 10),
                    child: Row(
                      children: <Widget>[
                        IconButton(
                          onPressed: () => Navigator.of(context).pop(),
                          icon: const Icon(Icons.arrow_back_rounded),
                        ),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                AppStrings.current.f10("MAĞAZA", "STORE", "SHOP", "TIENDA", "BOUTIQUE", "NEGOZIO", "LOJA", "WINKEL", "SKLEP", "МАГАЗИН"),
                                style: TextStyle(
                                  color: Color(0xFFFFD99A),
                                  fontSize: 21,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: 2.1,
                                ),
                              ),
                              SizedBox(height: 2),
                              Text(
                                AppStrings.current.f10("Coinlerini güçlere dönüştür", "Turn coins into power ups", "Verwandle Münzen in Kräfte", "Convierte monedas en poderes", "Transforme tes pièces en pouvoirs", "Trasforma le monete in potenziamenti", "Transforme moedas em poderes", "Zet munten om in krachten", "Zamień monety na moce", "Обменивайте монеты на усиления"),
                                style: TextStyle(
                                  color: Colors.white54,
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ),
                        ),
                        CoinBadge(coins: appState.coins),
                      ],
                    ),
                  ),
                  Expanded(
                    child: ListView(
                      padding: const EdgeInsets.fromLTRB(18, 12, 18, 28),
                      children: <Widget>[
                        _InventoryPanel(appState: appState),
                        const SizedBox(height: 14),
                        _StoreCard(
                          icon: Icons.undo_rounded,
                          title: AppStrings.current.f10("Geri Al Paketi", "Undo Pack", "Rückgängig-Paket", "Paquete de deshacer", "Lot d’annulations", "Pacchetto annulla", "Pacote de desfazer", "Pakket ongedaan maken", "Pakiet cofnięć", "Набор отмен"),
                          subtitle: AppStrings.current.f10("3 ekstra geri al hakkı", "3 extra undo uses", "3 zusätzliche Rückgängig-Nutzungen", "3 usos extra de Deshacer", "3 utilisations Annuler supplémentaires", "3 usi Annulla extra", "3 usos extras de Desfazer", "3 extra keer Ongedaan maken", "3 dodatkowe użycia Cofnij", "3 дополнительных отмены"),
                          price: 120,
                          onBuy: appState.buyUndoPack,
                        ),
                        const SizedBox(height: 10),
                        _StoreCard(
                          icon: Icons.autorenew_rounded,
                          title: AppStrings.current.f10("Yenile Paketi", "Refresh Pack", "Aktualisierungspaket", "Paquete de actualización", "Lot d’actualisations", "Pacchetto aggiornamento", "Pacote de atualização", "Vernieuwingspakket", "Pakiet odświeżeń", "Набор обновлений"),
                          subtitle: AppStrings.current.f10("3 ekstra blok yenileme hakkı", "3 extra piece refreshes", "3 zusätzliche Teile-Aktualisierungen", "3 renovaciones extra de piezas", "3 actualisations de pièces supplémentaires", "3 aggiornamenti pezzi extra", "3 atualizações extras de peças", "3 extra stukvernieuwingen", "3 dodatkowe odświeżenia elementów", "3 дополнительных обновления фигур"),
                          price: 120,
                          onBuy: appState.buyRefreshPack,
                        ),
                        const SizedBox(height: 10),
                        _StoreCard(
                          icon: Icons.auto_awesome_rounded,
                          title: AppStrings.current.f10("Özel Blok Paketi", "Special Block Pack", "Spezialblock-Paket", "Paquete de bloques especiales", "Lot de blocs spéciaux", "Pacchetto blocchi speciali", "Pacote de blocos especiais", "Pakket speciale blokken", "Pakiet bloków specjalnych", "Набор специальных блоков"),
                          subtitle: AppStrings.current.f10("3 kez anında özel blok üret", "Create special blocks 3 times", "Erzeuge 3-mal Spezialblöcke", "Crea bloques especiales 3 veces", "Crée des blocs spéciaux 3 fois", "Crea blocchi speciali 3 volte", "Crie blocos especiais 3 vezes", "Maak 3 keer speciale blokken", "Utwórz bloki specjalne 3 razy", "Создайте специальные блоки 3 раза"),
                          price: 180,
                          onBuy: appState.buySpecialPack,
                        ),
                        const SizedBox(height: 10),
                        _StoreCard(
                          icon: Icons.workspace_premium_rounded,
                          title: AppStrings.current.f10("Güç Paketi", "Power Bundle", "Kraftpaket", "Paquete de poderes", "Pack de pouvoirs", "Pacchetto potenziamenti", "Pacote de poderes", "Krachtpakket", "Pakiet mocy", "Набор усилений"),
                          subtitle: AppStrings.current.f10("5 geri al + 5 yenile + 2 özel blok", "5 undo + 5 refresh + 2 special blocks", "5 Rückgängig + 5 Aktualisieren + 2 Spezialblöcke", "5 Deshacer + 5 Actualizar + 2 bloques especiales", "5 Annuler + 5 Actualiser + 2 blocs spéciaux", "5 Annulla + 5 Aggiorna + 2 blocchi speciali", "5 Desfazer + 5 Atualizar + 2 blocos especiais", "5 Ongedaan maken + 5 Vernieuwen + 2 speciale blokken", "5 Cofnij + 5 Odśwież + 2 bloki specjalne", "5 отмен + 5 обновлений + 2 специальных блока"),
                          price: 300,
                          highlighted: true,
                          onBuy: appState.buyPowerBundle,
                        ),
                        const SizedBox(height: 18),
                        Text(
                          AppStrings.current.f10("Coinler yalnızca oyun içi ilerleme ile kazanılır. Bu sürümde gerçek para ile satın alma yoktur.", "Coins are earned only through gameplay. No real money purchases in this version.", "Münzen werden nur durch Spielen verdient. In dieser Version gibt es keine Käufe mit Echtgeld.", "Las monedas se obtienen solo jugando. En esta versión no hay compras con dinero real.", "Les pièces se gagnent uniquement en jouant. Aucun achat en argent réel dans cette version.", "Le monete si ottengono solo giocando. In questa versione non ci sono acquisti con denaro reale.", "As moedas são obtidas apenas jogando. Não há compras com dinheiro real nesta versão.", "Munten verdien je alleen door te spelen. In deze versie zijn er geen aankopen met echt geld.", "Monety zdobywa się wyłącznie podczas gry. W tej wersji nie ma zakupów za prawdziwe pieniądze.", "Монеты зарабатываются только в игре. В этой версии нет покупок за реальные деньги."),
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: Colors.white.withValues(alpha: 0.32),
                            fontSize: 10,
                            height: 1.4,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class _InventoryPanel extends StatelessWidget {
  const _InventoryPanel({required this.appState});

  final AppState appState;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        color: Colors.white.withValues(alpha: 0.045),
        border: Border.all(color: Colors.white.withValues(alpha: 0.08)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: <Widget>[
          _Stock(icon: Icons.undo_rounded, label: AppStrings.current.f10("GERİ AL", "UNDO", "RÜCKGÄNGIG", "DESHACER", "ANNULER", "ANNULLA", "DESFAZER", "ONGEDAAN MAKEN", "COFNIJ", "ОТМЕНА"), value: appState.undoInventory),
          _Stock(icon: Icons.autorenew_rounded, label: AppStrings.current.f10("YENİLE", "REFRESH", "AKTUALISIEREN", "ACTUALIZAR", "ACTUALISER", "AGGIORNA", "ATUALIZAR", "VERNIEUWEN", "ODŚWIEŻ", "ОБНОВИТЬ"), value: appState.refreshInventory),
          _Stock(icon: Icons.auto_awesome_rounded, label: AppStrings.current.f10("ÖZEL", "SPECIAL", "SPEZIAL", "ESPECIAL", "SPÉCIAL", "SPECIALE", "ESPECIAL", "SPECIAAL", "SPECJALNY", "СПЕЦИАЛЬНЫЙ"), value: appState.specialInventory),
        ],
      ),
    );
  }
}

class _Stock extends StatelessWidget {
  const _Stock({required this.icon, required this.label, required this.value});

  final IconData icon;
  final String label;
  final int value;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        Icon(icon, color: const Color(0xFFFFC86E), size: 24),
        const SizedBox(height: 5),
        Text(
          '$value',
          style: const TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.w900,
          ),
        ),
        const SizedBox(height: 2),
        Text(
          label,
          style: const TextStyle(
            color: Colors.white38,
            fontSize: 8,
            fontWeight: FontWeight.w800,
          ),
        ),
      ],
    );
  }
}

class _StoreCard extends StatelessWidget {
  const _StoreCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.price,
    required this.onBuy,
    this.highlighted = false,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final int price;
  final Future<bool> Function() onBuy;
  final bool highlighted;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        color: highlighted
            ? const Color(0xFFFFC86E).withValues(alpha: 0.075)
            : Colors.white.withValues(alpha: 0.04),
        border: Border.all(
          color: highlighted
              ? const Color(0xFFFFC86E).withValues(alpha: 0.35)
              : Colors.white.withValues(alpha: 0.07),
        ),
      ),
      child: Row(
        children: <Widget>[
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: const Color(0xFFFFC86E).withValues(alpha: 0.10),
            ),
            child: Icon(icon, color: const Color(0xFFFFC86E)),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  title,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 15,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: const TextStyle(color: Colors.white54, fontSize: 11),
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          FilledButton(
            onPressed: () async {
              final bought = await onBuy();
              if (!context.mounted) return;
              if (bought) {
                unawaited(AudioService.instance.playReward());
              }
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    bought
                        ? AppStrings.current.f10("Satın alındı.", "Purchased.", "Gekauft.", "Comprado.", "Acheté.", "Acquistato.", "Comprado.", "Gekocht.", "Kupiono.", "Куплено.")
                        : AppStrings.current.f10("Yeterli coin yok.", "Not enough coins.", "Nicht genug Münzen.", "No hay suficientes monedas.", "Pas assez de pièces.", "Monete insufficienti.", "Moedas insuficientes.", "Niet genoeg munten.", "Za mało monet.", "Недостаточно монет."),
                  ),
                ),
              );
            },
            style: FilledButton.styleFrom(
              backgroundColor: const Color(0xFFC98B42),
              padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 10),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                const Icon(Icons.monetization_on_rounded, size: 16),
                const SizedBox(width: 4),
                Text('$price'),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
