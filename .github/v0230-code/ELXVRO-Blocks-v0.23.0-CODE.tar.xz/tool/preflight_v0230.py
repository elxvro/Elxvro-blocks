from pathlib import Path
import re, sys

root = Path(sys.argv[1] if len(sys.argv) > 1 else '.').resolve()
errors = []
langs = ['tr','en','de','es','fr','it','pt','nl','pl','ru']

pub = (root / 'pubspec.yaml').read_text(encoding='utf-8')
if 'version: 0.23.0+47' not in pub:
    errors.append('pubspec version mismatch')

bg = (root / 'lib/widgets/gameplay_background.dart').read_text(encoding='utf-8')
for bad in ['CustomPaint', 'CustomPainter', 'Canvas ']:
    if bad in bg:
        errors.append(f'forbidden gameplay background API: {bad}')

ids = (root / 'lib/services/play_games_ids.dart').read_text(encoding='utf-8')
for value in ['CgkI6arsvtAGEAIQAw','CgkI6arsvtAGEAIQAg','CgkI6arsvtAGEAIQBA']:
    if value not in ids:
        errors.append('missing Play Games id ' + value)

app = (root / 'lib/l10n/app_strings.dart').read_text(encoding='utf-8')
for code in langs:
    if f"LanguageOption('{code}'" not in app:
        errors.append('missing language option ' + code)
keys = list(re.finditer(r"^    '([^']+)': <String, String>\{", app, re.M))
for idx, match in enumerate(keys):
    end = keys[idx + 1].start() if idx + 1 < len(keys) else app.find('\n  };', match.end())
    block = app[match.start():end]
    key = match.group(1)
    for code in langs:
        m = re.search(rf"^      '{code}':\s*(['\"])(.*?)\1,?\s*$", block, re.M)
        if m is None or not m.group(2).strip():
            errors.append(f'{key}: missing/empty {code}')

def f10_calls(text):
    for m in re.finditer(r'\bf10\s*\(', text):
        p = text.find('(', m.start())
        depth = 0; quote = None; esc = False; commas = 0; j = p; last = p + 1
        while j < len(text):
            ch = text[j]
            if quote:
                if esc: esc = False
                elif ch == '\\': esc = True
                elif ch == quote: quote = None
            else:
                if ch in "'\"": quote = ch
                elif ch == '(': depth += 1
                elif ch == ')':
                    depth -= 1
                    if depth == 0:
                        count = commas + (1 if text[last:j].strip() else 0)
                        yield m.start(), count
                        break
                elif ch == ',' and depth == 1:
                    commas += 1; last = j + 1
            j += 1

for p in (root / 'lib').rglob('*.dart'):
    text = p.read_text(encoding='utf-8')
    for pos, count in f10_calls(text):
        if count != 10:
            line = text.count('\n', 0, pos) + 1
            errors.append(f'{p.relative_to(root)}:{line}: f10 has {count} args')
    if p.parent.name == 'screens':
        if 'AppStrings.current.f(' in text:
            errors.append(f'{p.relative_to(root)} still uses two-language f()')
        if "languageCode == 'en'" in text or 'isEnglish' in text:
            errors.append(f'{p.relative_to(root)} still contains English-only branch logic')

state = (root / 'lib/app_state.dart').read_text(encoding='utf-8')
if 'AppStrings.normalizeLanguageCode(savedLanguage)' not in state:
    errors.append('load does not normalize language')
if 'AppStrings.normalizeLanguageCode(code)' not in state:
    errors.append('setLanguage does not normalize language')

# Regression guards for previously discovered mixed-language labels.
for rel in ['lib/screens/game_screen.dart','lib/screens/home_screen.dart','lib/screens/profile_screen.dart','lib/screens/social_hub_screen.dart']:
    text = (root / rel).read_text(encoding='utf-8')
    if re.search(r'"SEVİYE \$\{[^}]+\}",\s*"STUFE ', text):
        errors.append(f'{rel}: English level label is German')

if errors:
    print('FAIL')
    for error in errors:
        print('-', error)
    sys.exit(1)
print(f'PASS: {len(keys)} keyed labels, 10 languages, f10 coverage, IDs, background and version valid')
