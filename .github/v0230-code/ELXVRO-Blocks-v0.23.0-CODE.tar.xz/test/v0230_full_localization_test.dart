import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:elxvro_blocks/app_state.dart';
import 'package:elxvro_blocks/l10n/app_strings.dart';
import 'package:elxvro_blocks/models/adventure_level.dart';
import 'package:elxvro_blocks/models/block_piece.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  const expectedCodes = <String>[
    'tr', 'en', 'de', 'es', 'fr', 'it', 'pt', 'nl', 'pl', 'ru',
  ];

  test('v0.23.0 exposes exactly ten supported languages', () {
    expect(AppStrings.languages.map((item) => item.code).toList(), expectedCodes);
    expect(AppStrings.supportedLanguageCodes.length, 10);
    expect(AppStrings.hasCompleteCatalog, isTrue);
    expect(AppStrings.translationKeyCount, greaterThanOrEqualTo(78));
  });

  test('all ten languages resolve representative UI keys', () {
    const keys = <String>[
      'settings.title',
      'settings.language',
      'home.play',
      'home.store',
      'modes.title',
      'themes.title',
      'adventure.title',
      'falling.rotate',
      'game.undo',
    ];

    for (final code in expectedCodes) {
      final strings = AppStrings(code);
      for (final key in keys) {
        final value = strings.t(key);
        expect(value.trim(), isNotEmpty, reason: '$code / $key is empty');
        expect(value, isNot(key), reason: '$code / $key is untranslated');
      }
    }
  });

  test('ten-language dynamic labels keep the correct language order', () {
    const expectedLevel = <String, String>{
      'tr': 'SEVİYE 7',
      'en': 'LEVEL 7',
      'de': 'STUFE 7',
      'es': 'NIVEL 7',
      'fr': 'NIVEAU 7',
      'it': 'LIVELLO 7',
      'pt': 'NÍVEL 7',
      'nl': 'NIVEAU 7',
      'pl': 'POZIOM 7',
      'ru': 'УРОВЕНЬ 7',
    };
    for (final code in expectedCodes) {
      final value = AppStrings(code).f10(
        'SEVİYE 7', 'LEVEL 7', 'STUFE 7', 'NIVEL 7', 'NIVEAU 7',
        'LIVELLO 7', 'NÍVEL 7', 'NIVEAU 7', 'POZIOM 7', 'УРОВЕНЬ 7',
      );
      expect(value, expectedLevel[code], reason: 'wrong dynamic slot for $code');
    }
  });

  test('every supported language persists and unsupported values fall back', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    final state = AppState();
    await state.load();

    for (final code in expectedCodes) {
      await state.setLanguage(code);
      expect(state.languageCode, code);
      final restored = AppState();
      await restored.load();
      expect(restored.languageCode, code);
    }

    await state.setLanguage('xx');
    expect(state.languageCode, 'tr');
  });

  test('no screen uses the old two-language branch', () {
    for (final entity in Directory('lib/screens').listSync(recursive: true)) {
      if (entity is! File || !entity.path.endsWith('.dart')) continue;
      final source = entity.readAsStringSync();
      expect(source, isNot(contains('AppStrings.current.f(')), reason: entity.path);
      expect(source, isNot(contains("languageCode == 'en'")), reason: entity.path);
      expect(source, isNot(contains('isEnglish')), reason: entity.path);
    }
  });


  test('model-level user facing labels follow all ten languages', () {
    final level = adventureLevelFor(5);
    final special = specialBlockCatalog.firstWhere((piece) => piece.power == PiecePower.columnClear);
    for (final code in expectedCodes) {
      AppStrings.setCurrentLanguage(code);
      expect(level.title.trim(), isNotEmpty, reason: '$code adventure title');
      expect(level.difficultyLabel.trim(), isNotEmpty, reason: '$code adventure difficulty');
      expect(level.objective.trim(), isNotEmpty, reason: '$code adventure objective');
      expect(special.powerLabel.trim(), isNotEmpty, reason: '$code special block label');
    }
    AppStrings.setCurrentLanguage('tr');
  });

  test('gameplay background remains widget-only', () {
    final source = File('lib/widgets/gameplay_background.dart').readAsStringSync();
    expect(source, isNot(contains('CustomPaint')));
    expect(source, isNot(contains('CustomPainter')));
    expect(source, isNot(contains('Canvas ')));
  });
}
