import 'package:flutter_test/flutter_test.dart';
import 'package:elxvro_blocks/models/game_theme.dart';

void main() {
  test('v0.19 premium theme set is complete and compatible', () {
    expect(gameThemes, hasLength(9));

    final ids = gameThemes.map((theme) => theme.id).toSet();
    expect(ids, hasLength(9));
    expect(
      ids,
      containsAll(<String>{
        'classic',
        'night',
        'marble',
        'fire',
        'nature',
        'aurora',
        'obsidian',
        'polar_aurora',
        'magma',
      }),
    );

    expect(ThemeMaterial.values, hasLength(6));

    const supportedProfiles = <String>{
      'glass',
      'wood',
      'stone',
      'leaf',
      'crystal',
      'marble',
    };
    expect(
      gameThemes.every((theme) => supportedProfiles.contains(theme.audioProfile)),
      isTrue,
    );
  });
}
