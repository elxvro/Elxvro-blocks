# ELXVRO Blocks v0.2.0

Premium Flutter block puzzle prototype.

## v0.2.0 additions
- Daily missions with automatic daily reset
- Persistent achievements
- Expanded career statistics
- Haptic feedback for placement and line clears
- Animated combo indicator
- Premium 2x2 home feature grid
- Existing 10x10 drag/drop gameplay and 6 themes retained

## Build
Flutter 3.47.4 / Java 17

```bash
flutter pub get
flutter analyze
flutter test
flutter build apk --release
```
