import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AppState extends ChangeNotifier {
  static const String _bestScoreKey = 'best_score';
  static const String _themeKey = 'theme_id';
  static const String _gamesPlayedKey = 'games_played';
  static const String _maxComboKey = 'max_combo';
  static const String _totalScoreKey = 'total_score';
  static const String _totalLinesKey = 'total_lines';
  static const String _totalBlocksKey = 'total_blocks';
  static const String _dailyDateKey = 'daily_date';
  static const String _dailyGamesKey = 'daily_games';
  static const String _dailyLinesKey = 'daily_lines';
  static const String _dailyBestScoreKey = 'daily_best_score';

  int bestScore = 0;
  int gamesPlayed = 0;
  int maxCombo = 0;
  int totalScore = 0;
  int totalLines = 0;
  int totalBlocks = 0;

  int dailyGames = 0;
  int dailyLines = 0;
  int dailyBestScore = 0;

  String themeId = 'classic';
  bool isLoaded = false;

  int get completedDailyMissions {
    var completed = 0;
    if (dailyGames >= 1) completed += 1;
    if (dailyLines >= 8) completed += 1;
    if (dailyBestScore >= 2500) completed += 1;
    return completed;
  }

  int get unlockedAchievements {
    var unlocked = 0;
    if (gamesPlayed >= 1) unlocked += 1;
    if (bestScore >= 1000) unlocked += 1;
    if (maxCombo >= 3) unlocked += 1;
    if (totalLines >= 25) unlocked += 1;
    if (gamesPlayed >= 10) unlocked += 1;
    if (totalBlocks >= 250) unlocked += 1;
    if (bestScore >= 10000) unlocked += 1;
    return unlocked;
  }

  bool achievementUnlocked(String id) {
    switch (id) {
      case 'first_game':
        return gamesPlayed >= 1;
      case 'score_1000':
        return bestScore >= 1000;
      case 'combo_3':
        return maxCombo >= 3;
      case 'lines_25':
        return totalLines >= 25;
      case 'games_10':
        return gamesPlayed >= 10;
      case 'blocks_250':
        return totalBlocks >= 250;
      case 'score_10000':
        return bestScore >= 10000;
      default:
        return false;
    }
  }

  Future<void> load() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      bestScore = prefs.getInt(_bestScoreKey) ?? 0;
      gamesPlayed = prefs.getInt(_gamesPlayedKey) ?? 0;
      maxCombo = prefs.getInt(_maxComboKey) ?? 0;
      totalScore = prefs.getInt(_totalScoreKey) ?? 0;
      totalLines = prefs.getInt(_totalLinesKey) ?? 0;
      totalBlocks = prefs.getInt(_totalBlocksKey) ?? 0;
      themeId = prefs.getString(_themeKey) ?? 'classic';

      final today = _dayKey(DateTime.now());
      final savedDay = prefs.getString(_dailyDateKey);
      if (savedDay == today) {
        dailyGames = prefs.getInt(_dailyGamesKey) ?? 0;
        dailyLines = prefs.getInt(_dailyLinesKey) ?? 0;
        dailyBestScore = prefs.getInt(_dailyBestScoreKey) ?? 0;
      } else {
        dailyGames = 0;
        dailyLines = 0;
        dailyBestScore = 0;
        await _saveDaily(prefs, today);
      }
    } catch (error, stackTrace) {
      debugPrint('ELXVRO storage load failed: $error');
      debugPrintStack(stackTrace: stackTrace);
    } finally {
      isLoaded = true;
      notifyListeners();
    }
  }

  Future<void> setTheme(String id) async {
    themeId = id;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_themeKey, id);
    } catch (error) {
      debugPrint('ELXVRO theme save failed: $error');
    }
  }

  Future<void> recordGame({
    required int score,
    required int combo,
    required int clearedLines,
    required int placedBlocks,
  }) async {
    gamesPlayed += 1;
    totalScore += score;
    totalLines += clearedLines;
    totalBlocks += placedBlocks;

    if (score > bestScore) {
      bestScore = score;
    }
    if (combo > maxCombo) {
      maxCombo = combo;
    }

    final today = _dayKey(DateTime.now());
    dailyGames += 1;
    dailyLines += clearedLines;
    if (score > dailyBestScore) {
      dailyBestScore = score;
    }
    notifyListeners();

    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt(_bestScoreKey, bestScore);
      await prefs.setInt(_gamesPlayedKey, gamesPlayed);
      await prefs.setInt(_maxComboKey, maxCombo);
      await prefs.setInt(_totalScoreKey, totalScore);
      await prefs.setInt(_totalLinesKey, totalLines);
      await prefs.setInt(_totalBlocksKey, totalBlocks);
      await _saveDaily(prefs, today);
    } catch (error) {
      debugPrint('ELXVRO stats save failed: $error');
    }
  }

  Future<void> _saveDaily(SharedPreferences prefs, String day) async {
    await prefs.setString(_dailyDateKey, day);
    await prefs.setInt(_dailyGamesKey, dailyGames);
    await prefs.setInt(_dailyLinesKey, dailyLines);
    await prefs.setInt(_dailyBestScoreKey, dailyBestScore);
  }

  String _dayKey(DateTime date) {
    final year = date.year.toString().padLeft(4, '0');
    final month = date.month.toString().padLeft(2, '0');
    final day = date.day.toString().padLeft(2, '0');
    return '$year-$month-$day';
  }
}
