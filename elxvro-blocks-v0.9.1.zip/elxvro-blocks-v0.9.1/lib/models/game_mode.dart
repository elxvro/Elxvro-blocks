enum GameMode {
  classic,
  timed,
  target,
  daily,
}

class GameModeData {
  const GameModeData({
    required this.mode,
    required this.id,
    required this.title,
    required this.subtitle,
    required this.description,
    this.durationSeconds,
    this.targetScore,
    this.completionReward = 0,
  });

  final GameMode mode;
  final String id;
  final String title;
  final String subtitle;
  final String description;
  final int? durationSeconds;
  final int? targetScore;
  final int completionReward;

  bool get hasTimer => durationSeconds != null;
  bool get hasTarget => targetScore != null;
}

const Map<GameMode, GameModeData> gameModeData = <GameMode, GameModeData>{
  GameMode.classic: GameModeData(
    mode: GameMode.classic,
    id: 'classic',
    title: 'KLASİK',
    subtitle: 'Sınırsız oyun',
    description: 'Hamle kalmayana kadar oyna ve kendi rekorunu geliştir.',
  ),
  GameMode.timed: GameModeData(
    mode: GameMode.timed,
    id: 'timed',
    title: '2 DAKİKA',
    subtitle: 'Hız modu',
    description: '120 saniye içinde mümkün olan en yüksek skoru yap.',
    durationSeconds: 120,
    completionReward: 25,
  ),
  GameMode.target: GameModeData(
    mode: GameMode.target,
    id: 'target',
    title: 'HEDEF 5000',
    subtitle: 'Skor meydan okuması',
    description: 'Hamlelerin bitmeden 5.000 puana ulaş.',
    targetScore: 5000,
    completionReward: 60,
  ),
  GameMode.daily: GameModeData(
    mode: GameMode.daily,
    id: 'daily',
    title: 'GÜNLÜK CHALLENGE',
    subtitle: 'Her gün yeni tahta',
    description: '3 dakika içinde 3.500 puana ulaş. Günlük ödül bir kez alınır.',
    durationSeconds: 180,
    targetScore: 3500,
    completionReward: 150,
  ),
};
