import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/foundation.dart';

class AudioService {
  AudioService._();

  static final AudioService instance = AudioService._();

  static const int _maxConcurrentSfx = 6;

  final AudioPlayer _musicPlayer = AudioPlayer();
  bool _musicStarted = false;
  bool _musicEnabled = true;
  bool _sfxEnabled = true;
  bool _suspended = false;
  bool _disposed = false;
  int _activeSfx = 0;
  double _musicVolume = 0.26;
  double _sfxVolume = 0.95;

  Future<void> configure({
    required bool musicEnabled,
    required bool sfxEnabled,
    required double musicVolume,
    required double sfxVolume,
  }) async {
    if (_disposed) return;

    _musicEnabled = musicEnabled;
    _sfxEnabled = sfxEnabled;
    _musicVolume = musicVolume.clamp(0.0, 1.0).toDouble();
    _sfxVolume = sfxVolume.clamp(0.0, 1.0).toDouble();

    try {
      await _musicPlayer.setReleaseMode(ReleaseMode.loop);
      await _musicPlayer.setVolume(_musicVolume);
      if (_musicEnabled && !_suspended) {
        if (!_musicStarted) {
          _musicStarted = true;
          await _musicPlayer.play(
            AssetSource('audio/ambient_loop.wav'),
            volume: _musicVolume,
          );
        } else {
          await _musicPlayer.resume();
        }
      } else if (_musicStarted) {
        await _musicPlayer.pause();
      }
    } catch (error, stackTrace) {
      debugPrint('ELXVRO audio configure failed: $error');
      debugPrintStack(stackTrace: stackTrace);
    }
  }

  Future<void> setSuspended(bool value) async {
    if (_disposed || _suspended == value) return;
    _suspended = value;
    try {
      if (_suspended) {
        if (_musicStarted) {
          await _musicPlayer.pause();
        }
      } else if (_musicEnabled) {
        if (_musicStarted) {
          await _musicPlayer.resume();
        } else {
          _musicStarted = true;
          await _musicPlayer.play(
            AssetSource('audio/ambient_loop.wav'),
            volume: _musicVolume,
          );
        }
      }
    } catch (error) {
      debugPrint('ELXVRO audio lifecycle sync failed: $error');
    }
  }

  Future<void> playClick() => _play('audio/click.wav', 0.92);

  Future<void> playPlace(String profile) =>
      _play('audio/${_safeProfile(profile)}_place.wav', 1.0);

  Future<void> playClear(String profile) =>
      _play('audio/${_safeProfile(profile)}_clear.wav', 1.0);

  Future<void> playCombo(String profile) =>
      _play('audio/${_safeProfile(profile)}_combo.wav', 1.0);

  Future<void> playPerfect(String profile) =>
      _play('audio/${_safeProfile(profile)}_perfect.wav', 1.0);

  Future<void> playThemePreview(String profile) =>
      _play('audio/${_safeProfile(profile)}_clear.wav', 0.92);

  Future<void> playReward() => _play('audio/reward.wav', 1.0);
  Future<void> playGameOver() => _play('audio/game_over.wav', 0.96);

  String _safeProfile(String profile) {
    switch (profile) {
      case 'glass':
      case 'wood':
      case 'stone':
      case 'leaf':
      case 'crystal':
      case 'marble':
        return profile;
      default:
        return 'glass';
    }
  }

  Future<void> _play(String asset, double gain) async {
    if (_disposed || _suspended || !_sfxEnabled || _sfxVolume <= 0) return;
    if (_activeSfx >= _maxConcurrentSfx) return;

    _activeSfx += 1;
    final player = AudioPlayer();
    try {
      await player.play(
        AssetSource(asset),
        volume: (_sfxVolume * gain).clamp(0.0, 1.0).toDouble(),
      );
      await player.onPlayerComplete.first.timeout(
        const Duration(seconds: 4),
        onTimeout: () {},
      );
    } catch (error) {
      debugPrint('ELXVRO sfx failed ($asset): $error');
    } finally {
      _activeSfx -= 1;
      if (_activeSfx < 0) _activeSfx = 0;
      try {
        await player.dispose();
      } catch (error) {
        debugPrint('ELXVRO sfx dispose failed: $error');
      }
    }
  }

  Future<void> dispose() async {
    if (_disposed) return;
    _disposed = true;
    try {
      await _musicPlayer.dispose();
    } catch (error) {
      debugPrint('ELXVRO audio dispose failed: $error');
    }
  }
}
