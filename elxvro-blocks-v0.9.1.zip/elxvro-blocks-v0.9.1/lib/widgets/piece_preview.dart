import 'package:flutter/material.dart';

import '../models/block_piece.dart';
import '../models/game_theme.dart';
import 'theme_surface_painter.dart';

class PiecePreview extends StatelessWidget {
  const PiecePreview({
    super.key,
    required this.piece,
    required this.color,
    required this.accent,
    required this.material,
    this.cellSize = 24,
    this.dimmed = false,
  });

  final BlockPiece piece;
  final Color color;
  final Color accent;
  final ThemeMaterial material;
  final double cellSize;
  final bool dimmed;

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: dimmed ? 0.18 : 1,
      child: SizedBox(
        width: piece.cols * cellSize,
        height: piece.rows * cellSize,
        child: Stack(
          children: piece.cells.map((cell) {
            return Positioned(
              left: cell.col * cellSize,
              top: cell.row * cellSize,
              child: Container(
                width: cellSize - 2,
                height: cellSize - 2,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(cellSize * 0.16),
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: <Color>[
                      accent.withValues(alpha: 0.98),
                      color.withValues(alpha: 0.98),
                    ],
                    stops: const <double>[0.05, 0.95],
                  ),
                  border: Border.all(
                    color: Colors.white.withValues(alpha: 0.34),
                    width: 0.9,
                  ),
                  boxShadow: <BoxShadow>[
                    BoxShadow(
                      color: accent.withValues(alpha: 0.28),
                      blurRadius: 9,
                      spreadRadius: 0.4,
                    ),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(cellSize * 0.15),
                  child: CustomPaint(
                    painter: ThemeSurfacePainter(
                      material: material,
                      accent: accent,
                      intensity: 0.95,
                    ),
                  ),
                ),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }
}
