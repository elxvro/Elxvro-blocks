from pathlib import Path


def insert_after_block(text: str, marker: str, addition: str) -> str:
    start = text.find(marker)
    if start < 0:
        raise SystemExit(f'Could not find {marker!r}')
    brace = text.find('{', start)
    if brace < 0:
        raise SystemExit(f'Could not find opening brace for {marker!r}')
    depth = 0
    for index in range(brace, len(text)):
        char = text[index]
        if char == '{':
            depth += 1
        elif char == '}':
            depth -= 1
            if depth == 0:
                return text[: index + 1] + '\n\n' + addition + text[index + 1 :]
    raise SystemExit(f'Could not find closing brace for {marker!r}')


def patch_kotlin(path: Path) -> None:
    text = path.read_text(encoding='utf-8')
    if 'keystorePropertiesFile' in text:
        print(f'Release signing already configured in {path}')
        return

    imports = 'import java.io.FileInputStream\nimport java.util.Properties\n\n'
    text = imports + text

    properties = '''val keystoreProperties = Properties()\nval keystorePropertiesFile = rootProject.file("key.properties")\nif (keystorePropertiesFile.exists()) {\n    keystoreProperties.load(FileInputStream(keystorePropertiesFile))\n}\n\n'''
    text = insert_after_block(text, 'plugins {', properties)

    marker = '    buildTypes {'
    if marker not in text:
        raise SystemExit(f'Could not find buildTypes in {path}')

    signing = '''    signingConfigs {\n        if (keystorePropertiesFile.exists()) {\n            create("release") {\n                keyAlias = keystoreProperties["keyAlias"] as String\n                keyPassword = keystoreProperties["keyPassword"] as String\n                storeFile = file(keystoreProperties["storeFile"] as String)\n                storePassword = keystoreProperties["storePassword"] as String\n            }\n        }\n    }\n\n'''
    text = text.replace(marker, signing + marker, 1)
    debug_signing = 'signingConfig = signingConfigs.getByName("debug")'
    if debug_signing not in text:
        raise SystemExit(f'Could not find Flutter debug signing fallback in {path}')
    text = text.replace(
        debug_signing,
        'signingConfig = if (keystorePropertiesFile.exists()) signingConfigs.getByName("release") else signingConfigs.getByName("debug")',
        1,
    )
    path.write_text(text, encoding='utf-8')
    print(f'Configured optional release signing in {path}')


def patch_groovy(path: Path) -> None:
    text = path.read_text(encoding='utf-8')
    if 'keystorePropertiesFile' in text:
        print(f'Release signing already configured in {path}')
        return

    text = 'import java.io.FileInputStream\n\n' + text
    properties = '''def keystoreProperties = new Properties()\ndef keystorePropertiesFile = rootProject.file('key.properties')\nif (keystorePropertiesFile.exists()) {\n    keystoreProperties.load(new FileInputStream(keystorePropertiesFile))\n}\n\n'''
    text = insert_after_block(text, 'plugins {', properties)

    marker = '    buildTypes {'
    if marker not in text:
        raise SystemExit(f'Could not find buildTypes in {path}')

    signing = '''    signingConfigs {\n        release {\n            if (keystorePropertiesFile.exists()) {\n                keyAlias keystoreProperties['keyAlias']\n                keyPassword keystoreProperties['keyPassword']\n                storeFile file(keystoreProperties['storeFile'])\n                storePassword keystoreProperties['storePassword']\n            }\n        }\n    }\n\n'''
    text = text.replace(marker, signing + marker, 1)
    groovy_debug = 'signingConfig signingConfigs.debug'
    groovy_debug_equals = 'signingConfig = signingConfigs.debug'
    if groovy_debug in text:
        text = text.replace(
            groovy_debug,
            'signingConfig keystorePropertiesFile.exists() ? signingConfigs.release : signingConfigs.debug',
            1,
        )
    elif groovy_debug_equals in text:
        text = text.replace(
            groovy_debug_equals,
            'signingConfig = keystorePropertiesFile.exists() ? signingConfigs.release : signingConfigs.debug',
            1,
        )
    else:
        raise SystemExit(f'Could not find Flutter debug signing fallback in {path}')
    path.write_text(text, encoding='utf-8')
    print(f'Configured optional release signing in {path}')


kts = Path('android/app/build.gradle.kts')
groovy = Path('android/app/build.gradle')
if kts.exists():
    patch_kotlin(kts)
elif groovy.exists():
    patch_groovy(groovy)
else:
    raise SystemExit('No Android app Gradle file found.')
