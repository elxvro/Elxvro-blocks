from pathlib import Path
import re

manifest = Path('android/app/src/main/AndroidManifest.xml')
if not manifest.exists():
    raise SystemExit(f'Missing {manifest}')

text = manifest.read_text(encoding='utf-8')
text = re.sub(r'android:label="[^"]*"', 'android:label="ELXVRO Blocks"', text, count=1)

# Keep the puzzle game portrait-first on Android. Add the attribute only when
# Flutter's generated activity does not already define an orientation.
activity_pattern = r'(<activity\b[^>]*android:name="\.MainActivity"[^>]*)(>)'
match = re.search(activity_pattern, text, flags=re.S)
if match and 'android:screenOrientation=' not in match.group(1):
    replacement = match.group(1) + '\n            android:screenOrientation="portrait"' + match.group(2)
    text = text[:match.start()] + replacement + text[match.end():]

manifest.write_text(text, encoding='utf-8')
print('Applied ELXVRO Android label and portrait orientation.')
