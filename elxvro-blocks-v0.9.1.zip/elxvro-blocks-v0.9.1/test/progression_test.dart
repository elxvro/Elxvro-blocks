import 'package:elxvro_blocks/app_state.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('Progression', () {
    test('level thresholds grow over time', () {
      expect(AppState.xpForLevel(1), 0);
      expect(AppState.xpForLevel(2), 200);
      expect(AppState.xpForLevel(3), 475);
      expect(AppState.xpForLevel(5), greaterThan(AppState.xpForLevel(4)));
    });

    test('game XP has a minimum and a cap', () {
      expect(
        AppState.maxProgressionXp(
          score: 0,
          combo: 0,
          clearedLines: 0,
          placedBlocks: 0,
          perfectClears: 0,
        ),
        25,
      );
      expect(
        AppState.maxProgressionXp(
          score: 999999,
          combo: 99,
          clearedLines: 999,
          placedBlocks: 999,
          perfectClears: 99,
        ),
        1200,
      );
    });
  });
}
