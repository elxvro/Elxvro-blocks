import 'package:elxvro_blocks/game/board_engine.dart';
import 'package:elxvro_blocks/models/block_piece.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('BoardEngine', () {
    test('places a piece when cells are empty', () {
      final engine = BoardEngine(size: 10);
      const piece = BlockPiece(
        id: 'test',
        cells: <CellOffset>[CellOffset(0, 0), CellOffset(0, 1)],
      );

      final result = engine.place(piece, 2, 3);

      expect(result, isNotNull);
      expect(engine.grid[2][3], isTrue);
      expect(engine.grid[2][4], isTrue);
    });

    test('rejects overlapping placement', () {
      final engine = BoardEngine(size: 10);
      const piece = BlockPiece(
        id: 'test',
        cells: <CellOffset>[CellOffset(0, 0)],
      );

      expect(engine.place(piece, 0, 0), isNotNull);
      expect(engine.place(piece, 0, 0), isNull);
    });

    test('clears a completed row', () {
      final engine = BoardEngine(size: 4);
      const single = BlockPiece(
        id: 'single',
        cells: <CellOffset>[CellOffset(0, 0)],
      );

      for (var col = 0; col < 3; col++) {
        engine.place(single, 0, col);
      }
      final result = engine.place(single, 0, 3);

      expect(result, isNotNull);
      expect(result!.clearedRows, contains(0));
      expect(result.clearedCellCount, 4);
      expect(engine.grid[0].every((value) => value == false), isTrue);
    });

    test('bomb clears neighboring occupied cells', () {
      final engine = BoardEngine(size: 5);
      const single = BlockPiece(
        id: 'single',
        cells: <CellOffset>[CellOffset(0, 0)],
      );
      const bomb = BlockPiece(
        id: 'bomb',
        cells: <CellOffset>[CellOffset(0, 0)],
        power: PiecePower.bomb,
      );

      engine.place(single, 1, 1);
      engine.place(single, 1, 2);
      engine.place(single, 2, 1);
      final result = engine.place(bomb, 2, 2);

      expect(result, isNotNull);
      expect(result!.power, PiecePower.bomb);
      expect(engine.grid[1][1], isFalse);
      expect(engine.grid[1][2], isFalse);
      expect(engine.grid[2][1], isFalse);
      expect(engine.grid[2][2], isFalse);
    });

    test('snapshot can be restored', () {
      final engine = BoardEngine(size: 4);
      const single = BlockPiece(
        id: 'single',
        cells: <CellOffset>[CellOffset(0, 0)],
      );

      engine.place(single, 0, 0);
      final snapshot = engine.snapshot();
      engine.place(single, 1, 1);
      engine.restore(snapshot);

      expect(engine.grid[0][0], isTrue);
      expect(engine.grid[1][1], isFalse);
    });
  });
}
