import 'package:elxvro_blocks/app_state.dart';
import 'package:elxvro_blocks/services/social_service.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('Weekly league', () {
    test('week key starts on Monday', () {
      expect(AppState.weekKeyFor(DateTime(2026, 9, 16)), '2026-09-14');
      expect(AppState.weekKeyFor(DateTime(2026, 9, 20)), '2026-09-14');
      expect(AppState.weekKeyFor(DateTime(2026, 9, 21)), '2026-09-21');
    });

    test('offline social adapter does not fake a connection', () async {
      const service = LocalSocialService();
      final info = await service.connectionInfo();
      expect(info.connected, isFalse);
      expect(await service.signIn(), isFalse);
    });
  });
}
