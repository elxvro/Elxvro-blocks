import 'package:elxvro_blocks/app_state.dart';
import 'package:elxvro_blocks/main.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('ELXVRO Blocks açılıştan ana ekrana geçer', (
    WidgetTester tester,
  ) async {
    final appState = AppState();

    await tester.pumpWidget(ElxvroBlocksApp(appState: appState));
    expect(find.text('ELXVRO'), findsOneWidget);

    await tester.pump(const Duration(milliseconds: 1500));
    await tester.pumpAndSettle();

    expect(find.text('ELXVRO'), findsOneWidget);
    expect(find.text('OYNA'), findsOneWidget);
    expect(find.text('MODLAR'), findsOneWidget);
  });
}
