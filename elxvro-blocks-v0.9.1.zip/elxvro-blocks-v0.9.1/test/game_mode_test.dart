import 'package:elxvro_blocks/models/game_mode.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('challenge mode targets and timers are configured', () {
    expect(gameModeData[GameMode.timed]!.durationSeconds, 120);
    expect(gameModeData[GameMode.target]!.targetScore, 5000);
    expect(gameModeData[GameMode.daily]!.durationSeconds, 180);
    expect(gameModeData[GameMode.daily]!.targetScore, 3500);
  });
}
